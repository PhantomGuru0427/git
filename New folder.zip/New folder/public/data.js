tab1 = {
  name: "",
  telephone: "",
  email: "",
  password: "",
};
tab2 = {
  name: "",
  address: "",
  lastName: "",
  houseNumber: "",
  fiscalCode: "",
  province: "",
  sex: "",
  city: "",
  birthday: "",
  cap: "",
};
tab3 = {
  docType: "",
  releasedBy: "",
  releaseDate: "",
  docNum: "",
  place: "",
};
tab5 = {
  faceId: "",
};
bankAccount = {
  nome: "",
  tipo: "",
  iban: "",
  provincia: "",
  intestazione: "",
  abi: "",
  cab: "",
  conto: "",
  cin: "",
  bic: "",
  banca: "",
  sia: "",
  agenzia: "",
  sepa: "",
};
provider = "";
amountAndData = "";