import React from "react";
import { Routes, Route } from "react-router-dom";
import "./assets/css/font.css";
import "./App.css";
import Home from "./components/home";
import RecoverPassword from "./components/auth/login/RecoverPassword";
import VerifyCode from "./components/auth/login/VerifyCode";
import CreateNewPassword from "./components/auth/login/CreateNewPassword";
import Calcoli from "./pages/Calcoli";
import PrimaNota from "./pages/PrimaNota";
import Modelli from "./pages/Modelli";
import Proprietari from "./pages/Proprietari";
import ViewPropritari from "./pages/ViewPropritari";
import EditPropritari from "./pages/EditPropritari";

import Conduttori from "./pages/Conduttori";
import ViewConduttori from "./pages/ViewConduttori";
import EditConduttori from "./pages/EditConduttori";

import ViewFornitori from "./pages/ViewFornitori";
import EditFornitori from "./pages/EditFornitori";
import Fornitori from "./pages/Fornitori";

import Dashboard from "./pages/Dashboarod";
import Rate from "./pages/Rate";
import ModificationDocument from "./components/Documenti/PrimaNota/ModificationDocument";
import Register from "./components/auth/register/Register.js";
import RegisterSuccess from "./components/auth/register/RegisterSuccess";
import MembersRata from "./pages/MembersRata";
import UnitRata from "./pages/UnitRata";
import InnerDetailsM from "./components/Membri/Rate/Members/InnerDetailsM";
import InnerDetailsU from "./components/Membri/Rate/Unit/InnerDetailsU";
// import RegisterContainer from "./components/Autenticazione/registrazione/register-containter.components";
// import LoginContainer from "./components/Autenticazione/login/login-container.component";
import { Provider } from "react-redux";
import store from "./store";
import RegisterShort from "./components/auth/register/RegisterShort";

const App = () => {
  return (
    <Provider store={store}>
      <Routes>
        <Route path="/:mode" element={<App />} />
        <Route index element={<Home />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="propriietari" element={<Proprietari />} />
        <Route path="propriietari-view" element={<ViewPropritari />} />
        <Route path="propriietari-edit" element={<EditPropritari />} />
        <Route path="conduttori" element={<Conduttori />} />
        <Route path="conduttori-view" element={<ViewConduttori />} />
        <Route path="conduttori-edit" element={<EditConduttori />} />
        <Route path="fornitori" element={<Fornitori />} />
        <Route path="fornitori-view" element={<ViewFornitori />} />
        <Route path="fornitori-edit" element={<EditFornitori />} />
        <Route path="rate" element={<Rate />} />
        <Route path="membersrata" element={<MembersRata />} />
        <Route path="unitrata" element={<UnitRata />} />
        <Route path="unit-details" element={<InnerDetailsU />} />
        <Route path="members-details" element={<InnerDetailsM />} />
        <Route path="calcoli" element={<Calcoli />} />
        <Route path="prima-nota" element={<PrimaNota />} />
        <Route path="modelli" element={<Modelli />} />
        {/* <Route path="register/*" element={<RegisterContainer />} />
          <Route path="login/*" element={<LoginContainer />} /> */}
        <Route
          path="prima-nota/modification-document"
          element={<ModificationDocument />}
        />
        <Route path="/recover" element={<RecoverPassword />} />
        <Route path="/verify" element={<VerifyCode />} />
        <Route path="/newPassword" element={<CreateNewPassword />} />
        <Route path="/extendedRegister" element={<Register />} />
        <Route path="/reducedRegister" element={<RegisterShort />} />
        <Route path="/registerSuccess" element={<RegisterSuccess />} />
      </Routes>
    </Provider>
  );
};

export default App;
