import React, { useState } from "react";
import MediaQuery from "react-responsive";
import Sidebar from "./Sidebar";
import logo from "../assets/images/logo.png";
import mobileMenu from "../assets/images/mobile_menu.svg";
import mobileMenuClose from "../assets/images/white_close.svg";
import { Link } from "react-router-dom";
import { BsChevronDoubleLeft, BsChevronDoubleRight } from "react-icons/bs";
import Menu from "./Menu";
import LastMenu from "./LastMenu";

export default function Container(props) {
  const [isActive, setActive] = useState("false");

  const handleToggle = () => {
    setActive(!isActive);
  };
  const [mobile_menu, setMobileMenu] = useState(false);
  const toggleMobileMenu = () => {
    setMobileMenu(!mobile_menu);
  };
  return (
    <>
      <div className={`mobile-sidebar  ${mobile_menu ? "full-height " : ""}`}>
        <div className="logo-menu-group">
          <Link to="/">
            <img src={logo} alt="logo-image" className="mobile-logo" />
          </Link>
          <button className="mobile-menu">
            <img
              src={`${mobile_menu ? mobileMenuClose : mobileMenu}`}
              alt="mobileMenuIcon"
              className="mobile-menu-icon"
              onClick={toggleMobileMenu}
            />
          </button>
        </div>
        <div className={`${mobile_menu ? "display-show" : "display-hidden"}`}>
          <div className="mt-5">
            <Menu mobile_menu={mobile_menu} setMobileMenu={setMobileMenu} />
          </div>
          <div className="last-links bottom-position">
            <LastMenu />
          </div>
        </div>
      </div>
      <MediaQuery minWidth={1023}>
        <div className={`app-box d-flex ${isActive ? "" : "app-small"}`}>
          <div className="d-flex flex-column sidebar-main">
            <Sidebar />
            <button
              className="
          border-0
          bg-transparent
          text-white
          open-close-btn"
              onClick={handleToggle}
            >
              {isActive ? <BsChevronDoubleLeft /> : <BsChevronDoubleRight />}
            </button>
          </div>
          <div className="right-side-box p-5 d-block">{props.children}</div>
        </div>
      </MediaQuery>
      <MediaQuery maxWidth={1024}>
        <div className={`app-box d-flex ${isActive ? "app-small" : ""}`}>
          <div className="sidebar-main d-flex flex-column">
            <Sidebar />
          </div>
          <div
            className={`right-side-box p-5 d-block ${
              mobile_menu ? "display-hidden" : "display-show"
            }`}
          >
            {props.children}
          </div>
        </div>
      </MediaQuery>
    </>
  );
}
