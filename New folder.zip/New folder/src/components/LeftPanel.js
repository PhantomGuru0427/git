import React from "react";
import EmailIcon from "../assets/images/email-icon.png";
import PhoneIcon from "../assets/images/phone-icon.png";
import "../assets/css/LeftPanel.css";

export default function LeftPanel() {
  return (
    <div className="left-panel  ">
      <div className="logo-div"></div>
      <div className="left-background m-auto">
        <div className="side-login">
          <div className="login-text">
            <div style={{ paddingBottom: "2px" }}>
              Hai bisogno di assistenza?
            </div>
            <div
              className="border-outline border"
              style={{ width: "100%", height: "0px", margin: "auto" }}
            ></div>
          </div>
          <div className="login-text2">
            <div>
              Il nostro call center è a tua disposizone dal lunedì al venerdì
            </div>
            <div style={{ paddingBottom: "30px" }}>dalle 9:00 alle 18:00</div>
            <div className="email-icon">
              <img
                src={EmailIcon}
                alt="email-icon"
                style={{ paddingRight: "10px" }}
              ></img>
              support@realmeta.cloud
            </div>
            <div className="phone-icon">
              <img
                src={PhoneIcon}
                alt="phone-icon"
                style={{ paddingRight: "10px" }}
              ></img>
              +39 0103553678
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
