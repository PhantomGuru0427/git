import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import AddTypeModal from "../Tipologia/AddTypeModal";
import SubjectModal from "../Tipologia/SubjectModal";
import SubjectCard from "../Tipologia/SubjectCard";
import { BsPlusCircleFill } from "react-icons/bs";
import { connect } from "react-redux";
import PrintDwonloadIcons from "./PrintDwonloadIcons";

function MovimentoE(props) {
  const Metodo_di_pagamento = [
    "Accredito su conto corrente",
    "addebito su conto corrente",
    "assegno",
    "bancomat",
    "bollettino freccia",
    "bollettino postale",
    "bonifico",
    "carta di credito",
    "cessione del credito d’imposta",
    "compensazione finanziaria",
    "contanti",
    "giroconto",
    "Mav",
    "paypal",
    "rav",
    "ri.ba",
    "rid",
    "sdd ( sepa direct debit)",
    "vaglia cambiario",
    "vaglia postale",
  ];
  const table_data = [
    ["Idraulico", "Dario Verdi", "010384488", "Ditta individuale"],
    ["Notaio", "Gaetani Aldi", "018283u9", "Ditta individuale"],
  ];
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [subject_modal_show, setSubjectModalShow] = useState(false);
  const subjectModalClose = () => setSubjectModalShow(false);
  const subjectModalShow = () => setSubjectModalShow(true);
  const [subject_id, setSubjectId] = useState(-1);
  const [display, setDisplay] = useState(false);
  return (
    <>
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">
            MOVIMENTO
          </h1>
        </div>
      </div>
      <div className="d-block">
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Tipo di movimento
            </label>
            <div className="d-block">
              <select
                className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white col-sm-10 col-md-11"
                disabled={props.edit_mode ? false : true}
              >
                {props.server_movement_type.map((menu, index) => {
                  return (
                    <option key={index} value={menu}>
                      {menu}
                    </option>
                  );
                })}
                {(e) => {
                  props.user_movement_type.map((user_menu, user_index) => {
                    return (
                      <option key={user_index} value={user_menu}>
                        {user_menu}
                      </option>
                    );
                  });
                }}
              </select>
              <BsPlusCircleFill
                className={`col-sm-2 col-md-1 fs-35 plus-button ${
                  props.edit_mode ? "" : "d-none"
                }`}
                onClick={handleShow}
              />
            </div>
          </div>
        </div>
      </div>
      <div className="d-block">
        <div className="col-md-7">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2 mt-3">
              Descrizione dell’operazione
            </label>
            <textarea
              name=""
              id=""
              cols="30"
              rows="4"
              className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
              disabled={props.edit_mode ? false : true}
            ></textarea>
          </div>
        </div>
      </div>
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">DATE</h1>
        </div>
      </div>
      <div className="row gy-4">
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Data dell’operazione
            </label>
            <div className="d-flex align-items-center justify-content-between border border-secondary rounded-3 border-opacity-50">
              <Form.Control
                className="border-0 fs-16 text-dark flex-grow-1"
                max="9999-12-31"
                type="date"
                disabled={props.edit_mode ? false : true}
              ></Form.Control>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Inizio Competenza
            </label>
            <div className="d-flex align-items-center justify-content-between border border-secondary rounded-3 border-opacity-50">
              <Form.Control
                className="border-0 fs-16 text-dark flex-grow-1"
                max="9999-12-31"
                type="date"
                disabled={props.edit_mode ? false : true}
              ></Form.Control>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Fine Competenza
            </label>
            <div className="d-flex align-items-center justify-content-between border border-secondary rounded-3 border-opacity-50">
              <Form.Control
                className="border-0 fs-16 text-dark flex-grow-1"
                max="9999-12-31"
                type="date"
                disabled={props.edit_mode ? false : true}
              ></Form.Control>
            </div>
          </div>
        </div>
      </div>
      {/* ////////////////////////date/////////////////////////// */}
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">
            IMPORTO
          </h1>
        </div>
      </div>
      <div className="d-block col-md-12">
        {["radio"].map((type) => (
          <div key={`default-${type}`} className="mb-3 d-flex">
            <Form.Check
              default
              className="mb-2 col-md-3"
              label="Importo in entrata"
              name="group1"
              type={type}
              id={`default-${type}-1`}
              disabled={props.edit_mode ? false : true}
            />
            <Form.Check
              default
              className="mb-2 col-md-3"
              label="Importo in uscita"
              name="group1"
              type={type}
              id={`default-${type}-2`}
              disabled={props.edit_mode ? false : true}
            />
          </div>
        ))}
      </div>
      {/* ////////////////////////////// */}
      <div className="row gy-4">
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Imponibile
            </label>
            <input
              type="text"
              className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
              disabled={props.edit_mode ? false : true}
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Codice IVA
            </label>
            <input
              type="text"
              className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
              disabled={props.edit_mode ? false : true}
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Metodo di pagamento
            </label>
            <select
              className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white"
              disabled={props.edit_mode ? false : true}
            >
              {Metodo_di_pagamento.map((menu, index) => {
                return <option value={index}>{menu}</option>;
              })}
            </select>
          </div>
        </div>
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Risorsa contabile
            </label>
            <select
              className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white"
              disabled={props.edit_mode ? false : true}
            >
              <option>Select</option>
              <option>Select</option>
              <option>Select</option>
            </select>
          </div>
        </div>
      </div>
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">
            SOGGETTO
          </h1>
        </div>
      </div>
      <div className="col-12">
        <div className="d-flex align-items-center mt-5 form-last-btns">
          <button
            type="button"
            className={`back-btn btn-last rounded-3 shadow w-193 me-2 border-0 ${
              props.edit_mode ? "" : "d-none"
            }`}
          >
            Nuovo
          </button>
          <button
            type="button"
            className={`back-btn btn-last rounded-3 shadow w-193 me-2 border-0 ${
              props.edit_mode ? "" : "d-none"
            }`}
            onClick={subjectModalShow}
          >
            Seleziona
          </button>
        </div>
      </div>
      {subject_id != -1 ? (
        <SubjectCard
          title="DARIO VERDI"
          table_data={[
            table_data[subject_id][0],
            table_data[subject_id][3],
            table_data[subject_id][2],
          ]}
          closeId={setSubjectId}
          className="mt-4"
        />
      ) : (
        ""
      )}
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">
            ALLEGATI
          </h1>
        </div>
      </div>
      <Modal
        show={show}
        className={`add-section-modal ${display ? "d-none" : "small-modal"}`}
        onHide={handleClose}
        backdrop="static"
      >
        <Modal.Body className="p-3">
          <Button
            variant=""
            onClick={handleClose}
            className="float-end border-0 bg-white"
          >
            <i className="fal fa-times"></i>
          </Button>
          <AddTypeModal setDisplay={setDisplay} />
        </Modal.Body>
      </Modal>
      {/* ///////---------- Select Subject Modal  ---------------///// */}
      <Modal
        show={subject_modal_show}
        className="type-modal"
        onHide={subjectModalClose}
        backdrop="static"
        size="lg"
      >
        <Modal.Body className="p-3">
          <Button
            variant=""
            onClick={subjectModalClose}
            className="float-end border-0 bg-white"
          >
            <i className="fal fa-times"></i>
          </Button>
          <SubjectModal
            table_data={table_data}
            setShow={setSubjectModalShow}
            setId={setSubjectId}
          />
        </Modal.Body>
      </Modal>
    </>
  );
}
const mapStateToProps = (state) => ({
  server_movement_type: state.movementTypeReducer.server_movement_type,
  user_movement_type: state.movementTypeReducer.user_movement_type,
});
export default connect(mapStateToProps, null)(MovimentoE);
