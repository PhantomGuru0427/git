import React, { useState } from "react";
import imageLight from "../../../assets/images/lightimg.png";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import searchIcon from "../../../assets/images/search_icon.svg";
import documentIcon from "../../../assets/images/document_icon.svg";
import closeIcon from "../../../assets/images/close_icon.svg";
import DocumentiModal from "./DocumentiModal";
import { BsPlusCircleFill } from "react-icons/bs";

const DocumentiBtn = (props) => {
  const [show, setShow] = useState(false);
  const [fullscreen, setFullscreen] = useState(true);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [mobile_search, setShowMobileSearch] = useState(-1);
  const showMobileSearch = () => {
    setShowMobileSearch(1);
  };
  const closeMobileSearch = () => {
    setShowMobileSearch(0);
  };
  return (
    <>
      {/* <div className="d-flex flex-row-reverse mb-3 alarm-group">
        <div className="d-flex align-items-end">
          <h6 className="flex-grow-1 fs-14 text-secondary">MARIO ROSSI</h6>
          <div className="img-light flex-shrink-0 w-26 h-26 fw-100 ms-3">
            <img src={imageLight} alt="" />
          </div>
        </div>
      </div> */}
      {/* <div className="d-flex align-item-center justify-content-end mt-3 search-group document-btn-group"> */}
      <div
        className={`d-flex align-item-center justify-content-between mt-2 document-btn-group ${
          mobile_search == 1 ? "search-show" : "search-hidden"
        }`}
      >
        {/* <div className="flex-shrink-0 me-3 mb-2"> */}

        {/* <div className="flex-shrink-0 search-window"> */}
        <div
          className={`${
            mobile_search == 1
              ? "mobile-search-show search-bar"
              : "search-window"
          }`}
        >
          <div className="search-fence d-flex align-items-center bg-white p-2 border-opacity-50 border-secondary border rounded-3 overflow-hidden">
            <i className="fal fa-search flex-shrink-0 me-2 text-secondary opacity-50"></i>
            <input
              type="text"
              name=""
              placeholder="Cerca"
              className="flex-grow-1 border-0 w-100 fs-16 search-bar"
              onChange={(e) => {
                props.setSearchName(e.target.value);
              }}
            />
          </div>
        </div>
        <div
          className={`me-3 mb-2 ${
            mobile_search == 1 ? "btn-hidden" : "btn-show"
          }`}
        >
          {/* <button
            className="documenti-owner-btn border-0 rounded-3 fs-16 modal-btn"
            onClick={handleShow}
          >
            <label className="desktop-label">{props.btnText}</label>
            <label className="mobile-label">Nuovo</label>
          </button> */}
          <BsPlusCircleFill
            className="fs-40 plus-button plus-btn"
            onClick={handleShow}
          />
        </div>
        {/* <div className="mobile-search-btn two-btn"> */}
        <div
          className={`mobile-close-btn mx-2 ${
            mobile_search == 1 ? "mobile-search-show" : "btn-hidden"
          }`}
        >
          <button
            className="close-btn mobile-icon-btn"
            onClick={closeMobileSearch}
          >
            <img src={closeIcon} />
          </button>
        </div>
        <div
          className={`mobile-search-btn  ${
            mobile_search == 1 ? "btn-hidden" : "btn-show two-btn"
          }`}
        >
          <button
            className="document-btn mobile-icon-btn me-2"
            // onClick={closeMobileSearch}
          >
            <img src={documentIcon} />
          </button>
          <button
            className="search-btn mobile-icon-btn"
            onClick={showMobileSearch}
          >
            <img src={searchIcon} />
          </button>
        </div>
      </div>
      <Modal
        show={show}
        fullscreen={fullscreen}
        className="right-full-pop"
        onHide={handleClose}
      >
        <Modal.Body className="p-4">
          <Button
            variant=""
            onClick={handleClose}
            className="float-end border-0 bg-white"
          >
            <i className="fal fa-times"></i>
          </Button>
          <DocumentiModal setShow={setShow} />
        </Modal.Body>
      </Modal>
    </>
  );
};

export default DocumentiBtn;
