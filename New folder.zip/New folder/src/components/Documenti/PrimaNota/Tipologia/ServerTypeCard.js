import React from "react";

export default function ServerTypeCard(props) {
  return (
    <div className="section-card">
      <p className="fs-18">{props.name}</p>
    </div>
  );
}
