import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import ServerTypeCard from "./ServerTypeCard";
import UserTypeCard from "./UserTypeCard";
import NewTypeModal from "./NewTypeModal";
import { BsChevronLeft } from "react-icons/bs";
import { connect } from "react-redux";

function AddTypeModal(props) {
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [search_name, setSearchName] = useState("");
  const modalBack = () => {
    props.setDisplay(false);
    handleClose();
  };
  const nextModal = () => {
    props.setDisplay(true);
    handleShow();
  };

  return (
    <>
      <div className="d-block w-100 mb-3 mt-4">
        <div>
          <h2 className="fs-20 text-dark mb-2 fw-bold">Tipo di movimento</h2>
        </div>
      </div>
      <Form>
        <div className="d-flex align-item-center justify-content-between mb-3">
          <div className="flex-shrink-0">
            <button
              type="button"
              className="documenti-owner-btn fs-16 back-btn rounded-3 shadow w-193 me-2 border-0"
              onClick={nextModal}
            >
              Nuovo
            </button>
          </div>
          <div className="flex-shrink-0 ms-3">
            <div className="search-fence d-flex align-items-center bg-white p-2 border-opacity-50 border-secondary border rounded-3 overflow-hidden">
              <i className="fal fa-search flex-shrink-0 me-2 text-secondary opacity-50"></i>
              <input
                type="text"
                name=""
                placeholder="Cerca"
                className="flex-grow-1 border-0 w-100 fs-14"
                onChange={(e) => {
                  setSearchName(e.target.value);
                }}
              />
            </div>
          </div>
        </div>
        <div className="d-block">
          {props.server_movement_type.map((menu, index) => {
            if (menu.toLowerCase().indexOf(search_name.toLowerCase()) != -1)
              return <ServerTypeCard key={index} name={menu} />;
          })}
          {props.user_movement_type.map((menu, index) => {
            if (menu.toLowerCase().indexOf(search_name.toLowerCase()) != -1)
              return <UserTypeCard key={index} name={menu} />;
          })}
        </div>
        <Modal show={show} className="type-modal" backdrop="static">
          <Modal.Body className="p-3">
            <label
              className="float-start black-link mt-2 back-icon"
              onClick={modalBack}
            >
              <BsChevronLeft />
              Indietro
            </label>
            <Button
              variant=""
              onClick={modalBack}
              className="float-end border-0 bg-white"
            >
              <i className="fal fa-times"></i>
            </Button>
            <NewTypeModal modalBack={modalBack} />
          </Modal.Body>
        </Modal>
      </Form>
    </>
  );
}
const mapStateToProps = (state) => ({
  server_movement_type: state.movementTypeReducer.server_movement_type,
  user_movement_type: state.movementTypeReducer.user_movement_type,
});
export default connect(mapStateToProps, null)(AddTypeModal);
