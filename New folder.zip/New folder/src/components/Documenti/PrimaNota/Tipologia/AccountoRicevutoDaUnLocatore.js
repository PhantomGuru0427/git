import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import ReceiveLessor from "./ReceiveLessor";
import LessorCard from "./LessorCard";

export default function AccountoRicevutoDaUnLocatore() {
  const table_data = [
    [
      "Mario",
      "Rossi",
      "Via Berli",
      "12",
      "Bologna",
      "BO",
      "75646",
      "RSSMRO76CF5D929T",
    ],
    [
      "Giulia",
      "Verdi",
      "Via Merli",
      "13",
      "Bologna",
      "BO",
      "75646",
      "GLABRL76CF5D929T",
    ],
  ];
  const Modalità = ["assegno", "contanti", "vaglia postale"];
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [subject_id, setSubjectId] = useState(-1);

  return (
    <>
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">
            ACCONTO
          </h1>
        </div>
      </div>
      <div className="d-block">
        <div className="col-md-7">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Descrizione dell’operazione
            </label>
            <textarea
              name=""
              id=""
              cols="30"
              rows="4"
              className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
            ></textarea>
          </div>
        </div>
      </div>
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">
            LOCATORE
          </h1>
        </div>
      </div>
      <div className="col-12">
        <div className="d-flex align-items-center mt-5 form-last-btns">
          <button
            type="button"
            className="backwards-btn py-3 rounded-3 fs-16 fw-semibold border border-dark w-192 text-center me-3"
          >
            Nuovo
          </button>
          <button
            type="button"
            className="back-btn btn-last me-2 py-3 rounded-3 fs-16 fw-semibold border border-dark w-192 text-center me-3"
            onClick={handleShow}
          >
            Seleziona
          </button>
        </div>
      </div>
      {subject_id != -1 ? (
        <LessorCard
          title="MARIO ROSSI"
          table_data={[
            "1/3",
            " ",
            `${(table_data[subject_id][2], table_data[subject_id][3])}`,
            table_data[subject_id][6],
            "3347658976",
            table_data[subject_id][7],
            "02/10/2022",
          ]}
          closeId={setSubjectId}
          className="mt-4"
        />
      ) : (
        ""
      )}
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">DATE</h1>
        </div>
      </div>
      <div className="col-md-6">
        <div className="d-flex flex-column">
          <label htmlFor="" className="f-label fs-16 mb-2">
            Data dell’operazione
          </label>
          <div className="d-flex align-items-center justify-content-between border border-secondary px-3 rounded-3 border-opacity-50">
            <Form.Control
              className="border-0 fs-16 text-dark flex-grow-1"
              max="9999-12-31"
              type="date"
            ></Form.Control>
          </div>
        </div>
      </div>
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">
            IMPORTO
          </h1>
        </div>
      </div>
      <div className="row gy-4">
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Importo
            </label>
            <input
              type="text"
              className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Modalità
            </label>
            <select className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white">
              {Modalità.map((menu, index) => {
                return (
                  <option key={index} value={index}>
                    {menu}
                  </option>
                );
              })}
            </select>
          </div>
        </div>
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Da
            </label>
            <select className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white">
              <option>Select</option>
              <option>Select</option>
              <option>Select</option>
            </select>
          </div>
        </div>
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              A
            </label>
            <select className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white">
              <option>Select</option>
              <option>Select</option>
              <option>Select</option>
            </select>
          </div>
        </div>
      </div>
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">
            ALLEGATI
          </h1>
        </div>
      </div>
      <Modal
        show={show}
        className="type-modal"
        onHide={handleClose}
        backdrop="static"
        size="lg"
      >
        <Modal.Body className="p-5">
          <Button
            variant=""
            onClick={handleClose}
            className="float-end border-0 bg-white"
          >
            <i className="fal fa-times"></i>
          </Button>
          <ReceiveLessor
            table_data={table_data}
            setShow={setShow}
            setId={setSubjectId}
          />
        </Modal.Body>
      </Modal>
    </>
  );
}
