import React, { useState } from "react";
import edit from "../../../../assets/images/edit.svg";
import delete_icon from "../../../../assets/images/delete.svg";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import ModifyFileModal from "./ModifyFileModal";
import { connect } from "react-redux";
import { changeMovementType } from "../../../../actions/movementType";
import CheckBtn from "../../../../assets/images/check_btn.svg";
import CloseBtn from "../../../../assets/images/close_btn.svg";

export default function FileCard(props) {
  const [change_state, setChangeState] = useState(false);
  const [new_name, setNewName] = useState(props.name);
  const modifyName = () => {
    setChangeState(false);
  };

  return (
    <>
      <div className="section-card">
        <input
          type="text"
          className="fs-16 text-dark card-input flex-auto"
          disabled={change_state ? false : true}
          value={new_name}
          onChange={(e) => {
            setNewName(e.target.value);
          }}
        />
        <div className={`icon-btn-group ${change_state ? "d-none" : ""}`}>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={() => {
              setChangeState(true);
            }}
          >
            <img src={edit} alt="icon" />
          </button>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={() => props.setFileName("")}
          >
            <img src={delete_icon} alt="icon" />
          </button>
        </div>
        <div className={`icon-btn-group ${change_state ? "" : "d-none"}`}>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={modifyName}
          >
            <img src={CheckBtn} alt="check-icon" />
          </button>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={() => {
              setChangeState(false);
              setNewName(props.name);
            }}
          >
            <img src={CloseBtn} alt="check-icon" />
          </button>
        </div>
      </div>
      {/* <Modal
        show={show}
        className="type-modal"
        onHide={handleClose}
        backdrop="static"
      >
        <Modal.Body className="p-3">
          <Button
            variant=""
            onClick={handleClose}
            className="float-end border-0 bg-white"
          >
            <i className="fal fa-times"></i>
          </Button>
          <ModifyFileModal setFileName={props.setFileName} setShow={setShow} />
        </Modal.Body>
      </Modal> */}
    </>
  );
}
