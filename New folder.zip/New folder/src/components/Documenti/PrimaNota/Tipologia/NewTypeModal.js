import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import { connect } from "react-redux";
import { changeMovementType } from "../../../../actions/movementType";

function NewTypeModal(props) {
  const [new_type, setNewType] = useState("");
  const addNew = () => {
    let initial_user_movement_type = [...props.user_movement_type];
    initial_user_movement_type.push(new_type);
    props.changeMovementType(initial_user_movement_type);
    props.modalBack();
  };
  return (
    <>
      <div className="d-block w-100 mb-3 mt-5">
        <div>
          <h2 className="fs-20 text-dark mb-2 fw-bold">
            Nuovo tipo di movimento
          </h2>
        </div>
      </div>
      <Form>
        <div className="form-item-align-box d-block">
          <div className="mt-3">
            <div className="d-flex flex-column">
              <label className="f-label fs-16 mb-2">Nome</label>
              <input
                type="text"
                className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                onChange={(e) => {
                  setNewType(e.target.value);
                }}
              />
            </div>
          </div>
          <div className="form-last-btns mt-3">
            <button
              type="button"
              className="next-btn btn-last rounded-3 shadow me-2 border-0 col-md-12"
              onClick={addNew}
            >
              Crea
            </button>
            <button
              type="button"
              className="black-btn btn-last rounded-3 shadow border-0 col-md-12 mt-3"
              onClick={() => {
                props.modalBack();
              }}
            >
              Annulla
            </button>
          </div>
        </div>
      </Form>
    </>
  );
}
const mapStateToProps = (state) => ({
  user_movement_type: state.movementTypeReducer.user_movement_type,
});
export default connect(mapStateToProps, { changeMovementType })(NewTypeModal);
