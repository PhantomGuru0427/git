import React, { useState } from "react";
import edit from "../../../../assets/images/edit.svg";
import delete_icon from "../../../../assets/images/delete.svg";
import { connect } from "react-redux";
import { changeMovementType } from "../../../../actions/movementType";
import CheckBtn from "../../../../assets/images/check_btn.svg";
import CloseBtn from "../../../../assets/images/close_btn.svg";

function UserTypeCard(props) {
  const [change_state, setChangeState] = useState(false);
  const [new_name, setNewName] = useState(props.name);
  const modifyName = () => {
    setChangeState(false);
    if (new_name != props.name) {
      let initial_user_movement_type = [...props.user_movement_type];

      for (var i = 0; i < initial_user_movement_type.length; i++) {
        if (initial_user_movement_type[i] == props.name) {
          initial_user_movement_type[i] = new_name;
          break;
        }
      }
      props.changeMovementType(initial_user_movement_type);
    }
  };
  const deleteUserMovementType = () => {
    let initial_user_movement_type = props.user_movement_type;
    initial_user_movement_type = initial_user_movement_type.filter(
      (item) => item != props.name
    );
    props.changeMovementType(initial_user_movement_type);
  };

  return (
    <>
      <div className="section-card">
        <input
          type="text"
          className="fs-16 text-dark card-input flex-auto"
          disabled={change_state ? false : true}
          value={new_name}
          onChange={(e) => {
            setNewName(e.target.value);
          }}
        />
        <div className={`icon-btn-group ${change_state ? "d-none" : ""}`}>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={() => {
              setChangeState(true);
            }}
          >
            <img src={edit} alt="icon" />
          </button>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={deleteUserMovementType}
          >
            <img src={delete_icon} alt="icon" />
          </button>
        </div>
        <div className={`icon-btn-group ${change_state ? "" : "d-none"}`}>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={modifyName}
          >
            <img src={CheckBtn} alt="check-icon" />
          </button>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={() => {
              setChangeState(false);
              setNewName(props.name);
            }}
          >
            <img src={CloseBtn} alt="check-icon" />
          </button>
        </div>
      </div>
    </>
  );
}
const mapStateToProps = (state) => ({
  user_movement_type: state.movementTypeReducer.user_movement_type,
});
export default connect(mapStateToProps, { changeMovementType })(UserTypeCard);
