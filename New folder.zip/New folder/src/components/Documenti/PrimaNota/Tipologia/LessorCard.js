import React from "react";

export default function LessorCard(props) {
  const table_header = [
    "PARTI DI PROPRIETÀ",
    "PROCURATORE",
    "INDIRIZZO",
    "CITTÀ",
    "CAP",
    "TELEFONO",
    "CF",
    "DATA D'INIZIO POSSESSO",
  ];
  return (
    <div className="col-md-6 mt-4">
      <div className="popup-pink d-block overflow-hidden rounded-3">
        <div className="pink-popup-header d-flex align-items-center justify-content-between p-2">
          <h3 className="fs-16 text-white fw-semibold">
            {/* DARIO VERDI } */}
            {props.title}
          </h3>
          <button
            type="button"
            className="border-0 bg-transparent text-white"
            onClick={() => {
              props.closeId(-1);
            }}
          >
            <i className="fal fa-times"></i>
          </button>
        </div>
        <div className="table-list d-block">
          <table className="table table-borderless">
            <tbody>
              {props.table_data.map((data, index) => {
                return (
                  <tr key={index}>
                    <td className="text-uppercase fs-14 text-secondary px-3">
                      {table_header[index]}
                    </td>
                    <td className="text-capitalize fs-14 text-dark px-3">
                      {data}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
