import React from "react";
import Form from "react-bootstrap/Form";

export default function PrelievoDaContoInCassa() {
  const Modalità = ["bancomat", "carta di credito", "contanti"];

  return (
    <>
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">
            PRELIEVO
          </h1>
        </div>
      </div>
      <div className="d-block">
        <div className="col-md-7">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Descrizione dell’operazione
            </label>
            <textarea
              name=""
              id=""
              cols="30"
              rows="4"
              className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
            ></textarea>
          </div>
        </div>
      </div>
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">DATE</h1>
        </div>
      </div>
      <div className="col-md-6">
        <div className="d-flex flex-column">
          <label htmlFor="" className="f-label fs-16 mb-2">
            Data dell’operazione
          </label>
          <div className="d-flex align-items-center justify-content-between border border-secondary px-3 rounded-3 border-opacity-50">
            <Form.Control
              className="border-0 fs-16 text-dark flex-grow-1"
              max="9999-12-31"
              type="date"
            ></Form.Control>
          </div>
        </div>
      </div>
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">
            IMPORTO
          </h1>
        </div>
      </div>
      <div className="row gy-4">
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Importo
            </label>
            <input
              type="text"
              className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
            />
          </div>
        </div>
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Modalità
            </label>
            <select className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white">
              {Modalità.map((menu, index) => {
                return (
                  <option key={index} value={index}>
                    {menu}
                  </option>
                );
              })}
            </select>
          </div>
        </div>
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              Da
            </label>
            <select className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white">
              <option>Select</option>
              <option>Select</option>
              <option>Select</option>
            </select>
          </div>
        </div>
        <div className="col-md-6">
          <div className="d-flex flex-column">
            <label htmlFor="" className="f-label fs-16 mb-2">
              A
            </label>
            <select className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white">
              <option>Select</option>
              <option>Select</option>
              <option>Select</option>
            </select>
          </div>
        </div>
      </div>
      <div className="label-heading my-4 d-block w-100">
        <div className="label-text rel d-inline-block py-2 px-2">
          <h1 className="fs-16 text-white text-uppercase fw-semibold">
            ALLEGATI
          </h1>
        </div>
      </div>
    </>
  );
}
