import React from "react";

export default function DocumentCard(props) {
  return (
    <div className="document-card">
      <p className="fs-14 fw-bold">{props.data["Descrizione"]}</p>
      <p className="fs-14 fw-bold w-15p">{props.data["Data"]}</p>
      <p className="fs-14 fw-bold w-15p">{props.data["Conto"]}</p>
      <p className="fs-14 fw-bold w-15p c-green">
        {`${props.data["Entrata"] != "" ? props.data["Entrata"] + " $" : ""}`}
      </p>
      <p className="fs-14 fw-bold w-15p c-red">
        {`${props.data["Uscita"] != "" ? props.data["Uscita"] + " $" : ""}`}
      </p>
      <p className="fs-14 fw-bold w-15p c-green">
        {`${props.data["Saldo"] != "" ? props.data["Saldo"] + " $" : ""}`}
      </p>
    </div>
  );
}
