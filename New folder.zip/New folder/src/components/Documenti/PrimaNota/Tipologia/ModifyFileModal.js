import React, { useState } from "react";
import Form from "react-bootstrap/Form";

export default function ModifyFileModal(props) {
  const [new_name, setNewName] = useState("");
  return (
    <>
      <div className="d-block w-100 mb-3 mt-2">
        <div>
          <h2 className="fs-20 text-dark mb-2 fw-bold">Rinomina</h2>
        </div>
      </div>
      <Form>
        <div className="form-item-align-box d-block">
          <div className="mt-3">
            <div className="d-flex flex-column">
              <label className="f-label fs-16 mb-2">Nome</label>
              <input
                type="text"
                className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                onChange={(e) => {
                  setNewName(e.target.value);
                }}
              />
            </div>
          </div>
          <div className="form-last-btns mt-3">
            <button
              type="button"
              className="next-btn btn-last rounded-3 shadow me-2 border-0 col-md-12"
              onClick={() => {
                props.setFileName(new_name);
                props.setShow(false);
              }}
            >
              Modifica
            </button>
            <button
              type="button"
              className="black-btn btn-last rounded-3 shadow border-0 col-md-12 mt-3"
              onClick={() => {
                props.setShow(false);
              }}
            >
              Annulla
            </button>
          </div>
        </div>
      </Form>
    </>
  );
}
