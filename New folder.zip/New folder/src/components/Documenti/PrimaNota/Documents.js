import React, { useState, useEffect } from "react";
import Form from "react-bootstrap/Form";
import Table from "react-bootstrap/Table";
import DocumentCard from "./Tipologia/DocumentCard";
import { connect } from "react-redux";
import { changeDocuments } from "../../../actions/documents";
import { Link } from "react-router-dom";

function Documents(props) {
  const account = ["Conto1", "Conto2", "Cassa"];
  const amount = [90.0, 5.0, 10.0];
  const [table_select, setTableSelect] = useState(-1);
  const [flag, setFlag] = useState(false);
  const [from_date, setFromDate] = useState("");
  const [to_date, setToDate] = useState("");
  const [type1, setType1] = useState(false);
  const [type2, setType2] = useState(false);
  const [type3, setType3] = useState(false);
  const [type4, setType4] = useState(false);
  const [tutto, setTutto] = useState(false);
  const [entrata, setEntrata] = useState(false);
  const [uscita, setUscita] = useState(false);
  const [filtered_document, setFilteredDocument] = useState(props.documents);
  const dateCompare = (d1, d2) => {
    const date1 = new Date(d1);
    const date2 = new Date(d2);
    if (date1 >= date2) return true;
    else return false;
  };
  const removeDate = () => {
    setFlag(!flag);
    setFromDate("");
    setToDate("");
  };
  useEffect(() => {
    const filterFunc = () => {
      let temp = props.documents;
      if (from_date != "") {
        temp = temp.filter((item) => {
          return dateCompare(item.Data, from_date);
        });
      }
      if (to_date != "") {
        temp = temp.filter((item) => {
          return dateCompare(to_date, item.Data);
        });
      }
      if (type1 == true) {
        temp = temp.filter((item) => {
          return item.typology == "Movimento";
        });
      }
      if (type2 == true) {
        temp = temp.filter((item) => {
          return item.typology == "Prelievo da conto in cassa";
        });
      }
      if (type3 == true) {
        temp = temp.filter((item) => {
          return item.typology == "Acconto dato al locatore";
        });
      }
      if (type4 == true) {
        temp = temp.filter((item) => {
          return item.typology == "Acconto ricevuto da locatore";
        });
      }
      if (tutto == true) {
        temp = temp.filter((item) => {
          return item.Uscita != "" && item.Entrata != "";
        });
      }
      if (entrata == true) {
        temp = temp.filter((item) => {
          return item.Entrata != "";
        });
      }
      if (uscita == true) {
        temp = temp.filter((item) => {
          return item.Uscita != "";
        });
      }
      if (table_select == 0) {
        temp = temp.filter((item) => {
          return item.Conto.indexOf("Conto1") != -1;
        });
      }
      if (table_select == 1) {
        temp = temp.filter((item) => {
          return item.Conto.indexOf("Conto2") != -1;
        });
      }
      if (table_select == 2) {
        temp = temp.filter((item) => {
          return item.Conto.indexOf("Cassa") != -1;
        });
      }
      setFilteredDocument(temp);
    };
    filterFunc();
  }, [
    from_date,
    to_date,
    type1,
    type2,
    type3,
    type4,
    tutto,
    uscita,
    entrata,
    table_select,
  ]);
  // const filterFunc = () => {
  //   let temp = props.documents;
  //   if (from_date != "") {
  //     temp = temp.filter((item) => {
  //       return dateCompare(item.Data, from_date);
  //     });
  //   }
  //   if (to_date != "") {
  //     temp = temp.filter((item) => {
  //       return dateCompare(to_date, item.Data);
  //     });
  //   }
  //   setFilteredDocument(temp);
  // };

  return (
    <>
      <div className="filter">
        <p className="fs-14 fw-bold">Filtra per</p>
        <div className="dropdown">
          <button type="button" className="filter-btn">
            Data
          </button>
          <div className="dropdown-content">
            <div className="d-flex flex-column">
              <label className="f-label fs-16 mb-2">Dal</label>
              <div className="d-flex align-items-center justify-content-between border border-secondary px-3 rounded-3 border-opacity-50 mb-3">
                <Form.Control
                  className="border-0 fs-16 text-dark flex-grow-1"
                  max="9999-12-31"
                  value={from_date}
                  type="date"
                  onChange={(e) => {
                    setFromDate(e.target.value);
                  }}
                ></Form.Control>
              </div>
            </div>
            <div className="d-flex flex-column">
              <label className="f-label fs-16 mb-2">AI</label>
              <div className="d-flex align-items-center justify-content-between border border-secondary px-3 rounded-3 border-opacity-50 mb-3">
                <Form.Control
                  className="border-0 fs-16 text-dark flex-grow-1"
                  max="9999-12-31"
                  type="date"
                  value={to_date}
                  onChange={(e) => {
                    setToDate(e.target.value);
                  }}
                ></Form.Control>
              </div>
            </div>
            <div>
              <button
                className="back-btn btn-last rounded-3 shadow w-100 border-0 drowdown-content-btn"
                onClick={removeDate}
              >
                Rimuovi
              </button>
            </div>
          </div>
        </div>
        <div className="dropdown">
          <button type="button" className="filter-btn">
            Importo
          </button>
          <div className="dropdown-content">
            <div className="fs-16 fw-bold">IMPORTI</div>
            <div className="mt-2">
              {["checkbox"].map((type) => (
                <div key={`inline-${type}`} className="fs-14 mb-3">
                  <Form.Check
                    inline
                    label="Tutto"
                    name="group3"
                    type={type}
                    id={`inline-${type}-1`}
                    onChange={(e) => {
                      setTutto(e.target.checked);
                    }}
                  />
                </div>
              ))}
              {["checkbox"].map((type) => (
                <div key={`inline-${type}`} className="fs-14 mb-3">
                  <Form.Check
                    inline
                    label="Entrata"
                    name="group3"
                    type={type}
                    id={`inline-${type}-1`}
                    onChange={(e) => {
                      setEntrata(e.target.checked);
                    }}
                  />
                </div>
              ))}
              {["checkbox"].map((type) => (
                <div key={`inline-${type}`} className="fs-14 mb-3">
                  <Form.Check
                    inline
                    label="Uscita"
                    name="group3"
                    type={type}
                    id={`inline-${type}-1`}
                    onChange={(e) => {
                      setUscita(e.target.checked);
                    }}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="dropdown">
          <button type="button" className="filter-btn">
            Tipologia
          </button>
          <div className="dropdown-content">
            <div className="fs-16 fw-bold">TIPOLOGIA</div>
            <div className="mt-2">
              {["checkbox"].map((type) => (
                <div key={`inline-${type}`} className="fs-14 mb-3">
                  <Form.Check
                    inline
                    label="Movimento"
                    value="Movimento"
                    name="group3"
                    type={type}
                    id={`inline-${type}-1`}
                    onChange={(e) => {
                      setType1(e.target.checked);
                    }}
                  />
                </div>
              ))}
              {["checkbox"].map((type) => (
                <div key={`inline-${type}`} className="fs-14 mb-3">
                  <Form.Check
                    inline
                    label="Prelievo da conto in cassa"
                    value="Prelievo da conto in cassa"
                    name="group3"
                    type={type}
                    id={`inline-${type}-1`}
                    onChange={(e) => {
                      setType2(e.target.checked);
                    }}
                  />
                </div>
              ))}
              {["checkbox"].map((type) => (
                <div key={`inline-${type}`} className="fs-14 mb-3">
                  <Form.Check
                    inline
                    label="Acconto dato al locatore"
                    value="Acconto dato al locatore"
                    name="group3"
                    type={type}
                    id={`inline-${type}-1`}
                    onChange={(e) => {
                      setType3(e.target.checked);
                    }}
                  />
                </div>
              ))}
              {["checkbox"].map((type) => (
                <div key={`inline-${type}`} className="fs-14 mb-3">
                  <Form.Check
                    inline
                    label="Acconto ricevuto da locatore"
                    value="Acconto ricevuto da locatore"
                    name="group3"
                    type={type}
                    id={`inline-${type}-1`}
                    onChange={(e) => {
                      setType4(e.target.checked);
                    }}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="account-document">
        <div className="account">
          <Table className="account-table">
            <thead>
              <tr
                className={`${table_select == -1 ? "selected_tr" : ""}`}
                onClick={() => {
                  if (table_select != -1) {
                    setTableSelect(-1);
                  }
                }}
              >
                <th>Tutti i conti</th>
                <th>105,00€</th>
              </tr>
            </thead>
            <tbody>
              {account.map((item, index) => {
                return (
                  <tr
                    key={index}
                    onClick={() => {
                      if (table_select != index) {
                        setTableSelect(index);
                      } else setTableSelect(-1);
                    }}
                    className={table_select != index ? "" : "selected_tr"}
                  >
                    <td>{item}</td>
                    <td>{amount[index].toFixed(2) + "€"}</td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </div>
        <div className="document">
          <div className="document-card document-card-header">
            <p className="fs-14 fw-bold w-15p">Descrizione</p>
            <p className="fs-14 fw-bold w-15p">Data</p>
            <p className="fs-14 fw-bold w-15p">Conto</p>
            <p className="fs-14 fw-bold w-15p">Entrata</p>
            <p className="fs-14 fw-bold w-15p">Uscita</p>
            <p className="fs-14 fw-bold w-15p">Saldo</p>
          </div>
          {Object.keys(filtered_document).length != 0
            ? filtered_document.map((item, index) => {
                if (
                  item["Descrizione"]
                    .toLowerCase()
                    .indexOf(props.search_name.toLowerCase()) != -1
                ) {
                  return (
                    <Link
                      key={index}
                      to="modification-document"
                      className="text-dark"
                    >
                      <DocumentCard data={item} />
                    </Link>
                  );
                }
              })
            : ""}
        </div>
      </div>
    </>
  );
}
const mapStateToProps = (state) => ({
  documents: state.documentsReducer.documents,
});
export default connect(mapStateToProps, { changeDocuments })(Documents);
