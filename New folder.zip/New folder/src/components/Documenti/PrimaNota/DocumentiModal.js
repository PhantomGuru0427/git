import React, { useState } from "react";
import { BsCalendar2Event } from "react-icons/bs";
import Form from "react-bootstrap/Form";
import Movimento from "./Tipologia/Movimento";
import VersamentoTraCassaEConto from "./Tipologia/VersamentoTraCassaEConto";
import PrelievoDaContoInCassa from "./Tipologia/PrelievoDaContoInCassa";
import TrasferimenttoTraContiBancari from "./Tipologia/TrasferimenttoTraContiBancari";
import AccountoDatoAdUnLocatore from "./Tipologia/AccountoDatoAdUnLocatore";
import AccountoRicevutoDaUnLocatore from "./Tipologia/AccountoRicevutoDaUnLocatore";
import { BsPlusCircleFill } from "react-icons/bs";
import FileCard from "./Tipologia/FileCard";

export default function DocumentiModal(props) {
  const Tipologia = [
    "Movimento",
    "Versamento tra cassa e conto",
    "Prelievo da conto in cassa",
    "Trasferimento tra conti bancari",
    "Accounto dato ad un locatore",
    "Accounto ricevuto da un locatore",
  ];
  const [Tipologia_index, setTipologiaIndex] = useState(0);
  const [file, setFile] = useState("");
  const [file_name, setFileName] = useState("");
  const handleChange = (e) => {
    setFile(e.target.files);
    setFileName(e.target.files[0].name);
  };

  return (
    <div className="d-block w-100 mb-3">
      <div>
        <h2 className="fs-20 text-dark mb-2 fw-bold">Nuova Prima Nota</h2>
      </div>
      <Form>
        <div className="form-item-align-box d-block">
          <div className="label-heading my-4 d-block w-100">
            <div className="label-text rel d-inline-block py-2 px-2">
              <h1 className="fs-16 text-white text-uppercase fw-semibold">
                TIPOLOGIA
              </h1>
            </div>
          </div>
          <div className="d-block">
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Tipologia
                </label>
                <select
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white"
                  onChange={(e) => {
                    setTipologiaIndex(e.target.value);
                  }}
                >
                  {Tipologia.map((menu, index) => {
                    return (
                      <option key={index} value={index}>
                        {menu}
                      </option>
                    );
                  })}
                </select>
              </div>
            </div>
            {Tipologia_index == 0 ? (
              <div>
                <Movimento />
              </div>
            ) : Tipologia_index == 1 ? (
              <VersamentoTraCassaEConto />
            ) : Tipologia_index == 2 ? (
              <PrelievoDaContoInCassa />
            ) : Tipologia_index == 3 ? (
              <TrasferimenttoTraContiBancari />
            ) : Tipologia_index == 4 ? (
              <AccountoDatoAdUnLocatore />
            ) : Tipologia_index == 5 ? (
              <AccountoRicevutoDaUnLocatore />
            ) : (
              <AccountoRicevutoDaUnLocatore />
            )}
            {file_name != "" ? (
              <FileCard name={file_name} setFileName={setFileName} />
            ) : (
              ""
            )}
            <label htmlFor="input-file" className="black-link mt-2">
              <BsPlusCircleFill className="plus-icon" />
              Aggiungi allegati
            </label>
            <input
              type="file"
              id="input-file"
              className="d-none"
              multiple={false}
              onChange={handleChange}
            ></input>
            <div className="col-12">
              <div className="d-flex align-items-center mt-5 form-last-btns">
                <button
                  type="button"
                  className="back-btn btn-last rounded-3 shadow w-193 me-2 border-0"
                  onClick={() => {
                    props.setShow(false);
                  }}
                >
                  Annulla
                </button>
                <button
                  type="button"
                  className="next-btn btn-last rounded-3 shadow w-193 border-0"
                >
                  Salva
                </button>
              </div>
            </div>
          </div>
        </div>
      </Form>
    </div>
  );
}
