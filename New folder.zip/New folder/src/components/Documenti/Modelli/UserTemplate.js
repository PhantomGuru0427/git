import React, { useState } from "react";
import search from "../../../assets/images/search.svg";
import download from "../../../assets/images/download.svg";
import edit from "../../../assets/images/edit.svg";
import delete_icon from "../../../assets/images/delete.svg";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import url from "../../../assets/scan876.pdf";
import { Logger } from "logging-library";
import FileViewer from "react-file-viewer";
import { CustomErrorComponent } from "custom-error";
import { connect } from "react-redux";
import { changeUserTemplate } from "../../../actions/userTemplateAction";
import CheckBtn from "../../../assets/images/check_btn.svg";
import CloseBtn from "../../../assets/images/close_btn.svg";

function UserTemplate(props) {
  const [preview_modal_show, setPreviewModalShow] = useState(false);
  const previewModalClose = () => setPreviewModalShow(false);
  const previewModalShow = () => setPreviewModalShow(true);
  const [change_state, setChangeState] = useState(false);
  const type = "pdf";
  const onError = (e) => {
    Logger.logError(e, "error in file-viewer");
  };
  const [new_template_name, setNewTemplateName] = useState(props.name);
  const changeTemplateName = () => {
    setChangeState(false);
    if (new_template_name != props.name) {
      let initial_user_template = props.user_template;
      initial_user_template[props.section_name][
        initial_user_template[props.section_name].indexOf(props.name)
      ] = new_template_name;
      props.changeUserTemplate(initial_user_template);
    }
  };
  const deleteTemplate = () => {
    let initial_user_template = props.user_template;
    initial_user_template[props.section_name] = initial_user_template[
      props.section_name
    ].filter((item) => item !== props.name);
    if (initial_user_template[props.section_name].length == 0) {
      delete initial_user_template[props.section_name];
    }
    console.log("kkkk", initial_user_template);
    props.changeUserTemplate(initial_user_template);
  };

  return (
    <>
      <div className="template-card">
        <input
          type="text"
          className="fs-16 text-dark card-input flex-auto fw-bold"
          disabled={change_state ? false : true}
          value={new_template_name}
          onChange={(e) => {
            setNewTemplateName(e.target.value);
          }}
        />
        <div className={`icon-btn-group ${change_state ? "d-none" : ""}`}>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={previewModalShow}
          >
            <img src={search} alt="icon" />
          </button>
          <button type="button" className="btn round-icon-btn">
            <img src={download} alt="icon" />
          </button>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={() => {
              setChangeState(true);
            }}
          >
            <img src={edit} alt="icon" />
          </button>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={deleteTemplate}
          >
            <img src={delete_icon} alt="icon" />
          </button>
        </div>
        <div className={`icon-btn-group ${change_state ? "" : "d-none"}`}>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={changeTemplateName}
          >
            <img src={CheckBtn} alt="check-icon" />
          </button>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={() => {
              setChangeState(false);
              setNewTemplateName(props.name);
            }}
          >
            <img src={CloseBtn} alt="check-icon" />
          </button>
        </div>
      </div>
      <Modal
        show={preview_modal_show}
        onHide={previewModalClose}
        className="preview-screen"
      >
        <Button
          variant=""
          onClick={previewModalClose}
          className="modal-close-btn"
        >
          <i className="fal fa-times modal-close-icon"></i>
        </Button>
        <Modal.Body>
          {/* <FileViewer
            fileType={type}
            filePath={url}
            errorComponent={CustomErrorComponent}
            onError={onError}
          /> */}
          <FileViewer
            fileType={"docx"}
            filePath={"http://localhost:5173/file-sample_100kB.docx"}
            errorComponent={CustomErrorComponent}
            onError={onError}
          />
        </Modal.Body>
      </Modal>
    </>
  );
}
const mapStateToProps = (state) => ({
  user_template: state.userTemplateReducer.user_template,
});

export default connect(mapStateToProps, { changeUserTemplate })(UserTemplate);
