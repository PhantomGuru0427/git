import React from "react";
import CloseBtn from "../../../assets/images/close.svg";

export default function FileLoadCard(props) {
  return (
    <div className="file-load-card mt-3">
      <p className="fs-18">{props.name}</p>
      <div className="icon-btn-group">
        <img src={CloseBtn} alt="icon" />
      </div>
    </div>
  );
}
