import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import ServerSectionCard from "./ServerSectionCard";
import UserSectionCard from "./UserSectionCard";
import NewSectionModal from "./NewSectionModal";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { BsChevronLeft } from "react-icons/bs";
import { connect } from "react-redux";

function AddSectionModal(props) {
  const server_sections = ["Consensi e deleghe", "Affitti"];
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [search_name, setSearchName] = useState("");
  const modalBack = () => {
    props.setDisplay(false);
    handleClose();
  };
  const nextModal = () => {
    props.setDisplay(true);
    handleShow();
  };
  return (
    <>
      <div className="d-block w-100 mb-3 mt-4">
        <div>
          <h2 className="fs-20 text-dark mb-2 fw-bold">Sezioni </h2>
        </div>
      </div>
      <Form className="form-content">
        <div className="d-flex align-item-center justify-content-between flex-wrap mb-3">
          <div className="flex-shrink-0 flex-auto">
            <button
              type="button"
              className="documenti-owner-btn fs-16 back-btn rounded-3 shadow w-193 me-2 border-0"
              onClick={nextModal}
            >
              Nuovo
            </button>
          </div>
          <div className="flex-shrink-0 flex-auto">
            <div className="search-fence d-flex align-items-center bg-white p-2 border-opacity-50 border-secondary border rounded-3 overflow-hidden">
              <i className="fal fa-search flex-shrink-0 me-2 text-secondary opacity-50"></i>
              <input
                type="text"
                name=""
                placeholder="Cerca"
                className="flex-grow-1 border-0 w-100 fs-14"
                onChange={(e) => setSearchName(e.target.value)}
              />
            </div>
          </div>
        </div>
        <div className="d-block card-list">
          {server_sections.map((menu, index) => {
            if (menu.toLowerCase().indexOf(search_name.toLowerCase()) != -1) {
              return <ServerSectionCard key={index} name={menu} />;
            } else return "";
          })}
          {Object.keys(props.user_template).map((menu, index) => {
            if (menu.toLowerCase().indexOf(search_name.toLowerCase()) != -1) {
              return <UserSectionCard key={index} name={menu} />;
            } else return "";
          })}
        </div>
        <Modal show={show} className="small-modal" backdrop="static">
          <Modal.Body className="p-5">
            <label
              className="float-start black-link mt-2 back-icon"
              onClick={modalBack}
            >
              <BsChevronLeft />
              Indietro
            </label>
            <NewSectionModal modalBack={modalBack} />
          </Modal.Body>
        </Modal>
      </Form>
    </>
  );
}
const mapStateToProps = (state) => ({
  user_template: state.userTemplateReducer.user_template,
});
export default connect(mapStateToProps, null)(AddSectionModal);
