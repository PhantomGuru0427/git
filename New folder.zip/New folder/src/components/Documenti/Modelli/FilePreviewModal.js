import React from "react";
import { Logger } from "logging-library";
import FileViewer from "react-file-viewer";
import { CustomErrorComponent } from "custom-error";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";

export default function FilePreviewModal(props) {
  const type = "pdf";
  const [view, setView] = useState(false);
  const handleView = () => {
    setView(!view);
  };

  const onError = (e) => {
    Logger.logError(e, "error in file-viewer");
  };
  return (
    <>
      <Modal show={show} onHide={handleClose} backdrop="static">
        <Modal.Body className="p-5">
          <Button
            variant=""
            onClick={handleClose}
            className="float-end border-0 bg-white"
          >
            <i className="fal fa-times"></i>
          </Button>
          {/* <ModifyDocument show={show} setShow={setShow} /> */}
          <FileViewer
            fileType={props.type}
            filePath={props.url}
            errorComponent={CustomErrorComponent}
            onError={onError}
          />
        </Modal.Body>
      </Modal>
    </>
  );
}
