import React, { useState } from "react";
import search from "../../../assets/images/search.svg";
import download from "../../../assets/images/download.svg";

import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import url from "../../../assets/scan876.pdf";
import { Logger } from "logging-library";
import FileViewer from "react-file-viewer";
import { CustomErrorComponent } from "custom-error";

export default function ServerTemplate(props) {
  const [preview_modal_show, setPreviewModalShow] = useState(false);
  const previewModalClose = () => setPreviewModalShow(false);
  const previewModalShow = () => setPreviewModalShow(true);

  const type = "pdf";
  const onError = (e) => {
    Logger.logError(e, "error in file-viewer");
  };

  return (
    <div className="template-card">
      <p className="fs-16 fw-bold">{props.name}</p>
      <div className="icon-btn-group">
        <button
          type="button"
          className="btn round-icon-btn"
          onClick={previewModalShow}
        >
          <img src={search} alt="icon" />
        </button>
        <button type="button" className="btn round-icon-btn">
          <img src={download} alt="icon" />
        </button>
      </div>
      <Modal
        show={preview_modal_show}
        onHide={previewModalClose}
        className="preview-screen"
      >
        <Button
          variant=""
          onClick={previewModalClose}
          className="modal-close-btn"
        >
          <i className="fal fa-times modal-close-icon"></i>
        </Button>
        <Modal.Body>
          <FileViewer
            fileType={type}
            filePath={url}
            errorComponent={CustomErrorComponent}
            onError={onError}
          />
        </Modal.Body>
      </Modal>
    </div>
  );
}
