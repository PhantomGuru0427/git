import React, { useState } from "react";
import AddIcon from "../../../assets/images/add.svg";
import FileLoadCard from "./FileLoadCard";

export default function UploadBtn() {
  const [file, setFile] = useState([]);
  const [dragActive, setDragActive] = useState(false);

  const handleChange = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setFile(e.target.files);
  };

  // handle drag events
  const handleDrag = function (e) {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  // triggers when file is dropped
  const handleDrop = function (e) {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files);
    }
  };

  return (
    <div className="upload-div mt-3 mb-3">
      <button
        type="button"
        className={dragActive ? "drag-active btn upload-btn" : "btn upload-btn"}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <img src={AddIcon} alt="Image No"></img>
        <p className="fs-20 text-secondary text-center fw-bold">
          Trascina qui il tuo file o &nbsp;
          <label htmlFor="input-file" className="input-file-label">
            clicca per caricare
          </label>
          <input
            type="file"
            id="input-file"
            className="d-none"
            multiple={true}
            onChange={handleChange}
          ></input>
        </p>
        <p className="fs-12 text-secondary text-center fw-bold">
          Formati supportati: doc, docx, pages
        </p>
      </button>
      {file.length > 0 ? <FileLoadCard name={file[0].name} /> : ""}
      
    </div>
  );
}
