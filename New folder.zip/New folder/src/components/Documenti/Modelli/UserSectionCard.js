import React, { useState } from "react";
import edit from "../../../assets/images/edit.svg";
import delete_icon from "../../../assets/images/delete.svg";
import { connect } from "react-redux";
import { changeUserTemplate } from "../../../actions/userTemplateAction";
import CheckBtn from "../../../assets/images/check_btn.svg";
import CloseBtn from "../../../assets/images/close_btn.svg";

function UserSectionCard(props) {
  const [name, setName] = useState(props.name);
  const [change_state, setChangeState] = useState(false);
  const renameSection = () => {
    setChangeState(false);
    if (name != props.name) {
      let initial_user_template = {};
      for (var i = 0; i < Object.keys(props.user_template).length; i++) {
        if (Object.keys(props.user_template)[i] == props.name)
          initial_user_template = {
            ...initial_user_template,
            [name]: props.user_template[props.name],
          };
        else {
          initial_user_template = {
            ...initial_user_template,
            [Object.keys(props.user_template)[i]]:
              props.user_template[Object.keys(props.user_template)[i]],
          };
        }
      }
      props.changeUserTemplate(initial_user_template);
    }
  };

  const deleteSection = () => {
    let initial_user_template = props.user_template;
    delete initial_user_template[props.name];
    props.changeUserTemplate(initial_user_template);
  };
  return (
    <>
      <div className="section-card">
        <input
          type="text"
          className="fs-16 text-dark card-input flex-auto"
          disabled={change_state ? false : true}
          value={name}
          onChange={(e) => {
            setName(e.target.value);
          }}
        />
        <div className={`icon-btn-group ${change_state ? "d-none" : ""}`}>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={() => {
              setChangeState(true);
            }}
          >
            <img src={edit} alt="icon" />
          </button>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={deleteSection}
          >
            <img src={delete_icon} alt="icon" />
          </button>
        </div>
        <div className={`icon-btn-group ${change_state ? "" : "d-none"}`}>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={renameSection}
          >
            <img src={CheckBtn} alt="check-icon" />
          </button>
          <button
            type="button"
            className="btn round-icon-btn"
            onClick={() => {
              setChangeState(false);
              setName(props.name);
            }}
          >
            <img src={CloseBtn} alt="check-icon" />
          </button>
        </div>
      </div>
    </>
  );
}
const mapStateToProps = (state) => ({
  user_template: state.userTemplateReducer.user_template,
});
export default connect(mapStateToProps, { changeUserTemplate })(
  UserSectionCard
);
