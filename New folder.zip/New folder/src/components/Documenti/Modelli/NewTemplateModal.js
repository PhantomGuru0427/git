import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import { BsPlusCircleFill } from "react-icons/bs";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import UploadBtn from "./UploadBtn";
import AddSectionModal from "./AddSectionModal";
import { connect } from "react-redux";
import { changeUserTemplate } from "../../../actions/userTemplateAction";

function NewTemplateModal({
  show,
  setShow,
  changeUserTemplate,
  user_template,
}) {
  const [section_name, setSectionName] = useState(
    Object.keys(user_template)[0]
  );
  const [template_name, setTemplateName] = useState("");

  const setTemplateInfo = () => {
    let initial_user_template = user_template;
    var flag = 0;
    for (var i = 0; i < Object.keys(initial_user_template).length; i++) {
      if (section_name == Object.keys(initial_user_template)[i]) {
        initial_user_template[Object.keys(initial_user_template)[i]].push(
          template_name
        );
        flag = 1;
        break;
      }
    }
    if (flag == 0)
      initial_user_template = {
        ...user_template,
        [section_name]: [template_name],
      };
    changeUserTemplate(initial_user_template);
    shutdownModal();
  };
  const [show1, setShow1] = useState(false);
  const [display, setDisplay] = useState(false);
  const handleClose = () => setShow1(false);
  const handleShow = () => setShow1(true);
  const shutdownModal = () => {
    setShow(false);
  };

  return (
    <>
      <div className="d-block w-100 mb-3 mt-5">
        <div>
          <h2 className="fs-20 text-dark mb-2 fw-bold">Nuovo modello</h2>
        </div>
      </div>
      <Form>
        <div className="form-item-align-box d-block">
          <div className="d-block">
            <div className="col-md-12">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Sezione di riferimento
                </label>
                <div className="d-flex align-items-center justify-content-between">
                  <select
                    className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white flex-auto"
                    onChange={(e) => {
                      setSectionName(e.target.value);
                    }}
                  >
                    {Object.keys(user_template).map((menu, index) => {
                      return (
                        <option key={index} value={menu}>
                          {menu}
                        </option>
                      );
                    })}
                  </select>
                  <BsPlusCircleFill
                    className="plus-button add-section-btn"
                    onClick={handleShow}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="mt-3">
            <div className="d-flex flex-column">
              <label className="f-label fs-16 mb-2">Nome modello</label>
              <input
                type="text"
                className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                onChange={(e) => {
                  setTemplateName(e.target.value);
                }}
              />
            </div>
          </div>
          <UploadBtn />
          <div className="form-last-btns">
            <button
              type="button"
              className="light-btn btn-last rounded-3 shadow me-2 border-0 col-md-12 add-btn"
              disabled={template_name != "" ? false : true}
              onClick={setTemplateInfo}
            >
              Aggiungi
            </button>
            <button
              type="button"
              className="back-btn btn-last rounded-3 shadow border-0 col-md-12 mt-3"
              onClick={shutdownModal}
            >
              Annulla
            </button>
          </div>
        </div>
        <div className="scroller">
          <Modal
            show={show1}
            className={display ? "d-none" : "small-modal"}
            onHide={handleClose}
            backdrop="static"
          >
            <Modal.Body className="p-4">
              <Button
                variant=""
                onClick={handleClose}
                className="float-end border-0 bg-white"
              >
                <i className="fal fa-times"></i>
              </Button>
              <AddSectionModal setDisplay={setDisplay} />
            </Modal.Body>
          </Modal>
        </div>
      </Form>
    </>
  );
}
const mapStateToProps = (state) => ({
  user_template: state.userTemplateReducer.user_template,
});
export default connect(mapStateToProps, { changeUserTemplate })(
  NewTemplateModal
);
