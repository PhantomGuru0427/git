import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import { connect } from "react-redux";
import { changeUserTemplate } from "../../../actions/userTemplateAction";
function NewSectionModal(props) {
  const [section_name, setSectionName] = useState("");
  const addSection = () => {
    let initial_user_tempalte = props.user_template;
    initial_user_tempalte = { ...initial_user_tempalte, [section_name]: [] };
    props.changeUserTemplate(initial_user_tempalte);
    props.modalBack();
  };
  return (
    <>
      <div className="section-modal-container">
        <div className="d-block w-100 mb-3 mt-5">
          <div>
            <h2 className="fs-20 text-dark mb-2 fw-bold">Nuova sezione</h2>
          </div>
        </div>
        <Form>
          <div className="form-item-align-box d-block">
            <div className="mt-3">
              <div className="d-flex flex-column">
                <label className="f-label fs-16 mb-2">Nome</label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) => {
                    setSectionName(e.target.value);
                  }}
                />
              </div>
            </div>
            <div className="form-last-btns mt-3 section-modal-btn">
              <button
                type="button"
                className="next-btn btn-last rounded-3 shadow me-2 border-0 col-md-12"
                disabled={section_name != "" ? false : true}
                onClick={addSection}
              >
                Crea
              </button>
              <button
                type="button"
                className="black-btn btn-last rounded-3 shadow border-0 col-md-12 mt-3"
                onClick={() => {
                  props.modalBack();
                }}
              >
                Annulla
              </button>
            </div>
          </div>
        </Form>
      </div>
    </>
  );
}
const mapStateToProps = (state) => ({
  user_template: state.userTemplateReducer.user_template,
});
export default connect(mapStateToProps, { changeUserTemplate })(
  NewSectionModal
);
