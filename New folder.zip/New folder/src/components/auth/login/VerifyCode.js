import React, { useState } from "react";
import LeftPanel from "../../LeftPanel";
import "../../../assets/css/RecoverPassword.css";

import ReturnIcon from "../../../assets/images/returnIcon.svg";
import ErrorIcon from "../../../assets/images/input_error.svg";

import { useNavigate } from "react-router";

export default function VerifyCode() {
  const navigate = useNavigate();
  const [error, setError] = useState(false);
  const [verifyCode, setVerifyCode] = useState("");

  const returnLogin = () => {
    navigate("/");
  };

  const onChange = async (e) => {
    setVerifyCode(e.target.value);
  };

  const onSubmit = async (e) => {
    const res = false;
    if (res === true) {
      setError(true);
    } else {
      setError(false);
      navigate("/newPassword");
    }

    e.preventDefault();
  };

  return (
    <div className="d-flex" style={{height: "100vh"}}>
      <LeftPanel />
      <div className="m-auto">
        <div className="return-login" onClick={() => returnLogin()}>
          <img
            src={ReturnIcon}
            alt="return"
            style={{ marginRight: "17.6px" }}
          ></img>
          Torna al login
        </div>
        <div className="recover-text">Verifica codice</div>
        <div className="recover-text2">
          Abbiamo inviato un codice al tuo indirizzo email
        </div>
        <div className="recover-text2">
          bob******@gmail.com. Inserisci il codice ricevuto
        </div>
        <div className="recover-text2">nel campo sottostante.</div>
        {error && (
          <div className="emailtypeError-div">
            <img
              src={ErrorIcon}
              alt="input_error"
              style={{ marginRight: "22px", marginLeft: "32px" }}
            ></img>
            L’email inserita non è corretta
          </div>
        )}
        <div className="recover-subtitle">Codice di recupero</div>
        <form onSubmit={onSubmit}>
          <input
            type="text"
            placeholder="Inserisci il codice"
            value={verifyCode}
            onChange={onChange}
            className="form-control password-form"
          />
          <input
            type="submit"
            className="recover-btn"
            value="Verifica Codice"
          />
        </form>
        <div
          style={{
            width: "300px",
            textAlign: "center",
            margin: "auto",
            paddingTop: "30px",
          }}
        >
          <div className="resend-code">Hai dimenticato la password?</div>
        </div>
      </div>
    </div>
  );
}
