import React, { useState, useEffect } from "react";
import "../../../assets/css/Login.css";
import "bootstrap/dist/css/bootstrap.min.css";

import ErrorIcon from "../../../assets/images/input_error.svg";

import ToggleSwitch from "../../ToggleSwitch";
import { BsEye, BsEyeSlash } from "react-icons/bs";
import { Link, useNavigate, useParams } from "react-router-dom";

import ModalForVerify from "./ModalForVerify";
import ModalForEnterCode from "../register/ModalForEnterCode";

import { useDispatch, connect } from "react-redux";
import { setShow } from "../../../actions/ModalForVerify";
import { setShowEnterCode } from "../../../actions/ModalForEnterCode";

import * as Yup from "yup";
import LeftPanel from "../../LeftPanel";

import VerificaCodice from "../reset_password/verifica-codice.tsx";
import AuthService from "../services/auth.service.ts";

const Login = ({ show }) => {
  const dispatch = useDispatch();
  let navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [codice, setCodice] = useState("");

  const [error, setError] = useState(false);
  const [readyLogin, setReadyLogin] = useState(false);

  const { email, password } = formData;

  // const validationSchema = () => {
  //   return Yup.object().shape({
  //     email: Yup.string().required("Campo Obbligatorio!"),
  //     password: Yup.string().required("Campo Obbligatorio!"),
  //   });
  // }

  // const handleLogin = (email, password) => {
  //   setMessage('');
  //   setLoading(true);

  //   //Finire la gestionedelle chiamate per il login
  //   AuthService.login(email, password).then(
  //     () => {
  //       handleShow();
  //       /* this.props.history.push("/profile");
  //       window.location.reload(); */
  //       //Dovra' diventare la dashboard
  //       /* let navigate = useNavigate();
  //       navigate("/profile", { replace: true }); */
  //     },
  //     (error) => {
  //       const resMessage =
  //         (error.response &&
  //           error.response.data &&
  //           error.response.data.message) ||
  //         error.message ||
  //         error.toString();

  //         setLoading(false);
  //         setMessage(resMessage);
  //     }
  //   );
  // }

  // const handleValueCodice= (code) => {
  //   setCodice(code);
  //   /*  AuthService.signUpVerify() */
  //   AuthService.loginVerify(email, password, code).then(
  //     (response) => {
  //       console.log("response:", response.data);
  //       if (response.data?.return_value) {
  //         dispatch(setShow(false));
  //         navigate("/", { replace: true });
  //         //Redirect alla dashboard
  //       } else {
  //         //Errore nel form, gestirlo in qualche maniera
  //       }
  //     },
  //     (error) => {
  //       const resMessage =
  //         (error.response &&
  //           error.response.data &&
  //           error.response.data.message) ||
  //         error.message ||
  //         error.toString();

  //       setMessage(resMessage);
  //     }
  //   );
  // }

  const { mode } = useParams();

  useEffect(() => {
    if (formData.email.length === 0 || formData.password.length === 0) {
      setReadyLogin(false);
    } else {
      setReadyLogin(true);
    }
  }, [formData]);

  const handleShow = () => dispatch(setShow(true));

  const isValidEmail = (email) => {
    return /\S+@\S+\.\S+/.test(email);
  };

  const isValidPassword = (password) => {
    if (password.length === 0) {
      return false;
    } else {
      return true;
    }
  };

  const onChange = async (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    if (!isValidEmail(formData.email) || !isValidPassword(formData.password)) {
      setError(true);
    } else {
      setError(false);
      handleShow();
    }

    e.preventDefault();
  };

  const create = () => {
    dispatch(setShowEnterCode(true));
  };

  const [passwordType, setPasswordType] = useState("password");

  const togglePassword = () => {
    if (passwordType === "password") {
      setPasswordType("text");
      return;
    }
    setPasswordType("password");
  };

  return (
    <div>
      <div className="mobile-background">
        <div className="logo-mobile-div"></div>
        <div className="d-flex login-div" style={{ background: "#fff" }}>
          <LeftPanel />
          <div className="rightPanel">
            <div>
              <div className="welcome-title">Bentornato</div>
              <div className="welcome-description">
                Effettua il login per accedere alla tua area personale
              </div>
              <div
                className="title m-auto"
                style={{ paddingTop: "15px", paddingBottom: "10px" }}
              >
                Login
              </div>
              {error && (
                <div className="error-div">
                  <img
                    src={ErrorIcon}
                    alt="Input error"
                    style={{
                      height: "17.69px",
                      width: "20.53",
                      paddingLeft: "20px",
                      paddingRight: "10px",
                    }}
                  />
                  <div>L’email o la password inserita non è corretta</div>
                </div>
              )}
              <div className="subtitle">Email</div>
              <form className="form" onSubmit={onSubmit}>
                <input
                  type="email"
                  placeholder="Inserisci la tua email"
                  name="email"
                  value={email}
                  onChange={onChange}
                  id={error ? "input_error" : ""}
                  className="form-control"
                  style={{ fontFamily: "Mulish", height: "50px" }}
                />
                <div className="subtitle">Password</div>
                <div style={{ position: "relative" }}>
                  <input
                    type={passwordType}
                    placeholder="Inserisci la tua password"
                    name="password"
                    value={password}
                    onChange={onChange}
                    minLength="4"
                    id={error ? "input_error" : ""}
                    className="form-control"
                    style={{
                      marginBottom: "20px",
                      fontFamily: "Mulish",
                      height: "50px",
                    }}
                  />
                  <div onClick={togglePassword} className="passwordHideToggle">
                    {passwordType === "password" ? <BsEye /> : <BsEyeSlash />}
                  </div>
                </div>
                <ToggleSwitch label="Ricordami su questo computer" />
                <input
                  type={readyLogin ? "submit" : "button"}
                  id={readyLogin ? "" : "disable-login"}
                  className="login-btn"
                  value="Accedi"
                />
              </form>
              <div
                style={{
                  textAlign: "center",
                  margin: "auto",
                  paddingTop: "30px",
                }}
              >
                <Link to="/recover" className="reset-password">
                  Hai dimenticato la password?
                </Link>
              </div>
              <div
                className="row"
                style={{ justifyContent: "center", paddingTop: "30px" }}
              >
                <hr className="col-4" style={{ marginTop: "12px" }}></hr>
                <div
                  className="col-3"
                  style={{ textAlign: "center", color: "#696F79" }}
                >
                  Oppure
                </div>
                <hr className="col-4" style={{ marginTop: "12px" }}></hr>
              </div>
              <div
                className="createAccount-btn"
                style={{ color: "#000000" }}
                onClick={() => create()}
              >
                Crea il tuo account
              </div>
              <ModalForVerify />
              <ModalForEnterCode mode={mode} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const mapStateToProps = (state) => ({
  show: state.ModalForVerify.show,
});

export default connect(mapStateToProps, { setShow })(Login);
