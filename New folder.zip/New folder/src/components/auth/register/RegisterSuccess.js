import React from "react";
import logo from "../../../assets/images/logo2.png";
import SuccessLogo from "../../../assets/images/success.png";

import "../../../assets/css/RegisterSuccess.css";
import Footer from "../../Footer";

export default function RegisterSuccess() {
  return (
    <>
      <div className="register-div">
        <img src={logo} alt="logo" className="register-logo"></img>
        <div style={{ height: "84vh", display: "flex" }}>
          <div className="m-auto">
            <div className="register-title">Crea il tuo account</div>
            <img
              src={SuccessLogo}
              style={{ display: "flex", margin: "auto" }}
            ></img>
            <div className="register-success-subtitle">
              Benvenuto [username], la tua email è stata confermata
            </div>
            <div className="register-success-description">
              Nelle prossime 24/48 ore feriali un nostro operatore verificherà
              la correttezza dei documenti caricati. Una volta confermati,
              potrai avvalerti del servizio di notarizzazione.
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
