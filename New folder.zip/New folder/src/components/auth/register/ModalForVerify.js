import React, { useState } from "react";
import logo2 from "../../../assets/images/logo2.png";
import { Modal } from "react-bootstrap";
import { useDispatch, connect } from "react-redux";
import { setShow } from "../../../actions/ModalForVerify";
import "../../../assets/css/ModalForVerify.css";
import InputError from "../../../assets/images/input_error.svg";
import { useNavigate } from "react-router";

const ModalForVerify = ({ show, acrossSms = false }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [error, setError] = useState(false);
  const [alowSend, setAlowSend] = useState(false);
  const [smsSuccess, setSmsSuccess] = useState(acrossSms);

  const handleClose = () => {
    dispatch(setShow(false));
    setError(false);
  };
  const [verifyCode, setVerifyCode] = useState("");

  const onSubmit = async (e) => {
    /*You can add conditions to identify success for verification*/
    if (verifyCode.length === 0) {
      setError(true);
    } else {
      setError(false);
      setSmsSuccess(true);
    }

    e.preventDefault();
  };

  const verifyCodeChange = (e) => {
    setVerifyCode(e.target.value);
    if (e.target.value.length === 0) {
      setAlowSend(false);
    } else {
      setAlowSend(true);
    }
  };

  const registerSuccess = () => {
    navigate('/registerSuccess');
  };

  return (
    <Modal
      show={show}
      onHide={handleClose}
      aria-labelledby="contained-modal-title-vcenter"
      centered
      className="verify-Modal"
    >
      <Modal.Header closeButton style={{ borderBottom: "0 none" }} />
      <Modal.Body>
        <img
          src={logo2}
          alt="logo"
          style={{
            paddingBottom: "15px",
            margin: "auto",
            display: "flex",
          }}
        />
        <div className="titleOTP-div">
          <div style={{ paddingBottom: "10px" }}>
            {smsSuccess ? "Controlla la tua casella email" : "Inserisci OTP"}
          </div>
          <div className="verify-description-div">
            {smsSuccess
              ? "Ti abbiamo appena inviato una e-mail di conferma a bob****@gmail.com L'email contiene un link che dovrai aprire per confermare la validità dell'indirizzo da te fornito. Una volta confermato si notorizzerà l’intero processo di registrazione."
              : "Ti abbiamo inviato l’OTP di 6 cifre al numero 329******367 Inseriscilo nel campo sottostante per verificare il tuo numero"}
          </div>

          <form className="form" onSubmit={onSubmit}>
            {smsSuccess ? (
              <div></div>
            ) : (
              <input
                type="text"
                placeholder="Inserisci OTP"
                name="text"
                value={verifyCode}
                onChange={verifyCodeChange}
                id={error ? "otp_input_error" : ""}
                className="form-control"
                style={{
                  fontFamily: "Mulish",
                  height: "50px",
                  border: "1px solid #BDBDBD",
                }}
              />
            )}
            {error && (
              <div className="opt_error_msg">
                <img src={InputError} alt="input_error"></img>
                <div style={{ paddingLeft: "10px" }}>
                  Il codice inserito non è corretto
                </div>
              </div>
            )}
            {smsSuccess ? (
              <div
                className="confirm-emailLink-div"
                onClick={() => registerSuccess()}
              >
                Ok
              </div>
            ) : (
              <input
                type="submit"
                id={alowSend ? "active-submit" : ""}
                className="confirm-btn-div"
                value="Continua"
                style={{ marginTop: "10px" }}
              />
            )}
          </form>
          {smsSuccess ? (
            <div className="resend-div">Invia di nuovo l’email</div>
          ) : (
            <div className="resend-div">Invia nuovamente l’OTP</div>
          )}
        </div>
      </Modal.Body>
    </Modal>
  );
};

const mapStateToProps = (state) => ({
  show: state.ModalForVerify.show,
});

export default connect(mapStateToProps, { setShow })(ModalForVerify);
