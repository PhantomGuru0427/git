import React, { forwardRef, useEffect, useState } from "react";
import "../../../assets/css/Tabs.css";
import ImportFile from "../../../assets/images/addimport-file.png";
import FaceId from "../../../assets/images/face_id.png";
import PencilEdit from "../../../assets/images/pencil_edit.svg";
import ClickCamera from "../../../assets/images/camera-circle.png";

import UploadBtn from "../../UploadBtn";
import ModalForVerify from "./ModalForVerify";
import { useNavigate, Link } from "react-router-dom";
import Webcam from "react-webcam";
import { useDispatch, connect } from "react-redux";
import { setShow } from "../../../actions/ModalForVerify";
import axios from "axios";
import Form from 'react-bootstrap/Form';

const Tabs = ({ show }) => {
  const [count, setCount] = useState(1);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const forward = () => {
    var num = count;
    if (num <= 6) {
      setCount(++num);
    }
  };

  const backward = () => {
    var num = count;
    if (num > 1) {
      setCount(--num);
    }
  };

  const confirm = () => {
    dispatch(setShow(true));
  };

  const returnLogin = () => {
    navigate(-1);
  };

  const tab1Click = () => {
    setCount(1);
  };
  const tab2Click = () => {
    setCount(2);
  };
  const tab3Click = () => {
    setCount(3);
  };
  const tab4Click = () => {
    setCount(4);
  };
  const tab5Click = () => {
    setCount(5);
  };
  const tab6Click = () => {
    setCount(6);
  };

  return (
    <>
      <div className="tabs-div">
        <div className="tab-icon" onClick={() => tab1Click()}>
          <div className="desktop-icon">
            <svg style={{ width: "170px", height: "58px" }}>
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M2.5 5C2.5 2.79086 4.29086 1 6.5 1H149.179C150.614 1 151.94 1.76914 152.652 3.01544L166.366 27.0154C167.069 28.2452 167.069 29.7548 166.366 30.9846L152.652 54.9846C151.94 56.2309 150.614 57 149.179 57H6.5C4.29086 57 2.5 55.2091 2.5 53V5Z"
                fill={count > 0 ? (count > 1 ? "#83112F" : "#FFF8F8") : "#fff"}
                stroke={count > 0 ? "#83112F" : "#C1C9D2"}
              />
            </svg>
            <div
              className={"tab-icon-title1"}
              style={{
                color:
                  count > 0 ? (count > 1 ? "#FFF8F8" : "#83112F") : "#3C4257",
              }}
            >
              Registrazione
            </div>
          </div>
          <div
            className="mobile-icon"
            style={{ position: "relative", width: "40px" }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <svg height="20" width="20">
                <ellipse
                  cx="10"
                  cy="10"
                  rx="10"
                  ry="10"
                  fill="#F1E2E2CF"
                  style={{ margin: "auto", display: count === 1 ? "" : "none" }}
                />
                Sorry, your browser does not support inline SVG.
              </svg>
              <svg
                height="10"
                width="10"
                style={{
                  position: "absolute",
                }}
              >
                <ellipse
                  cx="5"
                  cy="5"
                  rx="5"
                  ry="5"
                  fill={count > 0 ? "#83112F" : "#E0E0E0"}
                />
                Sorry, your browser does not support inline SVG.
              </svg>
            </div>
            <div
              className="tab1-mobile-title"
              style={{
                display: count === 1 ? "" : "none",
                position: "absolute",
                left: "-15px",
              }}
            >
              Registrazione
            </div>
          </div>
        </div>
        <div className="tab-icon" onClick={() => tab2Click()}>
          <div className="desktop-icon">
            <svg className="tab-icon-background">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M143.652 3.01544C142.939 1.76914 141.614 1 140.179 1H6.39263C3.32134 1 1.39587 4.31793 2.91966 6.98456L14.3659 27.0154C15.0686 28.2452 15.0686 29.7548 14.3659 30.9846L2.91966 51.0154C1.39587 53.6821 3.32133 57 6.39262 57H140.179C141.614 57 142.939 56.2309 143.652 54.9846L157.366 30.9846C158.069 29.7548 158.069 28.2452 157.366 27.0154L143.652 3.01544Z"
                fill={count > 1 ? (count > 2 ? "#83112F" : "#FFF8F8") : "#fff"}
                stroke={count > 1 ? "#83112F" : "#C1C9D2"}
              />
            </svg>
            <div
              className={"tab-icon-title2"}
              style={{
                color:
                  count > 1 ? (count > 2 ? "#FFF8F8" : "#83112F") : "#3C4257",
              }}
            >
              Dati personali
            </div>
          </div>
          <div
            className="mobile-icon"
            style={{ position: "relative", width: "40px" }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <svg height="20" width="20">
                <ellipse
                  cx="10"
                  cy="10"
                  rx="10"
                  ry="10"
                  fill="#F1E2E2CF"
                  style={{ margin: "auto", display: count === 2 ? "" : "none" }}
                />
                Sorry, your browser does not support inline SVG.
              </svg>
              <svg
                height="10"
                width="10"
                style={{
                  position: "absolute",
                }}
              >
                <ellipse
                  cx="5"
                  cy="5"
                  rx="5"
                  ry="5"
                  fill={count > 1 ? "#83112F" : "#E0E0E0"}
                />
                Sorry, your browser does not support inline SVG.
              </svg>
            </div>
            <div
              className="tab1-mobile-title"
              style={{
                display: count === 2 ? "" : "none",
                position: "absolute",
                left: "-16px",
              }}
            >
              Dati personali
            </div>
          </div>
        </div>
        <div className="tab-icon" onClick={() => tab3Click()}>
          <div className="desktop-icon">
            <svg className="tab-icon-background">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M143.652 3.01544C142.939 1.76914 141.614 1 140.179 1H6.39263C3.32134 1 1.39587 4.31793 2.91966 6.98456L14.3659 27.0154C15.0686 28.2452 15.0686 29.7548 14.3659 30.9846L2.91966 51.0154C1.39587 53.6821 3.32133 57 6.39262 57H140.179C141.614 57 142.939 56.2309 143.652 54.9846L157.366 30.9846C158.069 29.7548 158.069 28.2452 157.366 27.0154L143.652 3.01544Z"
                fill={count > 2 ? (count > 3 ? "#83112F" : "#FFF8F8") : "#fff"}
                stroke={count > 2 ? "#83112F" : "#C1C9D2"}
              />
            </svg>
            <div
              className={"tab-icon-title3"}
              style={{
                color:
                  count > 2 ? (count > 3 ? "#FFF8F8" : "#83112F") : "#3C4257",
              }}
            >
              Documenti
            </div>
          </div>
          <div
            className="mobile-icon"
            style={{ position: "relative", width: "40px" }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <svg height="20" width="20">
                <ellipse
                  cx="10"
                  cy="10"
                  rx="10"
                  ry="10"
                  fill="#F1E2E2CF"
                  style={{ margin: "auto", display: count === 3 ? "" : "none" }}
                />
                Sorry, your browser does not support inline SVG.
              </svg>
              <svg
                height="10"
                width="10"
                style={{
                  position: "absolute",
                }}
              >
                <ellipse
                  cx="5"
                  cy="5"
                  rx="5"
                  ry="5"
                  fill={count > 2 ? "#83112F" : "#E0E0E0"}
                />
                Sorry, your browser does not support inline SVG.
              </svg>
            </div>
            <div
              className="tab1-mobile-title"
              style={{
                display: count === 3 ? "" : "none",
                position: "absolute",
                left: "-7px",
              }}
            >
              Documenti
            </div>
          </div>
        </div>
        <div className="tab-icon" onClick={() => tab4Click()}>
          <div className="desktop-icon">
            <svg style={{ width: "243px", height: "58px" }}>
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M227.652 3.01544C226.939 1.76914 225.614 1 224.179 1H6.39263C3.32134 1 1.39587 4.31793 2.91966 6.98456L14.3659 27.0154C15.0686 28.2452 15.0686 29.7548 14.3659 30.9846L2.91966 51.0154C1.39587 53.6821 3.32134 57 6.39263 57H224.179C225.614 57 226.939 56.2309 227.652 54.9846L241.366 30.9846C242.069 29.7548 242.069 28.2452 241.366 27.0154L227.652 3.01544Z"
                fill={count > 3 ? (count > 4 ? "#83112F" : "#FFF8F8") : "#fff"}
                stroke={count > 3 ? "#83112F" : "#C1C9D2"}
              />
            </svg>
            <div
              className="tab-icon-title4"
              style={{
                color:
                  count > 3 ? (count > 4 ? "#FFF8F8" : "#83112F") : "#3C4257",
              }}
            >
              Statuto, foro e Consensi
            </div>
          </div>
          <div
            className="mobile-icon"
            style={{ position: "relative", width: "40px" }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <svg height="20" width="20">
                <ellipse
                  cx="10"
                  cy="10"
                  rx="10"
                  ry="10"
                  fill="#F1E2E2CF"
                  style={{ margin: "auto", display: count === 4 ? "" : "none" }}
                />
                Sorry, your browser does not support inline SVG.
              </svg>
              <svg
                height="10"
                width="10"
                style={{
                  position: "absolute",
                }}
              >
                <ellipse
                  cx="5"
                  cy="5"
                  rx="5"
                  ry="5"
                  fill={count > 3 ? "#83112F" : "#E0E0E0"}
                />
                Sorry, your browser does not support inline SVG.
              </svg>
            </div>
            <div
              className="tab1-mobile-title"
              style={{
                display: count === 4 ? "" : "none",
                position: "absolute",
                left: "-32px",
              }}
            >
              Statuto, foro e Consensi
            </div>
          </div>
        </div>
        <div className="tab-icon" onClick={() => tab5Click()}>
          <div className="desktop-icon">
            <svg className="tab-icon-background">
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M143.652 3.01544C142.939 1.76914 141.614 1 140.179 1H6.39263C3.32134 1 1.39587 4.31793 2.91966 6.98456L14.3659 27.0154C15.0686 28.2452 15.0686 29.7548 14.3659 30.9846L2.91966 51.0154C1.39587 53.6821 3.32133 57 6.39262 57H140.179C141.614 57 142.939 56.2309 143.652 54.9846L157.366 30.9846C158.069 29.7548 158.069 28.2452 157.366 27.0154L143.652 3.01544Z"
                fill={count > 4 ? (count > 5 ? "#83112F" : "#FFF8F8") : "#fff"}
                stroke={count > 4 ? "#83112F" : "#C1C9D2"}
              />
            </svg>
            <div
              className={"tab-icon-title5"}
              style={{
                color:
                  count > 4 ? (count > 5 ? "#FFF8F8" : "#83112F") : "#3C4257",
              }}
            >
              Face ID
            </div>
          </div>
          <div
            className="mobile-icon"
            style={{ position: "relative", width: "40px" }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <svg height="20" width="20">
                <ellipse
                  cx="10"
                  cy="10"
                  rx="10"
                  ry="10"
                  fill="#F1E2E2CF"
                  style={{ margin: "auto", display: count === 5 ? "" : "none" }}
                />
                Sorry, your browser does not support inline SVG.
              </svg>
              <svg
                height="10"
                width="10"
                style={{
                  position: "absolute",
                }}
              >
                <ellipse
                  cx="5"
                  cy="5"
                  rx="5"
                  ry="5"
                  fill={count > 4 ? "#83112F" : "#E0E0E0"}
                />
                Sorry, your browser does not support inline SVG.
              </svg>
            </div>
            <div
              className="tab1-mobile-title"
              style={{
                display: count === 5 ? "" : "none",
                position: "absolute",
              }}
            >
              Face ID
            </div>
          </div>
        </div>
        <div className="tab-icon" onClick={() => tab6Click()}>
          <div className="desktop-icon">
            <svg style={{ width: "125px", height: "58px" }}>
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M2.91966 6.98456C1.39587 4.31793 3.32134 1 6.39263 1H120.5C122.709 1 124.5 2.79086 124.5 5V53C124.5 55.2091 122.709 57 120.5 57H6.39263C3.32134 57 1.39587 53.6821 2.91966 51.0154L14.3659 30.9846C15.0686 29.7548 15.0686 28.2452 14.3659 27.0154L2.91966 6.98456Z"
                fill={count > 5 ? (count > 6 ? "#83112F" : "#FFF8F8") : "#fff"}
                stroke={count > 5 ? "#83112F" : "#C1C9D2"}
              />
            </svg>
            <div
              className="tab-icon-title6"
              style={{
                color:
                  count > 5 ? (count > 6 ? "#FFF8F8" : "#83112F") : "#3C4257",
              }}
            >
              Riepilogo
            </div>
          </div>
          <div
            className="mobile-icon"
            style={{ position: "relative", width: "40px" }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <svg height="20" width="20">
                <ellipse
                  cx="10"
                  cy="10"
                  rx="10"
                  ry="10"
                  fill="#F1E2E2CF"
                  style={{ margin: "auto", display: count === 6 ? "" : "none" }}
                />
                Sorry, your browser does not support inline SVG.
              </svg>
              <svg
                height="10"
                width="10"
                style={{
                  position: "absolute",
                }}
              >
                <ellipse
                  cx="5"
                  cy="5"
                  rx="5"
                  ry="5"
                  fill={count > 5 ? "#83112F" : "#E0E0E0"}
                />
                Sorry, your browser does not support inline SVG.
              </svg>
            </div>
            <div
              className="tab1-mobile-title"
              style={{
                display: count === 6 ? "" : "none",
                position: "absolute",
                left: "-3px",
              }}
            >
              Riepilogo
            </div>
          </div>
        </div>
      </div>
      <TabContent1
        isActive={count === 1 ? true : false}
        selecttab1={() => tab1Click()}
      />
      <TabContent2 isActive={count === 2 ? true : false} />
      <TabContent3 isActive={count === 3 ? true : false} />
      <TabContent4 isActive={count === 4 ? true : false} />
      <TabContent5 isActive={count === 5 ? true : false} />
      <TabContent6
        isActive={count === 6 ? true : false}
        edit1={() => tab1Click()}
        edit2={() => tab2Click()}
        edit3={() => tab3Click()}
        edit5={() => tab5Click()}
      />
      <div
        className="d-flex tabs-btn"
        style={{ justifyContent: "center", marginTop: "5%" }}
      >
        {count === 1 ? (
          <div className="toPrevStep-div" onClick={() => returnLogin()}>
            Annulla
          </div>
        ) : (
          <div className="toPrevStep-div" onClick={() => backward()}>
            Indietro
          </div>
        )}
        {count === 6 ? (
          <div className="toNextStep-div" onClick={() => confirm()}>
            Conferma
          </div>
        ) : (
          <div className="toNextStep-div" onClick={() => forward()}>
            Avanti
          </div>
        )}
      </div>
      <ModalForVerify />
    </>
  );
};

const TabContent1 = ({ isActive }) => {
  const [emailConfirmed, setEmailConfirm] = useState(false);
  const [passwordConfirmed, setPasswordConfirm] = useState(false);

  const userNameChange = (e) => {
    window.tab1.name = e.target.value;
  };

  const teleChange = (e) => {
    window.tab1.telephone = e.target.value;
  };

  const emailChange = (e) => {
    window.tab1.email = e.target.value;
  };

  const passwordChange = (e) => {
    window.tab1.password = e.target.value;
  };

  const confirmEmail = (e) => {
    if (window.tab1.email === e.target.value) {
      setEmailConfirm(true);
    }
  };

  return (
    <div
      className="container"
      style={{ display: isActive === true ? "" : "none" }}
    >
      <div className="tab1ContentTitle">Dati di registrazione</div>
      <div className="col-md-12 col-sm-12 mt-2">
        <div className="row mt-2">
          <div className="col-md-6 col-sm-6 tabContent-input1 padding-right">
            <div className="mt-2">
              <div className="tabContentSubtitle">Username</div>
              <input
                type="text"
                placeholder="Inserisci il tuo username"
                className="tabInputField form-control w-100"
                onChange={(e) => userNameChange(e)}
              ></input>
            </div>
            <div className="mt-2">
              <div className="tabContentSubtitle">Email</div>
              <input
                type="text"
                placeholder="Inserisci la tua email"
                className="tabInputField form-control w-100"
                onChange={(e) => emailChange(e)}
              ></input>
            </div>
            <div className="mt-2">
              <div className="tabContentSubtitle">Conferma email</div>
              <input
                type="text"
                placeholder="Conferma la tua mail"
                className="tabInputField form-control w-100"
                onChange={(e) => confirmEmail(e)}
              ></input>
            </div>
          </div>
          <div className="col-md-6 col-sm-6 tabContent-input2 padding-left">
            <div className="mt-2">
              <div className="tabContentSubtitle ">Telefono</div>
              <input
                type="text"
                placeholder="Inserisci il tuo numero di telefono"
                className="tabInputField form-control w-100"
                onChange={(e) => teleChange(e)}
              ></input>
            </div>
            <div className="mt-2">
              <div className="tabContentSubtitle ">Password</div>
              <input
                type="text"
                placeholder="Inserisci la tua password"
                className="tabInputField form-control w-100"
                onChange={(e) => passwordChange(e)}
              ></input>
              <div className="mt-2">
                <div className="tabContentSubtitle ">Conferma Password</div>
                <input
                  type="text"
                  placeholder="Conferma la tua password"
                  className="tabInputField form-control w-100"
                ></input>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const TabContent2 = ({ isActive }) => {
  const [province, setProvince] = useState([]);

  const fetchProvince = async () => {
    axios.get(`https://comuni.openapi.it/province`, {
      headers: {
        'Authorization': `Bearer 631fe7eaf659ed064446fc1a`
      }
    })
      .then(res => {
        const persons = res.data;
        setProvince(persons.data);

        const select = document.getElementById('selectProvince');
        for (let x in persons.data) {
          var opt = document.createElement('option');
          opt.value = x;
          opt.innerHTML = persons.data[x];
          select.appendChild(opt);
        }
      })
  }

  useEffect(() => {
    fetchProvince();
  }, []);

  const nameChange = (e) => {
    window.tab2.name = e.target.value;
  };
  const addressChange = (e) => {
    window.tab2.address = e.target.value;
  };
  const lastNameChange = (e) => {
    window.tab2.lastName = e.target.value;
  };
  const houseNumberChange = (e) => {
    window.tab2.houseNumber = e.target.value;
  };
  const fiscalCodeChange = (e) => {
    window.tab2.fiscalCode = e.target.value;
  };
  const provinceChange = async (e) => {
    window.tab2.province = e.target.value;
    axios.get(`https://comuni.openapi.it/province/${e.target.value}`, {
      headers: {
        'Authorization': `Bearer 631fe7eaf659ed064446fc1a`
      }
    })
      .then(res => {
        const persons = res.data;
        setProvince(persons.data);

        const select = document.getElementById('selectCity');
        for (let x in persons.data[0].comuni) {
          var opt = document.createElement('option');
          opt.value = x;
          opt.innerHTML = persons.data[0].comuni[x];
          select.appendChild(opt);
        }
      })
  };
  const sexChange = (e) => {
    window.tab2.sex = e.target.value;
  };
  const cityChange = (e) => {
    window.tab2.city = e.target.value;
  };
  const birthdayChange = (e) => {
    window.tab2.birthday = e.target.value;
  };
  const capChange = (e) => {
    window.tab2.cap = e.target.value;
  };

  return (
    <div
      className="container"
      style={{ display: isActive === true ? "" : "none" }}
    >
      <div className="tab1ContentTitle">Dati Personali</div>
      <div className="col-md-12 col-sm-12 mt-2">
        <div className="row mt-2">
          <div className="col-md-6 col-sm-6 padding-right tabContent-input1">
            <div className="mt-2">
              <div className="tabContentSubtitle">Nome </div>
              <input
                type="text"
                placeholder="Inserisci il tuo nome"
                className="tabInputField form-control w-100"
                onChange={(e) => nameChange(e)}
              ></input>
            </div>
            <div className="mt-2">
              <div className="tabContentSubtitle">Cognome</div>
              <input
                type="text"
                placeholder="Inserisci il tuo cognome"
                className="tabInputField form-control w-100"
                onChange={(e) => lastNameChange(e)}
              ></input>
            </div>
            <div className="mt-2">
              <div className="tabContentSubtitle">Codice Fiscale</div>
              <input
                type="text"
                placeholder="Inserisci il tuo codice fiscale"
                className="tabInputField form-control w-100"
                onChange={(e) => fiscalCodeChange(e)}
              ></input>
            </div>
            <div className="mt-2">
              <div className="tabContentSubtitle">Sesso</div>
              <select
                onChange={(e) => sexChange(e)}
                placeholder="Seleziona"
                className="tabInputField form-control w-100"
              >
                <option value="Maschio">Maschio</option>
                <option value="Femmina">Femmina</option>
              </select>
            </div>
            <div className="mt-2">
              <div className="tabContentSubtitle">Data di nascita</div>
              <input
                type="date"
                placeholder="Inserisci il tuo codice fiscale"
                className="tabInputField form-control w-100"
                onChange={(e) => birthdayChange(e)}
              ></input>
            </div>
          </div>
          <div className="col-md-6 col-sm-6 tabContent-input2 padding-left">
            <div className="mt-2">
              <div className="tabContentSubtitle ">Indirizzo di residenza</div>
              <input
                type="text"
                placeholder="Inserisci l’indirizzo di residenza"
                className="tabInputField form-control w-100"
                onChange={(e) => addressChange(e)}
              ></input>
            </div>
            <div className="mt-2">
              <div className="tabContentSubtitle ">Numero civico</div>
              <input
                type="text"
                placeholder="Inserisci il numero civico"
                className="tabInputField form-control w-100"
                onChange={(e) => houseNumberChange(e)}
              ></input>
            </div>
            <div className="mt-2">
              <div className="tabContentSubtitle ">Provincia di residenza</div>
              <Form.Select id="selectProvince" className="tabInputField w-100"
                onChange={(e) => provinceChange(e)}>
                <option selected disabled>Inserisci la tua provincia di residenza</option>
              </Form.Select>
            </div>
            <div className="mt-2">
              <div className="tabContentSubtitle ">Comune di residenza</div>
              <Form.Select id="selectCity" className="tabInputField w-100"
                onChange={(e) => cityChange(e)}>
                <option selected disabled>Inserisci il tuo comune di residenza</option>
              </Form.Select>
            </div>
            <div className="mt-2">
              <div className="tabContentSubtitle ">CAP</div>
              <input
                type="text"
                placeholder="Inserisci il tuo CAP"
                className="tabInputField form-control w-100"
                onChange={(e) => capChange(e)}
              ></input>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const TabContent3 = ({ isActive }) => {
  const docTypeChange = (e) => {
    window.tab3.docType = e.target.value;
  };
  const releasedBy = (e) => {
    window.tab3.releasedBy = e.target.value;
  };
  const releaseDateChange = (e) => {
    window.tab3.releaseDate = e.target.value;
  };
  const docNumChange = (e) => {
    window.tab3.docNum = e.target.value;
  };
  const placeChange = (e) => {
    window.tab3.place = e.target.value;
  };

  return (
    <div
      className="container"
      style={{ display: isActive === true ? "" : "none" }}
    >
      <div className="col-md-12 col-sm-12">
        <div className="row">
          <div className="col-md-6 col-sm-12 padding-right">
            <div className="tab1ContentTitle">Caricamento Documenti</div>
            <div className="tabContentSubtitle mt-4">Tipo di documento</div>
            <Form.Select
              name="docType"
              className="tabInputField w-100"
              onChange={(e) => docTypeChange(e)}
            >
              <option value="" disabled selected>Seleziona</option>
              <option value="2">carta d'identità elettronica/cartacea</option>
              <option value="3">patente</option>
              <option value="4">passaporto</option>
            </Form.Select>
            <div className="tabContentSubtitle ">Rilasciato da</div>
            <input
              type="text"
              placeholder="Inserisci il nome dell’ente che ha rilasciato il documento"
              className="tabInputField form-control w-100"
              onChange={(e) => releasedBy(e)}
            ></input>
            <div className="tabContentSubtitle">Data di rilascio</div>
            <input
              type="date"
              placeholder="Inserisci il tuo cognome"
              className="tabInputField form-control w-100"
              onChange={(e) => releaseDateChange(e)}
            ></input>
            <div className="tabContentSubtitle ">Numero del documento</div>
            <input
              type="text"
              placeholder="Inserisci il numero del documento"
              className="tabInputField form-control w-100"
              onChange={(e) => docNumChange(e)}
            ></input>
            <div className="tabContentSubtitle">Luogo di rilascio</div>
            <input
              type="text"
              placeholder="Inserisci il luogo di rilascio del documento"
              className="tabInputField form-control w-100"
              onChange={(e) => placeChange(e)}
            ></input>
          </div>
          <div className="tab3RightSideContent col-md-6 col-sm-12 padding-left">
            <UploadBtn />
          </div>
        </div>
      </div>
    </div>
  );
};

const TabContent4 = ({ isActive }) => {
  return (
    <div
      className="container"
      style={{ display: isActive === true ? "" : "none" }}
    >
      <div className="tab1ContentTitle" style={{ width: "80%" }}>
        Statuto, Fori e Consensi
      </div>
      <div className="tab4Content">
        <div className="tab4Content-border">
          <div className="tab4Content-container">
            <div className="tab4Content-title">TERMINI E CONDIZIONI</div>
            <hr></hr>
            <div style={{ marginBottom: "20px" }}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse ullamcorper tortor dui, at facilisis arcu vestibulum
              vitae. Proin faucibus malesuada dui, eu vestibulum diam maximus a.
              Cras mi orci, porta dapibus lacinia sit amet, iaculis ut odio.
              Aliquam elementum lacus tortor, non maximus mauris laoreet a. In
              vel nulla elit. Etiam a erat lorem. Praesent ipsum ex, finibus ut
              leo eget, suscipit aliquet velit. Aliquam sed rhoncus enim. Etiam
              luctus enim nec velit hendrerit egestas. Aliquam et erat pulvinar,
              dictum mauris vel, pretium quam. Suspendisse a tellus lacus.
              Nullam scelerisque accumsan ligula tristique pellentesque.
              Maecenas hendrerit leo urna. Mauris non tincidunt ante, quis
              interdum mauris. Maecenas tempor euismod enim, eget imperdiet
              mauris vehicula sit amet. Nunc egestas a augue a cursus. Curabitur
              at interdum sapien. Etiam semper dolor id ante rhoncus mattis.
              Vestibulum semper maximus ipsum, sed sollicitudin velit cursus at.
              Orci varius natoque penatibus et magnis dis parturient montes,
              nascetur ridiculus mus. Sed congue nisi vel viverra accumsan.
            </div>
            <input type="checkbox" name="vehicle1" value="Bike" />
            <label htmlFor="vehicle1">Accetto</label>
          </div>
        </div>
        <div className="tab4Content-border">
          <div className="tab4Content-container">
            <div className="tab4Content-title">STATUTO PRIVACY</div>
            <hr></hr>
            <div style={{ marginBottom: "20px" }}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse ullamcorper tortor dui, at facilisis arcu vestibulum
              vitae. Proin faucibus malesuada dui, eu vestibulum diam maximus a.
              Cras mi orci, porta dapibus lacinia sit amet, iaculis ut odio.
              Aliquam elementum lacus tortor, non maximus mauris laoreet a. In
              vel nulla elit. Etiam a erat lorem. Praesent ipsum ex, finibus ut
              leo eget, suscipit aliquet velit. Aliquam sed rhoncus enim. Etiam
              luctus enim nec velit hendrerit egestas. Aliquam et erat pulvinar,
              dictum mauris vel, pretium quam. Suspendisse a tellus lacus.
              Nullam scelerisque accumsan ligula tristique pellentesque.
              Maecenas hendrerit leo urna. Mauris non tincidunt ante, quis
              interdum mauris. Maecenas tempor euismod enim, eget imperdiet
              mauris vehicula sit amet. Nunc egestas a augue a cursus. Curabitur
              at interdum sapien. Etiam semper dolor id ante rhoncus mattis.
              Vestibulum semper maximus ipsum, sed sollicitudin velit cursus at.
              Orci varius natoque penatibus et magnis dis parturient montes,
              nascetur ridiculus mus. Sed congue nisi vel viverra accumsan.
            </div>
            <input type="checkbox" name="vehicle1" value="Bike" />
            <label htmlFor="vehicle1">Accetto</label>
            <br></br>
          </div>
        </div>
      </div>
    </div>
  );
};

const TabContent5 = ({ isActive }) => {
  const webcamRef = React.useRef(null);
  const [camera, setCamera] = useState(false);

  const videoConstraints = {
    width: 1280,
    height: 720,
    facingMode: "user",
  };

  const capture = React.useCallback(() => {
    const imageSrc = webcamRef.current.getScreenshot();
    let link_img = document.createElement("a");
    link_img.style.display = "none";
    document.body.appendChild(link_img);
    link_img.href = imageSrc;
    link_img.download = "face_id.png";
    link_img.click();
  }, [webcamRef]);

  return (
    <div
      className="container"
      style={{ display: isActive === true ? "" : "none" }}
    >
      <div className="tab1ContentTitle">Face ID</div>
      <div
        className="mt-4"
        style={{
          display: "flex",
          justifyContent: "center",
          position: "relative",
        }}
      >
        {camera ? (
          <Webcam
            audio={false}
            ref={webcamRef}
            screenshotFormat="image/jpeg"
            videoConstraints={videoConstraints}
            style={{ width: "100%" }}
            className="tab5Content"
          />
        ) : (
          <img src={FaceId} className="tab5Content"></img>
        )}
        {camera ? (
          <img src={ClickCamera} onClick={capture} className="capture-btn"></img>
        ) : (
          <div onClick={() => setCamera(true)} className="capture-btn">
            Clicca qui
          </div>
        )}
      </div>
    </div>
  );
};

const TabContent6 = ({ isActive, edit1, edit2, edit3, edit5 }) => {
  return (
    <div
      className="container"
      style={{ display: isActive === true ? "" : "none" }}
    >
      <div className="tab1ContentTitle">Riepilogo</div>
      <div className="col-md-8 col-sm-8 m-auto">
        <div className="tab6Border-div">
          <div className="tab6Border-insideContainer">
            <div className="d-flex" style={{ justifyContent: "space-between" }}>
              <div className="tab6Content-title">DATI DI REGISTRAZIONE</div>
              <img
                src={PencilEdit}
                style={{ cursor: "pointer" }}
                onClick={() => edit1()}
              ></img>
            </div>
            <hr></hr>
            <div className="d-flex">
              <div>
                <div className="tab6Content">USERNAME</div>
                <div className="tab6Content">EMAIL</div>
                <div className="tab6Content">TELEFONO</div>
              </div>
              <div style={{ marginLeft: "35%" }}>
                <div className="tab6Content">{window.tab1.name}</div>
                <div className="tab6Content">{window.tab1.email}</div>
                <div className="tab6Content">{window.tab1.telephone}</div>
              </div>
            </div>
          </div>
        </div>
        <div className="tab6Border-div">
          <div className="tab6Border-insideContainer">
            <div className="d-flex" style={{ justifyContent: "space-between" }}>
              <div className="tab6Content-title">DATI PERSONALI</div>
              <img
                src={PencilEdit}
                style={{ cursor: "pointer" }}
                onClick={() => edit2()}
              ></img>
            </div>
            <hr></hr>
            <div className="d-flex">
              <div>
                <div className="tab6Content">NOME E COGNOME</div>
                <div className="tab6Content">CODICE FISCALE</div>
                <div className="tab6Content">SESSO</div>
                <div className="tab6Content">DATA DI NASCITA</div>
                <div className="tab6Content">INDIRIZZO DI RESIDENZA</div>
                <div className="tab6Content">PROVINCIA DI RESIDENZA</div>
                <div className="tab6Content">COMUNE DI RESIDENZA</div>
                <div className="tab6Content">CAP</div>
              </div>
              <div style={{ marginLeft: "17%" }}>
                <div className="tab6Content">
                  {window.tab2.name + "  " + window.tab2.lastName}
                </div>
                <div className="tab6Content">{window.tab2.fiscalCode}</div>
                <div className="tab6Content">{window.tab2.sex}</div>
                <div className="tab6Content">{window.tab2.birthday}</div>
                <div className="tab6Content">{window.tab2.address}</div>
                <div className="tab6Content">{window.tab2.province}</div>
                <div className="tab6Content">{window.tab2.city}</div>
                <div className="tab6Content">{window.tab2.cap}</div>
              </div>
            </div>
          </div>
        </div>
        <div className="tab6Border-div">
          <div className="tab6Border-insideContainer">
            <div className="d-flex" style={{ justifyContent: "space-between" }}>
              <div className="tab6Content-title">CARICAMENTO DOCUMENTI</div>
              <img
                src={PencilEdit}
                style={{ cursor: "pointer" }}
                onClick={() => edit3()}
              ></img>
            </div>
            <hr></hr>
            <div className="d-flex">
              <div>
                <div className="tab6Content">TIPO DI DOCUMENTO</div>
                <div className="tab6Content">RILASCIATO DA</div>
                <div className="tab6Content">DATA DI RILASCIO</div>
                <div className="tab6Content">NUMERO DI DOCUMENTO</div>
                <div className="tab6Content">LUOGO DI RILASCIO</div>
                <div className="tab6Content">ALLEGATI</div>
              </div>
              <div style={{ marginLeft: "17%" }}>
                <div className="tab6Content">{window.tab3.docType}</div>
                <div className="tab6Content">{window.tab3.releasedBy}</div>
                <div className="tab6Content">{window.tab3.releaseDate}</div>
                <div className="tab6Content">{window.tab3.place}</div>
                <div className="tab6Content">{window.tab3.docNum}</div>
                <div className="tab6Content">{window.tab3.docNum}</div>
              </div>
            </div>
          </div>
        </div>
        <div className="tab6Border-div">
          <div className="tab6Border-insideContainer">
            <div className="d-flex" style={{ justifyContent: "space-between" }}>
              <div className="tab6Content-title">FACE ID</div>
              <img
                src={PencilEdit}
                style={{ cursor: "pointer" }}
                onClick={() => edit5()}
              ></img>
            </div>
            <hr></hr>
          </div>
        </div>
      </div>
    </div>
  );
};
const mapStateToProps = (state) => ({
  show: state.ModalForVerify.show,
});

export default connect(mapStateToProps, { setShow })(Tabs);
