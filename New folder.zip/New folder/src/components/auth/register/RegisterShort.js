import React, { useState, useEffect } from "react";
import LeftPanel from "../../LeftPanel";
import { Link, useNavigate } from "react-router-dom";
import ReturnIcon from "../../../assets/images/returnIcon.svg";
import { BsEye, BsEyeSlash } from "react-icons/bs";
import ModalForVerify from "./ModalForVerify";
import { useDispatch, connect } from "react-redux";
import { setShow } from "../../../actions/ModalForVerify";

const RegisterShort = ({ show }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [formData, setFormData] = useState({
    email: "",
    confirmEmail: "",
    password: "",
  });
  const [passwordType, setPasswordType] = useState("password");
  const [readyLogin, setReadyLogin] = useState(false);

  const { email, confirmEmail, password } = formData;

  useEffect(() => {
    if (
      !isValidEmail(email) ||
      !isValidPassword(password) ||
      !confirm(email, confirmEmail)
    ) {
      setReadyLogin(false);
    } else {
      setReadyLogin(true);
    }
  }, [formData]);

  const isValidEmail = (email) => {
    return /\S+@\S+\.\S+/.test(email);
  };

  const isValidPassword = (password) => {
    if (password.length === 0) {
      return false;
    } else {
      return true;
    }
  };

  const confirm = (email, confirmEmail) => {
    if (email === confirmEmail) {
      return true;
    } else {
      return false;
    }
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    dispatch(setShow(true));
  };
  const onChange = async (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  const returnLogin = () => {
    navigate("/");
  };

  const togglePassword = () => {
    if (passwordType === "password") {
      setPasswordType("text");
      return;
    }
    setPasswordType("password");
  };

  return (
    <div
      className="d-flex recover-div"
      style={{ height: "100vh", background: "#fff" }}
    >
      <LeftPanel />
      <div className="m-auto rightPanel">
        <div className="return-login" onClick={() => returnLogin()}>
          <img
            src={ReturnIcon}
            alt="return"
            style={{ marginRight: "17.6px" }}
          ></img>
          Torna al login
        </div>
        <div className="recover-text">Crea il tuo account</div>
        <form className="form" onSubmit={onSubmit}>
          <div className="subtitle">Email</div>
          <input
            type="email"
            placeholder="Inserisci la tua email"
            name="email"
            value={email}
            onChange={onChange}
            className="form-control"
            style={{ fontFamily: "Mulish", height: "50px" }}
          />
          <div className="subtitle">Confirm Email</div>
          <input
            type="email"
            placeholder="Inserisci la tua email"
            name="confirmEmail"
            value={confirmEmail}
            onChange={onChange}
            className="form-control"
            style={{ fontFamily: "Mulish", height: "50px" }}
          />
          <div className="subtitle">Password</div>
          <div style={{ position: "relative" }}>
            <input
              type={passwordType}
              placeholder="Inserisci la tua password"
              name="password"
              value={password}
              onChange={onChange}
              minLength="4"
              className="form-control"
              style={{
                marginBottom: "20px",
                fontFamily: "Mulish",
                height: "50px",
              }}
            />
            <div onClick={togglePassword} className="passwordHideToggle">
              {passwordType === "password" ? <BsEye /> : <BsEyeSlash />}
            </div>
          </div>
          <input
            type={readyLogin ? "submit" : "button"}
            id={readyLogin ? "" : "disable-login"}
            className="login-btn"
            value="Registrati"
          />
        </form>
        <div
          style={{
            textAlign: "center",
            margin: "auto",
            paddingTop: "30px",
          }}
        >
          <Link to="/" className="reset-password">
            Sei già registrato? Effettua il Login
          </Link>
        </div>
      </div>
      <ModalForVerify acrossSms={true} />
    </div>
  );
}

const mapStateToProps = (state) => ({
  show: state.ModalForVerify.show,
});

export default connect(mapStateToProps, { setShow })(RegisterShort);

