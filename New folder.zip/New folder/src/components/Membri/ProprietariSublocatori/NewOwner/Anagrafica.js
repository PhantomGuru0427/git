import React, { useState, useEffect } from "react";
import "../../../../assets/css/Membri.css";
import { BsCalendar2Event } from "react-icons/bs";
import Form from "react-bootstrap/Form";
import axios from "axios";

export default function Anagrafica(props) {
  const [checked, setChecked] = useState(false);
  const [province, setProvince] = useState([]);

  const fetchProvince = async () => {
    axios.get(`https://comuni.openapi.it/province`, {
      headers: {
        'Authorization': `Bearer 631fe7eaf659ed064446fc1a`
      }
    })
      .then(res => {
        const persons = res.data;
        setProvince(persons.data);

        const select = document.getElementById('selectProvince');
        for (let x in persons.data) {
          var opt = document.createElement('option');
          opt.value = x;
          opt.innerHTML = persons.data[x];
          select.appendChild(opt);
        }
      })
  }

  useEffect(() => {
    fetchProvince();
  }, []);

  const provinceChange = async (e) => {
    window.tab2.province = e.target.value;
    axios.get(`https://comuni.openapi.it/province/${e.target.value}`, {
      headers: {
        'Authorization': `Bearer 631fe7eaf659ed064446fc1a`
      }
    })
      .then(res => {
        const persons = res.data;
        setProvince(persons.data);

        const select = document.getElementById('selectCity');
        for (let x in persons.data[0].comuni) {
          var opt = document.createElement('option');
          opt.value = x;
          opt.innerHTML = persons.data[0].comuni[x];
          select.appendChild(opt);
        }
      })
  };

  const societaClick = () => {
    if (document.getElementById("societa-check").checked) {
      setChecked(true);
    } 
  };
  const personaClick = () => {
    if(document.getElementById("persona-check").checked) {
      setChecked(false);
    }
  }

  const  cityChange = (e) => {
    
  }

  return (
    <div
      className="d-block w-100 mb-3 bg-white"
      style={{ borderRadius: "16px" }}
    >
      <Form>
        <div className="form-item-align-box d-block pt-5 pb-5">
          <div className="label-heading my-4 d-block w-100">
            <div className="label-text rel d-inline-block py-2 px-2">
              <h1 className="fs-16 text-white text-uppercase fw-semibold">
                TIPO
              </h1>
            </div>
          </div>
          <div className="d-block">
            {["radio"].map((type) => (
              <div key={`default-${type}`} className="mb-3">
                <Form.Check
                  default
                  className="mb-2"
                  label="Persona fisica"
                  name="group1"
                  type={type}
                  id="persona-check"
                  onClick={() => personaClick()}
                />
                <Form.Check
                  default
                  className="mb-2"
                  label="Società od altri soggetti"
                  name="group1"
                  type={type}
                  id="societa-check"
                  onClick={() => societaClick()}
                />
              </div>
            ))}
          </div>
          {checked ? (
            <div>
              <div className="label-heading my-4 d-block w-100">
                <div className="label-text rel d-inline-block py-2 px-2">
                  <h1 className="fs-16 text-white text-uppercase fw-semibold">
                    SOCIETA’
                  </h1>
                </div>
              </div>
              <div className="row gy-4">
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Denominazione o ragione sociale*
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Ritenuta
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Tipo di soggetto*
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Codice fiscale*
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Partita IVA*
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
              </div>
              <div className="label-heading my-4 d-block w-100">
                <div className="label-text rel d-inline-block py-2 px-2">
                  <h1 className="fs-16 text-white text-uppercase fw-semibold">
                    CAMERA DI COMMERCIO
                  </h1>
                </div>
              </div>
              <div className="row gy-4">
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Numero
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Città
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
              </div>
              <div className="label-heading my-4 d-block w-100">
                <div className="label-text rel d-inline-block py-2 px-2">
                  <h1 className="fs-16 text-white text-uppercase fw-semibold">
                    ALTRI DATI
                  </h1>
                </div>
              </div>
              <div className="row gy-4">
                <div className="col-md-6 d-flex justify-content-between">
                  <div className="d-flex flex-column col-md-4">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      REA
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                  <div className="d-flex flex-column col-md-7 mt-auto mb-0">
                    <label htmlFor="" className="f-label fs-16 mb-2"></label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Capitale sociale
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
              </div>
              <div className="label-heading my-4 d-block w-100">
                <div className="label-text rel d-inline-block py-2 px-2">
                  <h1 className="fs-16 text-white text-uppercase fw-semibold">
                    RAPPRESENTANTE LEGALE
                  </h1>
                </div>
              </div>
              <div className="row gy-4">
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Nome
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Cognome
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Data di nascita
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Stato di nascita
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Comune di nascita
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                      onChange={(e) => cityChange(e)}
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Provincia
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Codice fiscale
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Sesso
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      In qualità di
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div>
              <div className="label-heading my-4 d-block w-100">
                <div className="label-text rel d-inline-block py-2 px-2">
                  <h1 className="fs-16 text-white text-uppercase fw-semibold">
                    PERSONA FISICA
                  </h1>
                </div>
              </div>

              <div className="row gy-4">
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Name*
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Cognome*
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Data di nascita*
                    </label>
                    <div className="d-flex align-items-center justify-content-between border border-secondary px-3 rounded-3 border-opacity-50">
                      <input
                        type="text"
                        className="border-0 fs-16 text-dark flex-grow-1"
                      />
                      <span className="flex-shrink-0">
                        <BsCalendar2Event />
                      </span>
                    </div>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Stato di nascita*
                    </label>
                    <select className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white">
                      <option>Select</option>
                      <option>Select</option>
                      <option>Select</option>
                    </select>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Comune di nascita*
                    </label>
                    <select className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white">
                      <option>Select</option>
                      <option>Select</option>
                      <option>Select</option>
                    </select>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Provincia *
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Codice fiscale*
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Sesso*
                    </label>
                    <select className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white">
                      <option>Select</option>
                      <option>Select</option>
                      <option>Select</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="col-12">
            <div className="d-flex align-items-center mt-5 form-last-btns justify-content-end">
              <button
                type="button"
                className="back-btn btn-last rounded-3 shadow w-193 me-2 border-0"
                onClick={() => props.back()}
              >
                Annulla
              </button>
              <button
                type="button"
                className="next-btn btn-last rounded-3 shadow w-193 border-0"
                onClick={() => props.next()}
              >
                Avanti
              </button>
            </div>
          </div>
        </div>
      </Form>
    </div>
  );
}
