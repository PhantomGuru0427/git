import React, { useState } from "react";
import "../../../../assets/css/Membri.css";
import cardimage from "../../../../assets/images/user-person.png";
import { BsCalendar2Event } from "react-icons/bs";
import Form from "react-bootstrap/Form";

import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";

export default function Fornitori(props) {
  const [show, setShow] = useState(false);
  const [selected, setSelected] = useState(0);
  const [saveSelect, setSaveSelect] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    <>
      <div
        className="d-block w-100 mb-3 bg-white"
        style={{ borderRadius: "16px" }}
      >
        <Form>
          <div className="form-item-align-box d-block pt-5 pb-5">
            <div className="row gy-4">
              <div className="col-12">
                <div className="d-flex align-items-center mt-5 form-last-btns">
                  <button
                    type="button"
                    className="back-btn btn-last rounded-3 shadow w-193 me-2 border-0"
                  >
                    Nuovo
                  </button>
                  <button
                    type="button"
                    className="back-btn btn-last rounded-3 shadow w-193 me-2 border-0"
                    onClick={handleShow}
                  >
                    Seleziona
                  </button>
                </div>
              </div>
              {saveSelect ? (
                <div className="col-md-6">
                  <div className="popup-yellow d-block overflow-hidden rounded-3">
                    <div className="yellow-popup-header d-flex align-items-center justify-content-between p-2">
                      <h3 className="fs-16 text-white fw-semibold">
                        DARIO VERDI
                      </h3>
                      <button
                        type="button"
                        className="border-0 bg-transparent text-white"
                        onClick={() => setSaveSelect(false)}
                      >
                        <i className="fal fa-times"></i>
                      </button>
                    </div>
                    <div
                      className="table-list d-block"
                      onClick={() => handleShow()}
                    >
                      <table className="table table-borderless">
                        <tbody>
                          <tr>
                            <td className="text-uppercase fs-14 text-secondary px-3">
                              CATEGORIA
                            </td>
                            <td className="text-capitalize fs-14 text-dark px-3">
                              Idraulico
                            </td>
                          </tr>
                          <tr>
                            <td className="text-uppercase fs-14 text-secondary px-3">
                              TIPO DI SOGGETTO
                            </td>
                            <td className="text-capitalize fs-14 text-dark px-3">
                              Ditta Individuale
                            </td>
                          </tr>
                          <tr>
                            <td className="text-uppercase fs-14 text-secondary px-3">
                              TELEFONO
                            </td>
                            <td className="text-capitalize fs-14 text-dark px-3">
                              3338449848
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="col-12 mt-5">
                  <div className="mx-auto d-table text-center">
                    <div className="image-user mx-auto d-table w-160 fw-100">
                      <img src={cardimage} alt="user-key" />
                    </div>
                    <p className="fs-20 text-secondary text-center">
                      Nessun fornitore associato
                    </p>
                  </div>
                </div>
              )}
              <div className="col-12">
                <div className="d-flex align-items-center mt-5 form-last-btns justify-content-end">
                  <button
                    type="button"
                    className="back-btn btn-last rounded-3 shadow w-193 me-2 border-0"
                    onClick={() => props.back()}
                  >
                    Annulla
                  </button>
                  <button
                    type="button"
                    className="next-btn btn-last rounded-3 shadow w-193 border-0"
                    onClick={() => props.next()}
                  >
                    Avanti
                  </button>
                </div>
              </div>
            </div>
          </div>
        </Form>
      </div>
      <Modal
        show={show}
        onHide={handleClose}
        dialogClassName="acc-table-box"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <Modal.Body className="p-5">
          <Button
            variant="secondary"
            onClick={handleClose}
            className="float-end bg-white border-0 text-dark"
          >
            <i className="fal fa-times"></i>
          </Button>
          <h2 className="top-form-heading d-block mb-4 fs-32 text-dark fw-semibold">
            Seleziona uno o più fornitori
          </h2>
          <div
            className="search-fence d-flex align-items-center bg-white p-2 border-opacity-50 border-secondary border rounded-3 overflow-hidden"
            style={{ width: "40%" }}
          >
            <i className="fal fa-search flex-shrink-0 me-2 text-secondary opacity-50"></i>
            <input
              type="text"
              placeholder="Cerca"
              name=""
              className="flex-grow-1 border-0 w-100 fs-14"
            />
          </div>
          <table className="table my-4 acc-list-table">
            <thead>
              <tr>
                <th className="">Categoria</th>
                <th className="">Denominazione</th>
                <th className="">Telefono</th>
                <th className="">Tipo di soggetto</th>
              </tr>
            </thead>
            <tbody>
              <tr
                style={{
                  background: selected === 1 ? "#2D9CDB33" : "",
                  cursor: "pointer",
                }}
                onClick={() => setSelected(1)}
              >
                <td>Idraulico</td>
                <td>Dario Verdi</td>
                <td>010384488</td>
                <td>Ditta individuale</td>
              </tr>
              <tr
                style={{
                  background: selected === 2 ? "#2D9CDB33" : "",
                  cursor: "pointer",
                }}
                onClick={() => setSelected(2)}
              >
                <td>Notaio</td>
                <td>Gaetani Aldi</td>
                <td>018283u9</td>
                <td>Ditta individuale</td>
              </tr>
            </tbody>
          </table>
          <div className="d-flex align-items-center mt-2 form-last-btns">
            <button
              type="button"
              className="back-btn btn-last rounded-3 shadow w-193 me-2 border-0"
              onClick={() => handleClose()}
            >
              Annulla
            </button>
            <button
              type="button"
              className="next-btn btn-last rounded-3 shadow w-193 border-0"
              onClick={() => {
                handleClose();
                setSaveSelect(selected);
              }}
            >
              Salva
            </button>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
}
