import React from "react";

export default function EmptyList(props) {
  return (
    <div className="mx-auto d-table text-center m-auto">
      <div className="image-user mx-auto d-table w-160 fw-100">
        <img src={props.imgSrc} alt="user-key" />
      </div>
      <p className="fs-20 text-secondary text-center">
        {props.subText}
      </p>
    </div>
  );
}
