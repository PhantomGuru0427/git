import React, { useState } from "react";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import AllegatiE from "../NewOwner/Allegati";
import AnagraficaE from "../NewOwner/Anagrafica";
import CorrentiE from "../NewOwner/Correnti";
import DocumentoE from "../NewOwner/Documento";
import NoteE from "../NewOwner/Note";
import RecapitiE from "../NewOwner/Recapiti";

import "../../../../assets/css/Membri.css";
import UnitaE from "./UnitaE";

export default function MidTabsE() {
  const [key, setKey] = useState("anagrafica");
  return (
    <div className="mt-30">
      <Tabs
        defaultActiveKey="anagrafica"
        id="uncontrolled-tab-example"
        className="mb-3 mid-tabs-box justify-content-center"
      >
        <Tab eventKey="anagrafica" title="Anagrafica">
          <AnagraficaE />
        </Tab>
        <Tab eventKey="recapiti" title="Recapiti">
          <RecapitiE />
        </Tab>
        <Tab eventKey="documento" title="Documento">
          <DocumentoE />
        </Tab>
        <Tab eventKey="correnti" title="Conti Correnti">
          <CorrentiE />
        </Tab>
        <Tab eventKey="unità" title="Unità">
          <UnitaE />
        </Tab>
        <Tab eventKey="note" title="Note">
          <NoteE />
        </Tab>
        <Tab eventKey="allegati" title="Allegati">
          <AllegatiE />
        </Tab>
      </Tabs>
    </div>
  );
}
