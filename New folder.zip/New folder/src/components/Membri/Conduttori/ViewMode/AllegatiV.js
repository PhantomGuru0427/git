import React from "react";

export default function AllegatiV() {
  return (
    <div className="row">
      <div className="col-12">
        <div className="form-item-align-box">
          <fieldset disabled className="d-flex flex-column">
            <label
              htmlFor=""
              className="f-label fs-16 border border-secondary p-2 px-3 text-dark rounded-3 border-opacity-50"
            >
              file.pdf
            </label>
          </fieldset>
        </div>
      </div>
    </div>
  );
}
