import React from "react";

export default function UnitaV() {
  return (
    <div className="row">
      <div className="col-md-6">
        <div className="popup-blue d-block overflow-hidden rounded-3">
          <div className="blue-popup-header d-flex align-items-center justify-content-between p-2">
            <h3 className="fs-16 text-white fw-semibold">villa verdi</h3>
            {/* <button
              type="button"
              className="border-0 bg-transparent text-white"
            >
              <i className="fal fa-times"></i>
            </button> */}
          </div>
          <div className="table-list d-block">
            <table className="table table-borderless table-correnti">
              <tbody>
                <tr>
                  <td className="text-uppercase fs-14 text-secondary px-3">
                    VIA
                  </td>
                  <td className="text-capitalize fs-14 text-dark px-3">
                    Via berli, 12
                  </td>
                </tr>
                <tr>
                  <td className="text-uppercase fs-14 text-secondary px-3">
                    CITTà
                  </td>
                  <td className="text-capitalize fs-14 text-dark px-3">
                    Genova
                  </td>
                </tr>
                <tr>
                  <td className="text-uppercase fs-14 text-secondary px-3">
                    BANCA
                  </td>
                  <td className="text-capitalize fs-14 text-dark px-3">
                    Banca Intesa
                  </td>
                </tr>
                <tr>
                  <td className="text-uppercase fs-14 text-secondary px-3">
                    ABI
                  </td>
                  <td className="text-capitalize fs-14 text-dark px-3">186</td>
                </tr>
                <tr>
                  <td className="text-uppercase fs-14 text-secondary px-3">
                    CAB
                  </td>
                  <td className="text-capitalize fs-14 text-dark px-3">3456</td>
                </tr>
                <tr>
                  <td className="text-uppercase fs-14 text-secondary px-3">
                    CIN
                  </td>
                  <td className="text-capitalize fs-14 text-dark px-3">677</td>
                </tr>
                <tr>
                  <td className="text-uppercase fs-14 text-secondary px-3">
                    CONTO
                  </td>
                  <td className="text-capitalize fs-14 text-dark px-3">
                    76894
                  </td>
                </tr>
                <tr>
                  <td className="text-uppercase fs-14 text-secondary px-3">
                    BIC/SWIFT
                  </td>
                  <td className="text-capitalize fs-14 text-dark px-3">30</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
