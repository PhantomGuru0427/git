import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import "../../../../assets/css/Membri.css";
import { Link } from "react-router-dom";
import { BsTrash } from "react-icons/bs";
import LogoMark from "../../../../assets/images/logo_mark.svg";

export default function TopHeadPartV() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <>
      <div className="head-bar">
        <Link to="/propriietari" className="fs-14" style={{ color: "white" }}>
          <i className="fal fa-long-arrow-left"></i> Torna alla lista
          proprietari
        </Link>
        <div className="right-logo">
          <h3 className="fs-14 text-uppercase text-decoration-underline mb-0">
            MARIO ROSSI
          </h3>
          <img src={LogoMark} alt="logo mark" className="logo-mark" />
        </div>
      </div>
      <div
        className="d-flex flex-column flex-md-row
       justify-content-between align-items-md-end topHeading-title"
      >
        <div className="flex-grow-1">
          <div className="d-flex flex-column">
            <h3 className="fs-24 fs-md-30 text-dark fw-semibold mb-3 mb-md-0">
              Marco Panaro
            </h3>
          </div>
        </div>
        <div className="flex-shrink-0">
          <div className="d-flex align-items-center">
            <Link
              to="/conduttori-edit"
              className="modi-btn fs-16 text-white rounded-3 w-197 text-center py-2 px-3 me-2"
            >
              Modifica
            </Link>
            <button
              type="button"
              onClick={handleShow}
              className="border border-secondary bg-white text-secondary rounded-3 py-2 px-3"
            >
              <BsTrash />
            </button>
          </div>
        </div>
      </div>
      <Modal show={show} onHide={handleClose}>
        <Modal.Body className="p-5">
          <div className="d-flex flex-column text-center">
            <h2 className="fs-32 text-dark fw-semibold mb-3">
              Vuoi eliminare questo proprietario?
            </h2>
            <h6 className="fs-16 text-dark fw-normal mb-3">
              Questa azione è irreversibile
            </h6>
            <button
              type="button"
              className="confirm-btn mb-2 rounded-3 fs-16 py-2 w-100 border-0 text-white"
            >
              Conferma
            </button>
            <button
              type="button"
              className="cancel-btn rounded-3 fs-16 py-2 w-100 border-0 text-dark bg-white"
              onClick={handleClose}
            >
              Annulla
            </button>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
}
