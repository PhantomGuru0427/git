import React from "react";

export default function FornitoriV() {
  return (
    <div className="row">
      <div className="col-md-6">
        <div className="popup-yellow d-block overflow-hidden rounded-3">
          <div className="yellow-popup-header d-flex align-items-center justify-content-between p-2">
            <h3 className="fs-16 text-white fw-semibold">DARIO VERDI</h3>
            {/* <button
            type="button"
            className="border-0 bg-transparent text-white"
          >
            <i className="fal fa-times"></i>
          </button> */}
          </div>
          <div className="table-list d-block">
            <table className="table table-borderless table-correnti">
              <tbody>
                <tr>
                  <td className="text-uppercase fs-14 text-secondary px-3">
                    CATEGORIA
                  </td>
                  <td className="text-capitalize fs-14 text-dark px-3">
                    Idraulico
                  </td>
                </tr>
                <tr>
                  <td className="text-uppercase fs-14 text-secondary px-3">
                    TIPO DI SOGGETTO
                  </td>
                  <td className="text-capitalize fs-14 text-dark px-3">
                    Ditta Individuale
                  </td>
                </tr>
                <tr>
                  <td className="text-uppercase fs-14 text-secondary px-3">
                    TELEFONO
                  </td>
                  <td className="text-capitalize fs-14 text-dark px-3">
                    3338449848
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
