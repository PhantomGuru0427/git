import React from 'react'
import { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import "../../../../assets/css/AddDetails.css";

export default function EmailDetails(props) {
    const [show, setShow] = useState(true);
    const [selected, setSelected] = useState("");
  
    useEffect(() => {
      setShow(props.show);
    }, [props]);
  
    const handleClose = () => {
      setShow(false);
      props.setAdd(false);
    };
  
    return (
      <Modal
        show={show}
        onHide={handleClose}
        aria-labelledby="contained-modal-title-vcenter"
        centered
        className="verify-Modal"
      >
        <Modal.Header closeButton style={{ borderBottom: "0 none" }} />
        <Modal.Body>
          <div>
            <div className="contactDetails-title">Altri recapiti</div>
            <table className="contactDetails-table">
              <tbody>
                <tr
                  onClick={() => setSelected("Secondo email")}
                  style={{
                    background: selected === "Secondo email" ? "#F1E2E2CF" : "",
                    cursor: "pointer",
                  }}
                >
                  <td>&nbsp;Secondo email</td>
                </tr>
                <tr
                  onClick={() => setSelected("Terzo email")}
                  style={{
                    background: selected === "Terzo email" ? "#F1E2E2CF" : "",
                    cursor: "pointer",
                  }}
                >
                  <td>&nbsp;Terzo email</td>
                </tr>
                <tr
                  onClick={() => {setSelected("Quarto email");}}
                  style={{
                    background: selected === "Quarto email" ? "#F1E2E2CF" : "",
                    cursor: "pointer",
                  }}
                >
                  <td>&nbsp;Quarto email</td>
                </tr>
              </tbody>
            </table>
            <div className="d-flex align-items-center mt-5 form-last-btns justify-content-end">
              <button
                type="button"
                className="back-btn btn-last rounded-3 shadow w-193 me-2 border-0"
              >
                Annulla
              </button>
              <button
                type="button"
                className="next-btn btn-last rounded-3 shadow w-193 border-0"
                onClick={() => {props.addEmail(selected); handleClose();}}
              >
                Salva
              </button>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    );
}
