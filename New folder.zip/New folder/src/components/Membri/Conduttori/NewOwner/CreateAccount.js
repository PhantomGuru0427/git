import React from "react";
import { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import "../../../../assets/css/Membri.css";

import TrashBinIcon from "../../../../assets/images/trashbin.svg";
import PrintIcon from "../../../../assets/images/print.svg";
import PencilIcon from "../../../../assets/images/pencil.svg";

export default function CreateAccount(props) {
  const [show, setShow] = useState(true);
  const [disable, setDisable] = useState(false);  
  const [checked, setChecked] = useState(false);
  
  const [data, setData] = useState({
    nome: "",
    tipo: "",
    iban: "",
    provincia: "",
    intestazione: "",
    abi: "",
    cab: "",
    conto: "",
    cin: "",
    bic: "",
    banca: "",
    sia: "",
    agenzia: "",
    sepa: "",
  });

  useEffect(() => {
    const temp = {
      nome: window.bankAccount.nome,
      tipo: window.bankAccount.tipo,
      iban: window.bankAccount.iban,
      provincia: window.bankAccount.provincia,
      intestazione: window.bankAccount.intestazione,
      abi: window.bankAccount.abi,
      cab: window.bankAccount.cab,
      conto: window.bankAccount.conto,
      cin: window.bankAccount.cin,
      bic: window.bankAccount.bic,
      banca: window.bankAccount.banca,
      sia: window.bankAccount.sia,
      agenzia: window.bankAccount.agenzia,
      sepa: window.bankAccount.sepa,
    };
    setData(temp);
    setShow(props.show);    
    if (window.bankAccount.nome === "") {
      setDisable(false);
    } else {
      setDisable(true);
    }
  }, [props, window.bankAccount]);

  const checkClick = () => {
    var c = document.getElementById("disabilitato");
    if(c.checked) {
      setChecked(true);
    } else {
      setChecked(false);
    }
  }
  const handleClose = () => {
    setShow(false);
    props.setAdd(false);
    if (window.bankAccount.nome === "") {
      setDisable(false);
    } else {
      setDisable(true);
    }
  };

  const save = () => {
    handleClose();
    window.bankAccount = data;
    if(checked) props.setChecked(true);
  };

  return (
    <Modal
      show={show}
      onHide={handleClose}
      aria-labelledby="contained-modal-title-vcenter"
      centered
      className="create-Modal"
    >
      <Modal.Header closeButton style={{ borderBottom: "0 none" }} />
      <Modal.Body>
        <div
          className="form-item-align-box d-block"
          style={{ width: "100%" }}
          id={disable === false ? "" : "bankAccount-formItem"}
        >
          <div
            className="d-flex justify-content-between"
            style={{ alignItems: "center" }}
          >
            <div className="contactDetails-title">Nuova risorsa contabile</div>
            <div style={{ display: disable === false ? "none" : "" }}>
              <img
                src={TrashBinIcon}
                style={{ marginRight: "9px", cursor: "pointer" }}
                onClick={() => {props.setDel(true); handleClose();}}
              />
              <img
                src={PencilIcon}
                style={{ marginRight: "9px", cursor: "pointer" }}
                onClick={() => {
                  setDisable(false);
                }}
              />
              <img src={PrintIcon} style={{ cursor: "pointer" }} />
            </div>
          </div>
          <div className="row gy-4 mt-3">
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Nome
                </label>
                <input
                  type="text"
                  value={data.nome}
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) => setData({ ...data, nome: e.target.value })}
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Tipo
                </label>
                <select
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white"
                  onChange={(e) => setData({ ...data, tipo: e.target.value })}
                >
                  <option>conto corrente bancario</option>
                  <option>cassa</option>
                </select>
              </div>
            </div>
          </div>
          <div className="label-heading my-4 d-block w-100">
            <div className="label-text rel d-inline-block py-2 px-2">
              <h1 className="fs-16 text-white text-uppercase fw-semibold">
                DATI DEL CONTO
              </h1>
            </div>
          </div>
          <div className="row gy-4">
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  IBAN
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) => setData({ ...data, iban: e.target.value })}
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Provincia
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) =>
                    setData({ ...data, provincia: e.target.value })
                  }
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Intestazione
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) =>
                    setData({ ...data, intestazione: e.target.value })
                  }
                />
              </div>
            </div>
            <div className="col-md-6 d-flex">
              <div
                className="d-flex flex-column"
                style={{ marginRight: "15px", width: "13%" }}
              >
                <label htmlFor="" className="f-label fs-16 mb-2">
                  ABI
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) => setData({ ...data, abi: e.target.value })}
                />
              </div>
              <div
                className="d-flex flex-column"
                style={{ marginRight: "15px", width: "13%" }}
              >
                <label htmlFor="" className="f-label fs-16 mb-2">
                  CAB
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) => setData({ ...data, cab: e.target.value })}
                />
              </div>
              <div
                className="d-flex flex-column"
                style={{ marginRight: "15px", width: "27%" }}
              >
                <label htmlFor="" className="f-label fs-16 mb-2">
                  CONTO
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) => setData({ ...data, conto: e.target.value })}
                />
              </div>
              <div
                className="d-flex flex-column"
                style={{ marginRight: "15px", width: "13%" }}
              >
                <label htmlFor="" className="f-label fs-16 mb-2">
                  CIN
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) => setData({ ...data, cin: e.target.value })}
                />
              </div>
              <div
                className="d-flex flex-column w-124"
                style={{ marginRight: "15px", width: "23%" }}
              >
                <label htmlFor="" className="f-label fs-16 mb-2">
                  BIC/SWIFT
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) => setData({ ...data, bic: e.target.value })}
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Banca
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) => setData({ ...data, banca: e.target.value })}
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Codice SIA
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) => setData({ ...data, codice: e.target.value })}
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Agenzia/Comune
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) =>
                    setData({ ...data, agenzia: e.target.value })
                  }
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Codice CUC SEPA
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                  onChange={(e) => setData({ ...data, codice: e.target.value })}
                />
              </div>
            </div>
            <div className="col-md-6">
              <input type="checkbox" id="disabilitato" name="disabilitato" onChange={() => checkClick()}/>
              <label htmlFor="disabilitato" style={{marginLeft: "10px"}}>Conto disabilitato</label>
            </div>
          </div>
          <div className="d-flex align-items-center mt-5 form-last-btns justify-content-end mb-4">
            <button
              type="button"
              className="back-btn btn-last rounded-3 shadow w-193 me-2 border-0"
              onClick={() => {
                handleClose();
              }}
            >
              Annulla
            </button>
            <button
              type="button"
              className="next-btn btn-last rounded-3 shadow w-193 border-0"
              onClick={() => save()}
            >
              Salva
            </button>
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}
