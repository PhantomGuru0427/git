import React, { useState } from "react";
import "../../../../assets/css/Membri.css";
import cardimage from "../../../../assets/images/cards.png";
import { BsCalendar2Event } from "react-icons/bs";
import Form from "react-bootstrap/Form";
import CreateAccount from "./CreateAccount";
import DeleteConfirm from "./DeleteConfirm";

export default function Correnti(props) {
  const [create, setCreate] = useState(false);
  const [del, setDel] = useState(false);
  const [checked, setChecked] = useState(false);
  
  const reset = () => {
    window.bankAccount.nome = "";
    window.bankAccount.tipo = "";
    window.bankAccount.iban = "";
    window.bankAccount.provincia = "";
    window.bankAccount.intestazione = "";
    window.bankAccount.abi = "";
    window.bankAccount.cab = "";
    window.bankAccount.conto = "";
    window.bankAccount.cin = "";
    window.bankAccount.bic = "";
    window.bankAccount.banca = "";
    window.bankAccount.sia = "";
    window.bankAccount.agenzia = "";
    window.bankAccount.sepa = "";
  };

  return (
    <div className="d-block w-100 mb-3 bg-white" style={{borderRadius: "16px"}}>
      <Form>
        <div className="form-item-align-box d-block pt-5 pb-5">
          <div className="row gy-4">
            <div className="col-12">
              <div className="d-flex align-items-center mt-5 form-last-btns">
                <button
                  type="button"
                  className="back-btn btn-last rounded-3 shadow w-193 me-2 border-0"
                  onClick={() => setCreate(true)}
                >
                  Nuovo
                </button>
              </div>
            </div>
            {window.bankAccount.nome === "" ? (
              <div className="col-12 mt-5">
                <div className="mx-auto d-table text-center">
                  <div className="image-user mx-auto d-table w-130 fw-100">
                    <img src={cardimage} alt="user-key" />
                  </div>
                  <p className="fs-20 text-secondary text-center">
                    Non hai aggiunto ancora alcun conto
                  </p>
                </div>
              </div>
            ) : (
              <div className="col-md-6">
                <div
                  className="popup-green d-block overflow-hidden rounded-3"
                  onClick={() => setCreate(true)}
                >
                  <div className="green-popup-header d-flex align-items-center justify-content-between p-2">
                    <h3 className="fs-16 text-white fw-semibold">
                      Conto corrente
                    </h3>
                    <button
                      type="button"
                      className="border-0 bg-transparent text-white"
                      onClick={() => reset()}
                    >
                      <i className="fal fa-times"></i>
                    </button>
                  </div>
                  <div className="table-list d-block">
                    <table className="table table-borderless table-correnti">
                      <tbody style={{background: checked ? "#F2F2F2" : ""}}>
                        <tr>
                          <td className="text-uppercase fs-14 text-secondary px-3">
                            IBAN
                          </td>
                          <td className="text-capitalize fs-14 text-dark px-3">
                            {window.bankAccount.iban}
                          </td>
                        </tr>
                        <tr>
                          <td className="text-uppercase fs-14 text-secondary px-3">
                            INTESTATO A
                          </td>
                          <td className="text-capitalize fs-14 text-dark px-3">
                            {window.bankAccount.intestazione}
                          </td>
                        </tr>
                        <tr>
                          <td className="text-uppercase fs-14 text-secondary px-3">
                            BANCA
                          </td>
                          <td className="text-capitalize fs-14 text-dark px-3">
                            {window.bankAccount.banca}
                          </td>
                        </tr>
                        <tr>
                          <td className="text-uppercase fs-14 text-secondary px-3">
                            ABI
                          </td>
                          <td className="text-capitalize fs-14 text-dark px-3">
                            {window.bankAccount.abi}
                          </td>
                        </tr>
                        <tr>
                          <td className="text-uppercase fs-14 text-secondary px-3">
                            CAB
                          </td>
                          <td className="text-capitalize fs-14 text-dark px-3">
                            {window.bankAccount.cab}
                          </td>
                        </tr>
                        <tr>
                          <td className="text-uppercase fs-14 text-secondary px-3">
                            CIN
                          </td>
                          <td className="text-capitalize fs-14 text-dark px-3">
                            {window.bankAccount.cin}
                          </td>
                        </tr>
                        <tr>
                          <td className="text-uppercase fs-14 text-secondary px-3">
                            CONTO
                          </td>
                          <td className="text-capitalize fs-14 text-dark px-3">
                            {window.bankAccount.conto}
                          </td>
                        </tr>
                        <tr>
                          <td className="text-uppercase fs-14 text-secondary px-3">
                            BIC/SWIFT
                          </td>
                          <td className="text-capitalize fs-14 text-dark px-3">
                            {window.bankAccount.bic}
                          </td>
                        </tr>
                        <tr>
                          <td className="text-uppercase fs-14 text-secondary px-3">
                            Codice SIA
                          </td>
                          <td className="text-capitalize fs-14 text-dark px-3">
                            {window.bankAccount.sia}
                          </td>
                        </tr>
                        <tr>
                          <td className="text-uppercase fs-14 text-secondary px-3">
                            agenzia
                          </td>
                          <td className="text-capitalize fs-14 text-dark px-3">
                            {window.bankAccount.agenzia}
                          </td>
                        </tr>
                        <tr>
                          <td className="text-uppercase fs-14 text-secondary px-3">
                            sepa cuc
                          </td>
                          <td className="text-capitalize fs-14 text-dark px-3">
                            {window.bankAccount.sepa}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
            <div className="col-12">
              <div className="d-flex align-items-center mt-5 form-last-btns justify-content-end">
                <button
                  type="button"
                  className="back-btn btn-last rounded-3 shadow w-193 me-2 border-0"
                  onClick={() => props.back()}
                >
                  Annulla
                </button>
                <button
                  type="button"
                  className="next-btn btn-last rounded-3 shadow w-193 border-0"
                  onClick={() => props.next()}
                >
                  Avanti
                </button>
              </div>
            </div>
          </div>
        </div>
      </Form>
      <CreateAccount show={create} setAdd={(v) => setCreate(v)} setDel={(v) => setDel(v)} setChecked={(v) => setChecked(v)} />
      <DeleteConfirm show={del} confirm={() => reset()} setDel={(v) => setDel(v)} />
    </div>
  );
}
