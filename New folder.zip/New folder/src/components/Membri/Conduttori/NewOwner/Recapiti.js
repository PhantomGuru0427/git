import React, { useState } from "react";
import "../../../../assets/css/Membri.css";
import { BsFillPlusCircleFill } from "react-icons/bs";
import Form from "react-bootstrap/Form";
import ContactDetails from "./ContactDetails";
import EmailDetails from "./EmailDetails";

const Recapiti = (props) => {
  const [isAddContact, setIsAddContact] = useState(false);
  const [isAddEmail, setIsAddEmail] = useState(false);
  const [contactDetails, setContactDetails] = useState([]);
  const [emailDetails, setEmailDetails] = useState([]);

  const addContact = (selected) => {
    let details = contactDetails;
    details.push(selected);
    setContactDetails(details);
  };
  const addEmail = (selected) => {
    let details = emailDetails;
    details.push(selected);
    setEmailDetails(details);
  };

  return (
    <div className="d-block w-100 mb-3 bg-white" style={{borderRadius: "16px"}}>
      <Form>
        <div className="form-item-align-box d-block pt-5 pb-5">
          <div className="label-heading my-4 d-block w-100">
            <div className="label-text rel d-inline-block py-2 px-2">
              <h1 className="fs-16 text-white text-uppercase fw-semibold">
                RESIDENZA
              </h1>
            </div>
          </div>
          <div className="row gy-4">
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Indirizzo (Via/V.le/Piazza/Corso ecc)
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Civico
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Comune
                </label>
                <select className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white">
                  <option>Select</option>
                  <option>Select</option>
                  <option>Select</option>
                </select>
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Provincia
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                />
              </div>
            </div>
          </div>
          <div className="label-heading my-4 d-block w-100">
            <div className="label-text rel d-inline-block py-2 px-2">
              <h1 className="fs-16 text-white text-uppercase fw-semibold">
                INDIRIZZO DI CORRISPONDENZA
              </h1>
            </div>
          </div>
          <div className="row gy-4">
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Presso <i className="fal fa-exclamation-circle"></i>
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Indirizzo (Via/V.le/Piazza/Corso ecc)
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Civico
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Comune
                </label>
                <select className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white">
                  <option>Select</option>
                  <option>Select</option>
                  <option>Select</option>
                </select>
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Provincia
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                />
              </div>
            </div>
          </div>
          <div className="label-heading my-4 d-block w-100">
            <div className="label-text rel d-inline-block py-2 px-2">
              <h1 className="fs-16 text-white text-uppercase fw-semibold">
                RECAPITI TELEFONICI
              </h1>
            </div>
          </div>
          <div className="row gy-4">
            <div className="row gy-4">
              <InputComponent Name="Telefono casa" />
              <InputComponent Name="Telefono ufficio" />
              <InputComponent Name="Telefono cellulare" />
              <InputComponent Name="Fax" />
              <InputComponent Name="Skype" />
              {contactDetails.map((detail, index) => {
                return <InputComponent Name={detail} key={index} />;
              })}
            </div>
            <div className="col-12">
              <button
                type="button"
                className="other-contact p-0 text-dark fs-16 bg-transparent border-0 fw-semibold"
                onClick={() => setIsAddContact(true)}
              >
                <BsFillPlusCircleFill /> Aggiungi altri recapiti
              </button>
            </div>
          </div>
          <div className="label-heading my-4 d-block w-100">
            <div className="label-text rel d-inline-block py-2 px-2">
              <h1 className="fs-16 text-white text-uppercase fw-semibold">
                POSTA ELETTRONICA
              </h1>
            </div>
          </div>
          <div className="row gy-4">
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Email per notifiche
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                />
              </div>
            </div>
            <div className="col-md-6">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2">
                  Email posta certificata (PEC)
                </label>
                <input
                  type="text"
                  className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                />
              </div>
            </div>
            {emailDetails.map((detail, index) => {
              return <InputComponent Name={detail} key={index} />;
            })}
            <div className="col-12">
              <button
                type="button"
                className="other-contact p-0 text-dark fs-16 bg-transparent border-0 fw-semibold"
                onClick={() => setIsAddEmail(true)}
              >
                <BsFillPlusCircleFill /> Aggiungi altre email
              </button>
              <div className="d-flex align-items-center mt-5 form-last-btns justify-content-end">
                <button
                  type="button"
                  className="back-btn btn-last rounded-3 shadow w-193 me-2 border-0"
                  onClick={() => props.back()}
                >
                  Annulla
                </button>
                <button
                  type="button"
                  className="next-btn btn-last rounded-3 shadow w-193 border-0"
                  onClick={() => props.next()}
                >
                  Avanti
                </button>
              </div>
            </div>
          </div>
        </div>
      </Form>
      <ContactDetails
        show={isAddContact}
        addContact={(v) => addContact(v)}
        setAdd={(v) => setIsAddContact(v)}
      />
      <EmailDetails
        show={isAddEmail}
        addEmail={(v) => addEmail(v)}
        setAdd={(v) => setIsAddEmail(v)}
      />
    </div>
  );
};

const InputComponent = ({ Name }) => {
  return (
    <div className="col-md-6">
      <div className="d-flex flex-column">
        <label htmlFor="" className="f-label fs-16 mb-2">
          {Name}
        </label>
        <input
          type="text"
          className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
        />
      </div>
    </div>
  );
};

export default Recapiti;
