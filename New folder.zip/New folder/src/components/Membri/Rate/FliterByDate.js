import React, { useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { BsCalendar2Event } from "react-icons/bs";
import Form from "react-bootstrap/Form";
import "../../../assets/css/Rate.css";

export default function FliterByDate() {
  const [startDate, setStartDate] = useState(new Date());
  const [startDate1, setStartDate1] = useState(new Date());
  return (
    <>
      <div className="d-block bg-white rounded-3 p-3 w-274 date-filter-box shadow ">
        <Form>
          <div className="row gy-4">
            <div className="col-12">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2 text-dark">
                  Dal
                </label>
                <div className="d-flex rel align-items-center justify-content-between border border-secondary rounded-3 border-opacity-50">
                  {/* <input
                    type="text"
                    className="border-0 fs-16 text-dark flex-grow-1"
                  /> */}
                  <DatePicker
                    className="border-0 fs-16 text-dark flex-grow-1 w-100 px-3 rel zi-4 bg-transparent"
                    selected={startDate}
                    onChange={(date) => setStartDate(date)}
                  />
                  <span className="date-icon position-absolute zi-2 cur">
                    <BsCalendar2Event />
                  </span>
                </div>
              </div>
            </div>
            <div className="col-12">
              <div className="d-flex flex-column">
                <label htmlFor="" className="f-label fs-16 mb-2 text-dark">
                  Al
                </label>
                <div className="d-flex rel align-items-center justify-content-between border border-secondary rounded-3 border-opacity-50">
                  {/* <input
                    type="text"
                    className="border-0 fs-16 text-dark flex-grow-1"
                  /> */}
                  <DatePicker
                    className="border-0 fs-16 text-dark flex-grow-1 w-100 px-3 rel zi-4 bg-transparent"
                    selected={startDate1}
                    onChange={(date) => setStartDate1(date)}
                  />
                  <span className="date-icon position-absolute zi-2 cur">
                    <BsCalendar2Event />
                  </span>
                </div>
              </div>
            </div>
            <div className="col-12">
              <div className="d-flex flex-column">
                <button
                  type="button"
                  className="w-100 d-block rounded-3 py-2 text-white action-btn border-0 fs-16"
                >
                  Applica
                </button>
                <button
                  type="button"
                  className="w-100 d-block rounded-3 py-2 text-dark border-0 mt-1 bg-white fs-16"
                >
                  Rimuovi
                </button>
              </div>
            </div>
          </div>
        </Form>
      </div>
    </>
  );
}
