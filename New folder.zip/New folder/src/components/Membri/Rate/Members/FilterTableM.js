import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import MediaQuery from "react-responsive";
import dropLines from "../../../../assets/images/dwon-lines.svg";
import "../../../../assets/css/Rate.css";
// import userImg from "../../../assets/images/lightimg.png";
import homeImg from "../../../../assets/images/home.svg";
import { Link } from "react-router-dom";
import MembriBtn from "../MembriBtn";
import CheckBoxMember from "../CheckBoxMember";

export default function FilterTableM() {
  const [isActive, setIsActive] = useState(false);
  const [isActive1, setIsActive1] = useState(false);
  const [isActive2, setIsActive2] = useState(false);
  const [isActive3, setIsActive3] = useState(false);

  const handleClick = (event) => {
    // 👇️ toggle isActive state on click
    setIsActive((current) => !current);
  };
  const handleClick1 = (event) => {
    // 👇️ toggle isActive state on click
    setIsActive1((current) => !current);
  };
  const filterBtn = (event) => {
    // 👇️ toggle isActive state on click
    setIsActive2((current) => !current);
  };
  const memBtn = (event) => {
    // 👇️ toggle isActive state on click
    setIsActive3((current) => !current);
  };

  return (
    <>
      <MediaQuery minWidth={768}>
        <div className="d-flex flex-row-reverse mt-4">
          <div className="d-flex align-items-center top-filter">
            <h4 className="fs-14 text-dark fw-semibold me-2">Filtra per</h4>
            <div className="d-flex me-2 active rel">
              <Link
                to="/membersrata"
                className="mebtn  fs-14 text-white py-2 px-3 border-0"
              >
                Membri
              </Link>
              <MembriBtn />
            </div>
            <div className="">
              <Link
                to="/unitRata"
                className="unibtn fs-14 text-dark bg-white rounded-3 py-2 px-3 d-inline-block"
              >
                Unità
              </Link>
            </div>
          </div>
        </div>
        <div className="d-block ms-3 mt-4">
          <table className="table table-borderless midloop-table drop-table align-middle">
            <thead>
              <tr>
                <th>Nominativo</th>
                <th>Membro</th>
                <th>Totale dovuto</th>
                <th>Totale versato</th>
                <th>Saldo</th>
                <th>Saldo scaduto</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="position-relative">
                  <button
                    type="button"
                    onClick={handleClick}
                    className="updwon-icon border-0 bg-transparent"
                  >
                    <i
                      className={
                        isActive ? "fas fa-caret-up" : "fas fa-caret-down"
                      }
                    ></i>
                  </button>
                  <div className="d-flex align-items-center">
                    <div className="flex-shrink-0 me-3">
                      <div className="name-al w-56 h-56 rounded-circle overflow-hidden color1">
                        <h6 className="text-white fs-16 fw-semibold">A</h6>
                      </div>
                      {/*
                if user image to show
                <div className="user-img w-56 h-56 rounded-circle overflow-hidden color1 fw-100">
                  <img src={userImg} alt="user" />
                </div> */}
                    </div>
                    <div className="flex-grow-1">
                      <h4 className="fs-16 text-dark fw-semibold">
                        Mario Rossi
                      </h4>
                    </div>
                  </div>
                </td>
                <td>
                  <h4 className="fs-16 text-dark fw-semibold">Conduttore</h4>
                </td>
                <td>
                  <h4 className="fs-16 text-dark fw-semibold">1000 $</h4>
                </td>
                <td>
                  <h4 className="fs-16 text-dark fw-semibold">1000 $</h4>
                </td>
                <td>
                  <div className="d-flex align-items-center">
                    <span className="flex-shrink-0 me-3 bg-green w-22 h-22 rounded-circle"></span>
                    <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                      0 $
                    </h4>
                  </div>
                </td>
                <td>
                  <div className="d-flex align-items-center">
                    <span className="flex-shrink-0 me-3 bg-green w-22 h-22 rounded-circle"></span>
                    <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                      0 $
                    </h4>
                  </div>
                </td>
              </tr>
              <tr className={isActive ? "" : "showrow-click"}>
                <td className="position-relative">
                  <Link to="/members-details">
                    <div className="d-flex align-items-center">
                      <div className="flex-shrink-0 me-3">
                        {/* <div className="name-al w-56 h-56 rounded-circle overflow-hidden color1">
                      <h6 className="text-white fs-16 fw-semibold">A</h6>
                    </div> */}

                        <div className="user-img w-56 h-56 rounded-circle overflow-hidden fw-100 p-2">
                          <img src={homeImg} alt="user" />
                        </div>
                      </div>
                      <div className="flex-grow-1">
                        <h4 className="fs-16 text-dark fw-semibold">
                          Casa Rossi
                        </h4>
                      </div>
                    </div>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <h4 className="fs-16 text-dark fw-semibold invisible h-100">
                      Casa Rossi
                    </h4>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <h4 className="fs-16 text-dark fw-semibold">500 $</h4>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <h4 className="fs-16 text-dark fw-semibold">500 $</h4>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <div className="d-flex align-items-center">
                      <span className="flex-shrink-0 me-3 bg-green w-22 h-22 rounded-circle"></span>
                      <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                        0 $
                      </h4>
                    </div>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <div className="d-flex align-items-center">
                      <span className="flex-shrink-0 me-3 bg-green w-22 h-22 rounded-circle"></span>
                      <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                        0 $
                      </h4>
                    </div>
                  </Link>
                </td>
              </tr>
              <tr className={isActive ? "" : "showrow-click"}>
                <td className="position-relative">
                  <Link to="/members-details">
                    <div className="d-flex align-items-center">
                      <div className="flex-shrink-0 me-3">
                        {/* <div className="name-al w-56 h-56 rounded-circle overflow-hidden color1">
                      <h6 className="text-white fs-16 fw-semibold">A</h6>
                    </div> */}

                        <div className="user-img w-56 h-56 rounded-circle overflow-hidden fw-100 p-2">
                          <img src={homeImg} alt="user" />
                        </div>
                      </div>
                      <div className="flex-grow-1">
                        <h4 className="fs-16 text-dark fw-semibold">
                          Villa Gialli
                        </h4>
                      </div>
                    </div>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <h4 className="fs-16 text-dark fw-semibold invisible h-100">
                      Casa Rossi
                    </h4>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <h4 className="fs-16 text-dark fw-semibold">500 $</h4>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <h4 className="fs-16 text-dark fw-semibold">500 $</h4>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <div className="d-flex align-items-center">
                      <span className="flex-shrink-0 me-3 bg-green w-22 h-22 rounded-circle"></span>
                      <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                        0 $
                      </h4>
                    </div>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <div className="d-flex align-items-center">
                      <span className="flex-shrink-0 me-3 bg-green w-22 h-22 rounded-circle"></span>
                      <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                        0 $
                      </h4>
                    </div>
                  </Link>
                </td>
              </tr>
              <tr>
                <td className="position-relative">
                  <button
                    type="button"
                    onClick={handleClick1}
                    className="updwon-icon border-0 bg-transparent"
                  >
                    <i className="fas fa-caret-down"></i>
                  </button>
                  <div className="d-flex align-items-center">
                    <div className="flex-shrink-0 me-3">
                      <div className="name-al w-56 h-56 rounded-circle overflow-hidden bg-green">
                        <h6 className="text-white fs-16 fw-semibold">A</h6>
                      </div>
                      {/*
                if user image to show
                <div className="user-img w-56 h-56 rounded-circle overflow-hidden color1 fw-100">
                  <img src={userImg} alt="user" />
                </div> */}
                    </div>
                    <div className="flex-grow-1">
                      <h4 className="fs-16 text-dark fw-semibold">
                        Aldo Parodi
                      </h4>
                    </div>
                  </div>
                </td>
                <td>
                  <h4 className="fs-16 text-dark fw-semibold">Proprietario</h4>
                </td>
                <td>
                  <h4 className="fs-16 text-dark fw-semibold">1000 $</h4>
                </td>
                <td>
                  <h4 className="fs-16 text-dark fw-semibold">1000 $</h4>
                </td>
                <td>
                  <div className="d-flex align-items-center">
                    <span className="flex-shrink-0 me-3 bg-green w-22 h-22 rounded-circle"></span>
                    <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                      0 $
                    </h4>
                  </div>
                </td>
                <td>
                  <div className="d-flex align-items-center">
                    <span className="flex-shrink-0 me-3 bg-green w-22 h-22 rounded-circle"></span>
                    <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                      0 $
                    </h4>
                  </div>
                </td>
              </tr>
              <tr className={isActive1 ? "" : "showrow-click"}>
                <td className="position-relative">
                  <Link to="/members-details">
                    <div className="d-flex align-items-center">
                      <div className="flex-shrink-0 me-3">
                        {/* <div className="name-al w-56 h-56 rounded-circle overflow-hidden color1">
                      <h6 className="text-white fs-16 fw-semibold">A</h6>
                    </div> */}

                        <div className="user-img w-56 h-56 rounded-circle overflow-hidden fw-100 p-2">
                          <img src={homeImg} alt="user" />
                        </div>
                      </div>
                      <div className="flex-grow-1">
                        <h4 className="fs-16 text-dark fw-semibold">
                          Casa Rossi
                        </h4>
                      </div>
                    </div>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <h4 className="fs-16 text-dark fw-semibold invisible h-100">
                      Casa Rossi
                    </h4>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <h4 className="fs-16 text-dark fw-semibold">500 $</h4>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <h4 className="fs-16 text-dark fw-semibold">500 $</h4>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <div className="d-flex align-items-center">
                      <span className="flex-shrink-0 me-3 bg-green w-22 h-22 rounded-circle"></span>
                      <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                        0 $
                      </h4>
                    </div>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <div className="d-flex align-items-center">
                      <span className="flex-shrink-0 me-3 bg-green w-22 h-22 rounded-circle"></span>
                      <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                        0 $
                      </h4>
                    </div>
                  </Link>
                </td>
              </tr>
              <tr className={isActive1 ? "" : "showrow-click"}>
                <td className="position-relative">
                  <Link to="/members-details">
                    <div className="d-flex align-items-center">
                      <div className="flex-shrink-0 me-3">
                        {/* <div className="name-al w-56 h-56 rounded-circle overflow-hidden color1">
                      <h6 className="text-white fs-16 fw-semibold">A</h6>
                    </div> */}

                        <div className="user-img w-56 h-56 rounded-circle overflow-hidden fw-100 p-2">
                          <img src={homeImg} alt="user" />
                        </div>
                      </div>
                      <div className="flex-grow-1">
                        <h4 className="fs-16 text-dark fw-semibold">
                          Villa Gialli
                        </h4>
                      </div>
                    </div>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <h4 className="fs-16 text-dark fw-semibold invisible h-100">
                      Casa Rossi
                    </h4>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <h4 className="fs-16 text-dark fw-semibold">500 $</h4>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <h4 className="fs-16 text-dark fw-semibold">500 $</h4>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <div className="d-flex align-items-center">
                      <span className="flex-shrink-0 me-3 bg-green w-22 h-22 rounded-circle"></span>
                      <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                        0 $
                      </h4>
                    </div>
                  </Link>
                </td>
                <td>
                  <Link to="/members-details">
                    <div className="d-flex align-items-center">
                      <span className="flex-shrink-0 me-3 bg-green w-22 h-22 rounded-circle"></span>
                      <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                        0 $
                      </h4>
                    </div>
                  </Link>
                </td>
              </tr>
            </tbody>
            <tfoot className="five-box">
              <tr>
                <td></td>
                <td>
                  <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                    Totale complessivo
                  </h4>
                </td>
                <td>
                  <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                    1150 $
                  </h4>
                </td>
                <td>
                  <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                    1050 $
                  </h4>
                </td>
                <td>
                  <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                    100 $
                  </h4>
                </td>
                <td>
                  <h4 className="fs-16 text-dark fw-semibold flex-grow-1">
                    0 $
                  </h4>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </MediaQuery>
      <MediaQuery maxWidth={767}>
        <div className="d-flex flex-row-reverse mb-4 rel">
          <button
            type="button"
            className="bg-white border rounded-3 p-2"
            onClick={filterBtn}
          >
            <img src={dropLines} alt="lines" />
          </button>
          <div
            className={
              isActive2
                ? "d-block bg-white rounded-3 shadow p-3 position-absolute end-0 zi-5 filter-mob"
                : "d-none"
            }
          >
            <div className="d-flex flex-column top-filter">
              <h4 className="fs-14 text-dark fw-semibold mb-2">Filtra per</h4>
              <div className="d-flex align-items-center">
                <div className="d-flex me-2 active">
                  <Link
                    to="/membersrata"
                    className="mebtn  fs-14 text-white py-2 px-3 rounded-3 border-0"
                  >
                    Membri
                  </Link>
                </div>
                <div className="">
                  <Link
                    to="/unitRata"
                    className="unibtn fs-14 text-dark bg-white rounded-3 py-2 px-3 d-inline-block"
                  >
                    Unità
                  </Link>
                </div>
              </div>
              <div className="d-block mt-4">
                <div
                  className="d-flex justify-content-between"
                  onClick={memBtn}
                >
                  <h4 className="fs-14 text-dark fw-semibold mb-2">MEMBRI</h4>
                  <button type="button" className="bg-transparent border-0">
                    <i class="fal fa-angle-down"></i>
                  </button>
                </div>
                <div className={isActive3 ? "d-flex" : "d-none"}>
                  <CheckBoxMember />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="d-flex justify-content-between total-bal-green mb-4 rounded-3 px-4 py-2">
          <h4 className="fs-16 fw-semibold lh-base">Saldo Totale</h4>
          <h4 className="fs-20 fw-semibold">0€</h4>
        </div>

        <div className="d-block ms-4 ms-md-5 mb-3">
          <div className="d-flex justify-content-between align-items-center rel bg-white rounded-3 p-3 mb-2">
            <button
              type="button"
              onClick={handleClick}
              className="updwon-icon border-0 bg-transparent"
            >
              {isActive ? (
                <i className="fas fa-caret-up"></i>
              ) : (
                <i className="fas fa-caret-down"></i>
              )}
            </button>

            <div className="d-flex align-items-center">
              <div className="flex-shrink-0 me-3">
                <div className="name-al w-56 h-56 rounded-circle overflow-hidden color1">
                  <h6 className="text-white fs-16 fw-semibold">A</h6>
                </div>
                {/*
                if user image to show
                <div className="user-img w-56 h-56 rounded-circle overflow-hidden color1 fw-100">
                  <img src={userImg} alt="user" />
                </div> */}
              </div>
              <div className="flex-grow-1">
                <h4 className="fs-16 text-dark fw-semibold">Mario Rossi</h4>
              </div>
            </div>
            <h4 className="fs-16 fw-semibold text-green fs-24">0€</h4>
          </div>
          <div className={isActive ? "" : "showrow-click"}>
            <Link to="/members-details">
              <div className="d-flex justify-content-between align-items-center rel bg-white rounded-3 p-3 mb-2">
                <div className="d-flex align-items-center">
                  <div className="flex-shrink-0 me-3">
                    {/* <div className="name-al w-56 h-56 rounded-circle overflow-hidden color1">
                  <h6 className="text-white fs-16 fw-semibold">A</h6>
                </div> */}

                    {/* if user image to show */}
                    <div className="user-img w-56 h-56 rounded-circle overflow-hidden fw-100 p-2">
                      <img src={homeImg} alt="user" />
                    </div>
                  </div>
                  <div className="flex-grow-1">
                    <h4 className="fs-16 text-dark fw-semibold">Mario Rossi</h4>
                  </div>
                </div>
                <h4 className="fs-16 fw-semibold text-green fs-24">0€</h4>
              </div>
            </Link>
            <Link to="/members-details">
              <div className="d-flex justify-content-between align-items-center rel bg-white rounded-3 p-3 mb-2">
                <div className="d-flex align-items-center">
                  <div className="flex-shrink-0 me-3">
                    {/* <div className="name-al w-56 h-56 rounded-circle overflow-hidden color1">
                  <h6 className="text-white fs-16 fw-semibold">A</h6>
                </div> */}

                    {/* if user image to show */}
                    <div className="user-img w-56 h-56 rounded-circle overflow-hidden fw-100 p-2">
                      <img src={homeImg} alt="user" />
                    </div>
                  </div>
                  <div className="flex-grow-1">
                    <h4 className="fs-16 text-dark fw-semibold">Mario Rossi</h4>
                  </div>
                </div>
                <h4 className="fs-16 fw-semibold text-green fs-24">0€</h4>
              </div>
            </Link>
          </div>
        </div>
        <div className="d-block ms-4 ms-md-5 mb-3">
          <div className="d-flex justify-content-between align-items-center rel bg-white rounded-3 p-3 mb-2">
            <button
              type="button"
              onClick={handleClick1}
              className="updwon-icon border-0 bg-transparent"
            >
              {isActive1 ? (
                <i className="fas fa-caret-up"></i>
              ) : (
                <i className="fas fa-caret-down"></i>
              )}
            </button>
            <div className="d-flex align-items-center">
              <div className="flex-shrink-0 me-3">
                <div className="name-al w-56 h-56 rounded-circle overflow-hidden color1">
                  <h6 className="text-white fs-16 fw-semibold">A</h6>
                </div>
                {/*
                if user image to show
                <div className="user-img w-56 h-56 rounded-circle overflow-hidden color1 fw-100">
                  <img src={userImg} alt="user" />
                </div> */}
              </div>
              <div className="flex-grow-1">
                <h4 className="fs-16 text-dark fw-semibold">Mario Rossi</h4>
              </div>
            </div>
            <h4 className="fs-16 fw-semibold text-green fs-24">0€</h4>
          </div>
          <div className={isActive1 ? "" : "showrow-click"}>
            <Link to="/members-details">
              <div className="d-flex justify-content-between align-items-center rel bg-white rounded-3 p-3 mb-2">
                <div className="d-flex align-items-center">
                  <div className="flex-shrink-0 me-3">
                    {/* <div className="name-al w-56 h-56 rounded-circle overflow-hidden color1">
                  <h6 className="text-white fs-16 fw-semibold">A</h6>
                </div> */}

                    {/* if user image to show */}
                    <div className="user-img w-56 h-56 rounded-circle overflow-hidden fw-100 p-2">
                      <img src={homeImg} alt="user" />
                    </div>
                  </div>
                  <div className="flex-grow-1">
                    <h4 className="fs-16 text-dark fw-semibold">
                      Mario Rossi 2
                    </h4>
                  </div>
                </div>
                <h4 className="fs-16 fw-semibold text-green fs-24">10€</h4>
              </div>
            </Link>
            <Link to="/members-details">
              <div className="d-flex justify-content-between align-items-center rel bg-white rounded-3 p-3 mb-2">
                <div className="d-flex align-items-center">
                  <div className="flex-shrink-0 me-3">
                    {/* <div className="name-al w-56 h-56 rounded-circle overflow-hidden color1">
                  <h6 className="text-white fs-16 fw-semibold">A</h6>
                </div> */}

                    {/* if user image to show */}
                    <div className="user-img w-56 h-56 rounded-circle overflow-hidden fw-100 p-2">
                      <img src={homeImg} alt="user" />
                    </div>
                  </div>
                  <div className="flex-grow-1">
                    <h4 className="fs-16 text-dark fw-semibold">
                      Mario Rossi 1
                    </h4>
                  </div>
                </div>
                <h4 className="fs-16 fw-semibold text-green fs-24">10€</h4>
              </div>
            </Link>
          </div>
        </div>
      </MediaQuery>
    </>
  );
}
