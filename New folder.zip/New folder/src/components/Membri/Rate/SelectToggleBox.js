import React from "react";
export default function SelectToggleBox() {
  return (
    <select
      name=""
      id=""
      className="bg-white fs-14 text-uppercase fw-semibold text-dark rounded-3 w-100 border-0 p-3 shadow"
    >
      <option value="">Tutte le unità</option>
      <option value="">casa rossi</option>
      <option value="">appartamento rossi</option>
    </select>
  );
}
