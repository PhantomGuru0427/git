import React from "react";
import Form from "react-bootstrap/Form";
export default function CheckBoxMember() {
  return (
    <Form>
      {["checkbox"].map((type) => (
        <div key={`default-${type}`} className="cehck-row-full">
          <Form.Check type={type} id={`Tutti-${type}`} label={`Tutti`} />
          <Form.Check
            type={type}
            id={`Fornitore-${type}`}
            label={`Fornitore`}
          />
          <Form.Check
            type={type}
            id={`Proprietario-${type}`}
            label={`Proprietario`}
          />
          <Form.Check
            type={type}
            id={`Conduttore-${type}`}
            label={`Conduttore`}
          />
        </div>
      ))}
    </Form>
  );
}
