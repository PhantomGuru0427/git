import React from "react";
import Button from "react-bootstrap/Button";

import "../../../assets/css/Rate.css";
import { Link } from "react-router-dom";
import LogoMark from "../../../assets/images/logo_mark.svg";

export default function TopHeaderPart(props) {
  return (
    <>
      <div className="flex-grow-1 head-bar">
        <div className="d-flex flex-column">
          <Link to={props.pathLink} className="text-white fs-14">
            <i className="fal fa-long-arrow-left"></i> {props.backLinkText}
          </Link>
        </div>
        <div className="right-logo">
          <h3 className="fs-14 text-uppercase text-decoration-underline mb-0">
            MARIO ROSSI
          </h3>
          <img src={LogoMark} alt="logo mark" className="logo-mark" />
        </div>
      </div>
      <div
        className="d-flex 
       justify-content-between align-items-md-center topHeading-title"
      >
        <h3 className="fs-24 fs-md-30 text-dark fw-semibold mt-3 mb-3 mb-md-0">
          {props.heading}
        </h3>
        <div className="flex-shrink-0" style={{minWidth: "150px"}}>
          <div className="d-flex align-items-center">
            <div className="d-flex flex-md-column align-items-center w-md-150 text-center rounded-3 shadow py-2 px-3 balance-box">
              <h3 className="fs-14 text-white fw-normal w-100 me-2 me-md-0 ">
                Saldo
              </h3>
              <h4 className="fs-20 text-white fw-semibold w-100">$1000</h4>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
