import React, { useState } from "react";
import SelectToggleBox from "../SelectToggleBox";
import TopHeaderPart from "../TopHeaderPart";
import dropLines from "../../../../assets/images/dwon-lines.svg";
import FliterByDate from "../FliterByDate";
import MonthRateU from "./MonthRateU";
import MediaQuery from "react-responsive";
import Container from "../../../Container";

export default function InnerDetailsU() {
  const [isActive, setIsActive] = useState(false);
  const handleClick = (event) => {
    // 👇️ toggle isActive state on click
    setIsActive((current) => !current);
  };
  return (
    <Container>
      <TopHeaderPart
        pathLink="/membersrata"
        backLinkText="Torna alla lista"
        heading="Mario Rossi"
      />
      <div className="d-block my-5">
        <SelectToggleBox textToggle="Tutte le unità" />
      </div>
      <div className="d-block mb-4">
        <div className="d-flex justify-content-between align-items-center">
          <h3 className="fs-24 text-dark fw-semibold text-uppercase flex-shrink-0">
            Rate
          </h3>
          <div className="border-top border-1 border-secondary border-opacity-50 flex-grow-1 mx-3"></div>
          <div className="d-flex flex-column position-relative">
            <button
              className="bg-white border rounded-3 p-2"
              onClick={handleClick}
            >
              <img src={dropLines} alt="lines" />
            </button>
            <div className={isActive ? "d-block option-unit" : "d-none"}>
              <FliterByDate />
            </div>
          </div>
        </div>
      </div>
      <MediaQuery minWidth={768}>
        <div className="d-block mb-4">
          <div className="d-flex flex-column">
            <h3 className="fs-20 text-dark fw-bold mb-4 text-uppercase">
              Luglio 2022
            </h3>
            <MonthRateU />
          </div>
          <div className="d-flex flex-column">
            <h3 className="fs-20 text-dark fw-bold mb-4 text-uppercase">
              Giugno 2022
            </h3>
            <MonthRateU />
            <MonthRateU />
          </div>
        </div>
      </MediaQuery>
      <MediaQuery maxWidth={767}>
        <div className="d-flex flex-column">
          <h3 className="fs-18 text-dark fw-bold mb-4 text-uppercase">
            Luglio 2022
          </h3>
          <MonthRateU />
          <h3 className="fs-18 text-dark fw-bold mb-4 text-uppercase mb-2">
            Giugno 2022
          </h3>
          <MonthRateU />
        </div>
      </MediaQuery>
    </Container>
  );
}
