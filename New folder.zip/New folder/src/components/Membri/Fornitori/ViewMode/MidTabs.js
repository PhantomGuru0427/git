import React, { useState } from "react";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import AllegatiV from "./AllegatiV";
import AnagraficaV from "./AnagraficaV";
import CorrentiV from "./CorrentiV";
import DocumentoV from "./DocumentoV";
import FornitoriV from "./FornitoriV";
import NoteV from "./NoteV";
import RecapitiV from "./RecapitiV";
import UnitaV from "./UnitaV";

import TopArrow from "../../../../assets/images/select-up-arrow.svg";
import DownArrow from "../../../../assets/images/select-down-arrow.svg";

import "../../../../assets/css/Membri.css";

export default function MidTabs() {
  const [key, setKey] = useState("anagrafica");
  const [count, setCount] = useState(1);
  const [clicked, setClicked] = useState(false);

  const forward = () => {
    var num = count;
    if (num <= 5) {
      setCount(++num);
    }
  };

  const backward = () => {
    var num = count;
    if (num > 1) {
      setCount(--num);
    }
  };

  const tab1Click = () => {
    setCount(1);
  };
  const tab2Click = () => {
    setCount(2);
  };
  const tab3Click = () => {
    setCount(3);
  };
  const tab4Click = () => {
    setCount(4);
  };
  const tab5Click = () => {
    setCount(5);
  };

  const returnContent = (count) => {
    switch (count) {
      case 1:
        return <AnagraficaV />;
      case 2:
        return <RecapitiV />;
      case 3:
        return <CorrentiV />;
      case 4:
        return <NoteV />;
      case 5:
        return <AllegatiV />;
      default:
        return <AnagraficaV />;
    }
  };

  const tabSelect = (e) => {
    switch (e.target.value) {
      case "ana":
        tab1Click();
        break;
      case "rec":
        tab2Click();
        break;
      case "con":
        tab3Click();
        break;
      case "not":
        tab4Click();
        break;
      case "all":
        tab5Click();
        break;
      default:
        tab1Click();
        break;
    }
  };

  return (
    <div className="mt-30 ">
      <div className="justify-content-center d-flex tabs-select-div">
          <select
            className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white tabs-select"
            onChange={(e) => tabSelect(e)}
            onClick={() => setClicked(!clicked)}
          >
            <option value="ana">Anagrafica</option>
            <option value="rec">Recapiti</option>
            <option value="con">Conti Correnti</option>
            <option value="not">Note</option>
            <option value="all">Allegati</option>
          </select>
          <img src={clicked ? DownArrow : TopArrow} style={{display: "absolute", marginLeft: clicked ? "-43px" : "-37px"}} ></img>
      </div>
      <div className="justify-content-center tabs-title-div">
        <div
          className="tabs-title w-110"
          onClick={() => tab1Click()}
          style={{
            background: count === 1 ? "#83112F" : "",
            color: count === 1 ? "#FFFFFF" : "",
          }}
        >
          Anagrafica
        </div>
        <div
          className="tabs-title w-110"
          onClick={() => tab2Click()}
          style={{
            background: count === 2 ? "#83112F" : "",
            color: count === 2 ? "#FFFFFF" : "",
          }}
        >
          Recapiti
        </div>
        <div
          className="tabs-title w-140"
          onClick={() => tab3Click()}
          style={{
            background: count === 3 ? "#83112F" : "",
            color: count === 3 ? "#FFFFFF" : "",
          }}
        >
          Conti Correnti
        </div>
        <div
          className="tabs-title w-70"
          onClick={() => tab4Click()}
          style={{
            background: count === 4 ? "#83112F" : "",
            color: count === 4 ? "#FFFFFF" : "",
          }}
        >
          Note
        </div>
        <div
          className="tabs-title w-90"
          onClick={() => tab5Click()}
          style={{
            background: count === 5 ? "#83112F" : "",
            color: count === 5 ? "#FFFFFF" : "",
          }}
        >
          Allegati
        </div>
      </div>
      <div className="mt-25">
        <div className="tabContent-div">{returnContent(count)}</div>
      </div>
    </div>
  );
}
