import React from "react";
import { BsCalendar2Event } from "react-icons/bs";
import PrintDwonloadIcons from "./PrintDwonloadIcons";

export default function AnagraficaV() {
  return (
    <>
      <PrintDwonloadIcons />
      <fieldset disabled={true}>
        <div className="row mt-4">
          <div className="col-12">
            <div className="form-item-align-box">
              <div className="row gy-4">
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Denominazione o ragione sociale
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Tipo di soggetto
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Codice fiscale*
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      P. IVA
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Categoria
                    </label>
                    <select className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50 bg-white">
                      <option>assicurazione</option>
                      <option>geometra</option>
                      <option>idraulico</option>
                      <option>notaio</option>
                      <option>riparazioni varie</option>
                      <option>ristrutturazioni</option>
                      <option>stato</option>
                      <option>utenze - energia</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="label-heading my-4 d-block w-100">
                <div className="label-text rel d-inline-block py-2 px-2">
                  <h1 className="fs-16 text-white text-uppercase fw-semibold">
                    CONTATTO
                  </h1>
                </div>
              </div>
              <div className="row gy-4">
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Nome
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="d-flex flex-column">
                    <label htmlFor="" className="f-label fs-16 mb-2">
                      Cognome
                    </label>
                    <input
                      type="text"
                      className="border border-secondary fs-16 text-dark rounded-3 border-opacity-50"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </fieldset>
    </>
  );
}
