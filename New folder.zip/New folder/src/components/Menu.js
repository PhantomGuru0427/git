import React, { useState } from "react";
import { Link } from "react-router-dom";
import { BsChevronDown, BsChevronUp } from "react-icons/bs";
import icon1 from "../assets/images/m1.svg";
import icon2 from "../assets/images/m2.svg";
import icon3 from "../assets/images/m3.svg";
import icon4 from "../assets/images/m4.svg";
import icon5 from "../assets/images/m5.svg";
import icon6 from "../assets/images/m6.svg";
import icon7 from "../assets/images/m7.svg";
import icon8 from "../assets/images/m8.svg";

export default function Menu(props) {
  const [subMenuOpened, setSubMenuOpened] = useState([
    true,
    true,
    true,
    true,
    true,
    true,
  ]);
  const onHandleCollapse = (index) => {
    const tempSubMenu = [true, true, true, true, true, true];
    if (subMenuOpened[index] !== false) {
      tempSubMenu[index] = false;
    }

    setSubMenuOpened(tempSubMenu);
  };
  const setMobileMenu = () => {
    if (typeof props.setMobileMenu == "function") {
      props.setMobileMenu(false);
    }
  };
  return (
    <>
      <ul className="menu-list ls p-0">
        <li>
          <Link to="/" onClick={setMobileMenu}>
            <span className="icon-link">
              <img src={icon1} alt="image" />{" "}
            </span>
            <span className="text-link">Dashboard</span>
          </Link>
        </li>
        <li
          className={`dropdwon-link ${subMenuOpened[0] ? "" : "dropdwon-open"}`}
        >
          <button
            onClick={() => {
              onHandleCollapse(0);
            }}
            className="d-flex w-100 justify-content-between align-items-center p-0 bg-transparent border-0 text-start"
          >
            <span className="icon-link">
              <img src={icon2} alt="icon" />
            </span>

            <span className="text-link">Unità Immobiliari e Condomini</span>
            {subMenuOpened[0] ? (
              <BsChevronDown className="icon-down" />
            ) : (
              <BsChevronUp className="icon-down" />
            )}
          </button>
          <div className="sub-links">
            <ul className="ls d-flex flex-column">
              <li>
                <Link to="/" onClick={setMobileMenu}>
                  Link
                </Link>
              </li>
              <li>
                <Link to="/" onClick={setMobileMenu}>
                  Link
                </Link>
              </li>
              <li>
                <Link to="/" onClick={setMobileMenu}>
                  Link
                </Link>
              </li>
            </ul>
          </div>
        </li>
        <li>
          <Link to="/" onClick={setMobileMenu}>
            <span className="icon-link">
              <img src={icon3} alt="icon" />
            </span>
            <span className="text-link">Affitti</span>
          </Link>
        </li>
        <li
          className={`dropdwon-link ${subMenuOpened[1] ? "" : "dropdwon-open"}`}
        >
          <button
            onClick={() => {
              onHandleCollapse(1);
            }}
            className="d-flex w-100 justify-content-between align-items-center p-0 bg-transparent border-0 text-start"
          >
            <span className="icon-link">
              <img src={icon4} alt="icon" />
            </span>

            <span className="text-link">Stato Lavori in Corso</span>
            {subMenuOpened[1] ? (
              <BsChevronDown className="icon-down" />
            ) : (
              <BsChevronUp className="icon-down" />
            )}
          </button>
          <div className="sub-links">
            <ul className="ls d-flex flex-column">
              <li>
                <Link to="/" onClick={setMobileMenu}>
                  Link
                </Link>
              </li>
              <li>
                <Link to="/" onClick={setMobileMenu}>
                  Link
                </Link>
              </li>
              <li>
                <Link to="/" onClick={setMobileMenu}>
                  Link
                </Link>
              </li>
            </ul>
          </div>
        </li>
        <li
          className={`dropdwon-link ${subMenuOpened[2] ? "" : "dropdwon-open"}`}
        >
          <button
            onClick={() => {
              onHandleCollapse(2);
            }}
            className="d-flex w-100 justify-content-between align-items-center p-0 bg-transparent border-0 text-start"
          >
            <span className="icon-link">
              {" "}
              <img src={icon5} alt="icon" />
            </span>

            <span className="text-link">Membri</span>
            {subMenuOpened[2] ? (
              <BsChevronDown className="icon-down" />
            ) : (
              <BsChevronUp className="icon-down" />
            )}
          </button>
          <div className="sub-links">
            <ul className="ls d-flex flex-column">
              <li>
                <Link to="/propriietari" onClick={setMobileMenu}>
                  Proprietari/Sublocatori
                </Link>
              </li>
              <li>
                <Link to="/conduttori" onClick={setMobileMenu}>
                  Conduttori
                </Link>
              </li>
              <li>
                <Link to="/fornitori" onClick={setMobileMenu}>
                  Fornitori
                </Link>
              </li>
              <li>
                <Link to="/rate" onClick={setMobileMenu}>
                  Rate
                </Link>
              </li>
            </ul>
          </div>
        </li>
        <li
          className={`dropdwon-link ${subMenuOpened[3] ? "" : "dropdwon-open"}`}
        >
          <button
            onClick={() => {
              onHandleCollapse(3);
            }}
            className="d-flex w-100 justify-content-between align-items-center p-0 bg-transparent border-0 text-start"
          >
            <span className="icon-link">
              {" "}
              <img src={icon6} alt="icon" />
            </span>

            <span className="text-link">Documenti</span>
            {subMenuOpened[3] ? (
              <BsChevronDown className="icon-down" />
            ) : (
              <BsChevronUp className="icon-down" />
            )}
          </button>
          <div className="sub-links">
            <ul className="ls d-flex flex-column">
              <li>
                <Link to="/prima-nota" onClick={setMobileMenu}>
                  Prima Nota
                </Link>
              </li>
              <li>
                <Link to="/modelli" onClick={setMobileMenu}>
                  Modelli
                </Link>
              </li>
            </ul>
          </div>
        </li>
        <li
          className={`dropdwon-link ${subMenuOpened[4] ? "" : "dropdwon-open"}`}
        >
          <button
            onClick={() => {
              onHandleCollapse(4);
            }}
            className="d-flex w-100 justify-content-between align-items-center p-0 bg-transparent border-0 text-start"
          >
            <span className="icon-link">
              {" "}
              <img src={icon7} alt="icon" />
            </span>

            <span className="text-link">Calcoli Immobilliari</span>
            {subMenuOpened[4] ? (
              <BsChevronDown className="icon-down" />
            ) : (
              <BsChevronUp className="icon-down" />
            )}
          </button>
          <div className="sub-links">
            <ul className="ls d-flex flex-column">
              <li>
                <Link to="/" onClick={setMobileMenu}>
                  Calcolatrice
                </Link>
              </li>
              <li>
                <Link to="/calcoli" onClick={setMobileMenu}>
                  Calcoli
                </Link>
              </li>
            </ul>
          </div>
        </li>
        <li
          className={`dropdwon-link ${subMenuOpened[5] ? "" : "dropdwon-open"}`}
        >
          <button
            onClick={() => {
              onHandleCollapse(5);
            }}
            className="d-flex w-100 justify-content-between align-items-center p-0 bg-transparent border-0 text-start"
          >
            <span className="icon-link">
              {" "}
              <img src={icon8} alt="icon" />{" "}
            </span>

            <span className="text-link">Alert</span>
            {subMenuOpened[5] ? (
              <BsChevronDown className="icon-down" />
            ) : (
              <BsChevronUp className="icon-down" />
            )}
          </button>
          <div className="sub-links">
            <ul className="ls d-flex flex-column">
              <li>
                <Link to="/" onClick={setMobileMenu}>
                  Link
                </Link>
              </li>
              <li>
                <Link to="/" onClick={setMobileMenu}>
                  Link
                </Link>
              </li>
              <li>
                <Link to="/" onClick={setMobileMenu}>
                  Link
                </Link>
              </li>
            </ul>
          </div>
        </li>
      </ul>
    </>
  );
}
