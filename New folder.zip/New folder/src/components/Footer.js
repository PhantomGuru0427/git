import React from "react";
import "../assets/css/Footer.css";
import Logo from "../assets/images/logo.png";
import FacebookIcon from "../assets/images/facebook-icon.png";
import TwitterIcon from "../assets/images/twitter-icon.png";
import InstagramIcon from "../assets/images/instagram-icon.png";
import UpperArrow from "../assets/images/upperArrow.png";

export default function Footer() {
  return (
    <div className="footer">
      <div className="footer-container">
        <div>
          <img
            src={Logo}
            alt="logo"
            style={{ width: "80px", height: "40px" }}
          ></img>
          <div className="footer-logo-description">
            Designed by Anthill srls - Tutti i diritti sono riservati
          </div>
        </div>
        <div className="footer-description">
          <div className="main-description">Informative Legali</div>
          <div className="subdiscription-div">
            <div className="sub-description">Cookie Policy</div>
            <div className="sub-description">Legal policy</div>
            <div className="sub-description">Privacy Policy</div>
          </div>
        </div>
        <div className="footer-link-div">
          <div className="socialLink-div">
            <img src={FacebookIcon} alt="facebook"></img>
            <img src={TwitterIcon} alt="twitter"></img>
            <img src={InstagramIcon} alt="instagram"></img>
          </div>
          <img
            src={UpperArrow}
            alt="upperArrow"
            style={{ marginRight: "25px", width: "50px", height: "50px", cursor: "pointer" }}
            onClick={() => window.scrollTo(0, 0)}
          ></img>
        </div>
      </div>
    </div>
  );
}
