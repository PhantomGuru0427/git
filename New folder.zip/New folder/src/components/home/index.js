import React from 'react'
import Login from '../auth/login/Login';

export default function index() {
  return (
    <div style={{background: "#fff"}}>
        <Login />
    </div>
  )
}
