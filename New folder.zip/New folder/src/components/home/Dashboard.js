import React from "react";
import "../../assets/css/Dashboard.css";

export default function Dashboard() {
  return <div className="dash-title">The user lands on the DASHBOARD page</div>;
}
