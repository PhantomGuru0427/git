import React from "react";
import "../assets/css/ToggleSwitch.css";

const ToggleSwitch = ({label}) => {
  return (
    <>
    <label className="switch">
      <input type="checkbox" defaultChecked={true} />
      <span className="slider round"></span>
    </label>
    <span className="toggle-label">
    {label}
    </span>
    </>
  );
};

export default ToggleSwitch;
