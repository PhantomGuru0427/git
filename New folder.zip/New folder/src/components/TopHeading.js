import React, {useEffect, useState} from "react";
import LogoMark from "../assets/images/logo_mark.svg";
import ReturnIcon from "../assets/images/returnWhiteIcon.svg";

export default function TopHeading(props) {
  const [show, setShow] = useState(true);

  useEffect(() => {
    setShow(props.show);
  }, [props.show]);

  return (
    <>
      <div className="head-bar">
        <h3 className="fs-14 text-uppercase mt-auto mb-auto" style={{display: show ? "none" : ""}}>{props.SamllHeading}</h3>
        <img src={ReturnIcon}  style={{display: show ? "" : "none"}} onClick={() => props.setShow(false)} ></img>
        <div className="right-logo">
          <h3 className="fs-14 text-uppercase text-decoration-underline mb-0">
            MARIO ROSSI
          </h3>
          <img src={LogoMark} alt="logo mark" className="logo-mark" />
        </div>
      </div>
      <div>
        <h1 className="fs-24 fs-md-30 text-dark fw-bold mt-3">
          {props.Heading}
        </h1>
      </div>
    </>
  );
}
