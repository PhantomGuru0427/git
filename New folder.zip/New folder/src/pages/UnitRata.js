import React, { createContext } from "react";
import NewownerBtn from "../components/Membri/ProprietariSublocatori/NewownerBtn";
import FilterTableU from "../components/Membri/Rate/Unit/FilterTableU";
import TopHeading from "../components/TopHeading";
import Container from "../components/Container";

const RataText = createContext();

export default function UnitRata() {
  return (
    <Container>
      <div className="row gy-4 align-items-end mb-4 mt-4">
        <div className="col-md-6">
          <TopHeading SamllHeading="Membri" Heading="Rate" />
        </div>
      </div>
      <RataText.Provider value={"Nuova Rata"}>
        <NewownerBtn btnText="Nuovo rata" />
      </RataText.Provider>
      <div className="d-block mb-4 mt-4">
        <FilterTableU />
      </div>
    </Container>
  );
}
