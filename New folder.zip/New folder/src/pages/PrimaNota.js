import React, { createContext, useState } from "react";
import TopHeading from "../components/Membri/ProprietariSublocatori/TopHeading";
import EmptyList from "../components/Documenti/EmptyList";
import DocumentiBtn from "../components/Documenti/PrimaNota/DocumentiBtn";
import { connect } from "react-redux";
import Documents from "../components/Documenti/PrimaNota/Documents";
import Container from "../components/Container";
import "../assets/css/Documenti.css";

const CondutText = createContext();
function PrimaNota(props) {
  const [search_name, setSearchName] = useState("");
  return (
    <Container>
      <div className="title-search-group">
        <div className="right-header">
          <TopHeading SamllHeading="DOCUMENTI" Heading="Prima Nota" />
        </div>
        <div className="model-modul-group">
          <CondutText.Provider value={"Nuova Prima Nota"}>
            <DocumentiBtn
              btnText="Nuova Prima Nota"
              setSearchName={setSearchName}
            />
          </CondutText.Provider>
        </div>
      </div>
      {Object.keys(props.documents).length == 0 ? (
        <div className="d-block mb-4 mt-auto mb-auto">
          <EmptyList />
        </div>
      ) : (
        <Documents search_name={search_name} />
      )}
      {/* <div className="d-block mb-4 mt-auto mb-auto">
        <EmptyList />
      </div>
      <DocumentCard data={data} /> */}
    </Container>
  );
}
const mapStateToProps = (state) => ({
  documents: state.documentsReducer.documents,
});
export default connect(mapStateToProps, null)(PrimaNota);
