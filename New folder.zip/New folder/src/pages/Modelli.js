import React, { createContext } from "react";
import "../assets/css/Documenti.css";
import TopHeading from "../components/Membri/ProprietariSublocatori/TopHeading";
import ModelliBtn from "../components/Documenti/Modelli/ModelliBtn";
import ServerTemplate from "../components/Documenti/Modelli/ServerTemplate";
import UserTemplate from "../components/Documenti/Modelli/UserTemplate";
import { connect } from "react-redux";
import Container from "../components/Container";

const CondutText = createContext();
function Modelli(props) {
  const server_template = {
    "CONSENSI E DELEGHE": [
      "Delega per la chiusura dell’utenza del gas",
      "Delega per la chiusura dell’utenza elettrica",
      "Delega per la chiusura dell’utenza acqua",
    ],
    RISOLUZIONE: [
      "Disdetta del contratto di locazione per scadenza legale",
      "Disdetta del rinnovo del contratto da parte del conduttore",
    ],
  };

  const func = (search_name, search_object) => {
    for (var i = 0; i < search_object.length; i++) {
      if (
        search_object[i].toLowerCase().indexOf(search_name.toLowerCase()) != -1
      )
        return true;
    }
    return false;
  };
  return (
    <Container>
      <div className="title-search-group">
        <div className="right-header">
          <TopHeading SamllHeading="DOCUMENTI" Heading="Modelli" />
        </div>
        <div className="model-modul-group">
          <CondutText.Provider value={"Aggiungi Nuovo"}>
            <ModelliBtn btnText="Aggiungi Nuovo" />
          </CondutText.Provider>
        </div>
      </div>

      {Object.keys(server_template).map((keys, index) => {
        return (
          <div key={index}>
            {func(props.searchName, server_template[keys]) == true ? (
              <p key={index} className="fs-16 fw-bold mb-3 mt-4">
                {keys}
              </p>
            ) : (
              ""
            )}
            {server_template[keys].map((titles, id) => {
              if (
                titles.toLowerCase().indexOf(props.searchName.toLowerCase()) !=
                -1
              )
                return <ServerTemplate key={id + index * 100} name={titles} />;
              else return "";
            })}
          </div>
        );
      })}
      {Object.keys(props.user_template).map((keys, index) => {
        return (
          <div key={index}>
            {func(props.searchName, props.user_template[keys]) == true ? (
              <p key={"user" + index} className="fs-16 fw-bold mb-3 mt-4">
                {keys}
              </p>
            ) : (
              ""
            )}
            {props.user_template[keys].map((titles, id) => {
              if (
                titles.toLowerCase().indexOf(props.searchName.toLowerCase()) !=
                -1
              )
                return (
                  <UserTemplate key={id} name={titles} section_name={keys} />
                );
              else return "";
            })}
          </div>
        );
      })}
    </Container>
  );
}
const mapStateToProps = (state) => ({
  searchName: state.profile.searchName,
  user_template: state.userTemplateReducer.user_template,
});

export default connect(mapStateToProps, null)(Modelli);
