import React from "react";
import MidTabs from "../components/Membri/Conduttori/ViewMode/MidTabs";
import TopHeadPartV from "../components/Membri/Conduttori/ViewMode/TopHeadPartV";
import Container from "../components/Container";

export default function ViewConduttori() {
  return (
    <Container>
      <TopHeadPartV />
      <MidTabs />
    </Container>
  );
}
