import React from "react";
import MidTabsE from "../components/Membri/Fornitori/EditMode/MidTabsE";
import TopHeadPartE from "../components/Membri/Fornitori/EditMode/TopHeadPartE";
import Container from "../components/Container";

export default function EditFornitori() {
  return (
    <Container>
      <TopHeadPartE />
      <MidTabsE />
    </Container>
  );
}
