import React from "react";
import MidTabs from "../components/Membri/Fornitori/ViewMode/MidTabs";
import TopHeadPartV from "../components/Membri/Fornitori/ViewMode/TopHeadPartV";
import Container from "../components/Container";

export default function ViewFornitori() {
  return (
    <Container>
      <TopHeadPartV />
      <MidTabs />
    </Container>
  );
}
