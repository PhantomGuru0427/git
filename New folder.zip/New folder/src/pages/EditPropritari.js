import React from "react";
import MidTabsE from "../components/Membri/ProprietariSublocatori/EditMode/MidTabsE";
import TopHeadPartE from "../components/Membri/ProprietariSublocatori/EditMode/TopHeadPartE";
import Container from "../components/Container";

export default function EditPropritari() {
  return (
    <Container>
      <TopHeadPartE />
      <MidTabsE />
    </Container>
  );
}
