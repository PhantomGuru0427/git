import React from "react";
import MidTabsE from "../components/Membri/Conduttori/EditMode/MidTabsE";
import TopHeadPartE from "../components/Membri/Conduttori/EditMode/TopHeadPartE";
import Container from "../components/Container";

export default function EditConduttori() {
  return (
    <Container>
      <TopHeadPartE />
      <MidTabsE />
    </Container>
  );
}
