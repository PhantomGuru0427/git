import React from "react";
import Container from "../components/Container";

export default function Dashboarod() {
  return (
    <Container>
      <div>Dashboarod</div>
      <i className="fal fa-search"></i>
    </Container>
  );
}
