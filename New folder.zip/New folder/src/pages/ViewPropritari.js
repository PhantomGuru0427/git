import React from "react";
import MidTabs from "../components/Membri/ProprietariSublocatori/ViewMode/MidTabs";
import TopHeadPartV from "../components/Membri/ProprietariSublocatori/ViewMode/TopHeadPartV";
import Container from "../components/Container";
export default function ViewPropritari() {
  return (
    <Container>
      <TopHeadPartV />
      <MidTabs />
    </Container>
  );
}
