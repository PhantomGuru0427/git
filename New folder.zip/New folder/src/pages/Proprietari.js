import React, { createContext, useState } from "react";
import ColomboList from "../components/Membri/ProprietariSublocatori/ColomboList";
import EmptyList from "../components/Membri/ProprietariSublocatori/EmptyList";
import NewownerBtn from "../components/Membri/ProprietariSublocatori/NewownerBtn";
import TopHeading from "../components/Membri/ProprietariSublocatori/TopHeading";
import Container from "../components/Container";
import TabForm from "../components/Membri/ProprietariSublocatori/NewOwner/TabForm";
import userimage from "../assets/images/user-key.png";

const PropriText = createContext();

export default function Proprietari(props) {
  const [show, setShow] = useState(false);

  return (
    <Container>
      <div className="gy-4 align-items-end">
        <TopHeading
          SamllHeading="Membri"
          Heading={
            show
              ? "Nuovo proprietario o sublocatore"
              : "Proprietari/Sublocatori"
          }
          show={show}
          setShow={(v) => setShow(v)}
        />
      </div>
      {show ? (
        <TabForm setShow={(v) => setShow(v)}/>
      ) : (
        <div>
          <PropriText.Provider value={"Nuovo proprietario o sublocatore"}>
            <NewownerBtn
              btnText="Nuova proprietario"
              setShow={(v) => setShow(v)}
            />
          </PropriText.Provider>
          {window.provider === "" ? (
            <div
              className="d-flex mb-4 bg-white h-500 mt-4"
              style={{ borderRadius: "15px" }}
            >
              <EmptyList imgSrc={userimage} subText="Non hai aggiunto ancora nessun \n proprietario o sublocatore"/>
            </div>
          ) : (
            <div className="d-block mb-4 mt-4">
              <ColomboList target="Proprietari"/>
            </div>
          )}
        </div>
      )}
    </Container>
  );
}
export { PropriText };
