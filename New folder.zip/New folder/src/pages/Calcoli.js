import React from "react";
import FormBox from "../components/ColcoliImmobilliari/calcoli/index";
import TopHeading from "../components/Membri/ProprietariSublocatori/TopHeading";
import Container from "../components/Container";

export default function Calcoli(props) {
  return (
    <Container>
      <div className="mb-4">
        <TopHeading SamllHeading="CALCOLI IMMOBILIARI" Heading="Calcoli" />
      </div>
      <FormBox />
    </Container>
  );
}
