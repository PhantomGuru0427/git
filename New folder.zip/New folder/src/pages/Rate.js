import React, { createContext, useState } from "react";
import EmptyList from "../components/Membri/ProprietariSublocatori/EmptyList";
import NewownerBtn from "../components/Membri/ProprietariSublocatori/NewownerBtn";
import TopHeading from "../components/Membri/ProprietariSublocatori/TopHeading";
import imgIcon from "../assets/images/markdown.png";
import FilterTableM from "../components/Membri/Rate/Members/FilterTableM";
import Container from "../components/Container";
import TabForm from "../components/Membri/Rate/NewOwner/TabForm";

const RataText = createContext();

export default function Rate(props) {
  const [show, setShow] = useState(false);

  return (
    <Container>
      <div className="gy-4 align-items-end mb-2">
        <TopHeading
          SamllHeading="Membri"
          Heading={show ? "Nuova Rata" : "Rate"}
          show={show}
          setShow={(v) => setShow(v)}
        />
      </div>
      {show ? (
        <TabForm setShow={(v) => setShow(v)} />
      ) : (
        <div>
          <RataText.Provider value={"Nuova Rata"}>
            <NewownerBtn btnText="Nuovo rata" setShow={(v) => setShow(v)} />
          </RataText.Provider>
          {window.amountAndData === "" ? (
            <div
              className="d-flex mb-4 bg-white h-500 mt-4"
              style={{ borderRadius: "15px" }}
            >
              <EmptyList
                imgSrc={imgIcon}
                subText="Non hai aggiunto ancora nessun rata"
              />
            </div>
          ) : (
            <div className="d-block mb-4 mt-4">
              <FilterTableM />
            </div>
          )}
        </div>
      )}
    </Container>
  );
}
export { RataText };
