import { USER_TEMPLATE } from "./types";
export const changeUserTemplate = (new_user_template) => async (dispatch) => {
  try {
    dispatch({
      type: USER_TEMPLATE,
      payload: new_user_template,
    });
  } catch {}
};
