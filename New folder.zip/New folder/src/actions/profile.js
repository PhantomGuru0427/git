import { SET_NAME, SET_SEARCH } from "./types";

/*
  NOTE: we don't need a config object for axios as the
 default headers in axios are already Content-Type: application/json
 also axios stringifies and parses JSON for you, so no need for 
 JSON.stringify or JSON.parse
*/

// Get current users profile
export const setName = (name) => async (dispatch) => {
  try {
    dispatch({
      type: SET_NAME,
      payload: name,
    });
  } catch {}
};

export const setSearchName = (name) => async (dispatch) => {
  try {
    dispatch({
      type: SET_SEARCH,
      payload: name,
    });
  } catch {}
};
