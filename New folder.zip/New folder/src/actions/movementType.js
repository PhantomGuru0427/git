import { MOVEMENT_TYPE } from "./types";
export const changeMovementType = (new_movement_type) => async (dispatch) => {
  try {
    dispatch({
      type: MOVEMENT_TYPE,
      payload: new_movement_type,
    });
  } catch {}
};
