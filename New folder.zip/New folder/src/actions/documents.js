import { DOCUMENTS } from "./types";
export const changeDocuments = (new_documents) => async (dispatch) => {
  try {
    dispatch({
      type: DOCUMENTS,
      payload: new_documents,
    });
  } catch {}
};
