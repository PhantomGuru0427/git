import { combineReducers } from "redux";
import ModalForVerify from "./ModalForVerify";
import ModalForEnterCode from "./ModalForEnterCode";
import profile from "./profile";
import userTemplateReducer from "./userTemplateReducer";
import movementTypeReducer from "./movementTypeReducer";
import documentsReducer from "./documentsReducer";

export default combineReducers({
  ModalForVerify,
  ModalForEnterCode,
  profile,
  userTemplateReducer,
  movementTypeReducer,
  documentsReducer,
});
