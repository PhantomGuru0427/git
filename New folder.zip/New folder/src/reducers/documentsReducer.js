import { DOCUMENTS } from "../actions/types";

// const initialState = {
//   ["Spese condominiali", "22/06/2022", "Conto 1", 100, "", 100],
//   ["Prelievo da conto in cassa", "24/06/2022", "Conto1/Cassa", "", "", 100],
//   ["Acconto ricevuto da locatore", "30/06/2022", "Conto 2", 20, "", 120],
//   ["Interessi", "27/06/2022", "Conto 2", "", 10, 105],
//   documents:[
//     {}
//   ]
// };

const initialState = {
  documents: [
    {
      id: 1,
      cdat: "2022-08-10T07:53:48.315+0000",
      udate: null,
      typology: "Movimento",
      movementType: "bills",
      Descrizione: "Spese condominiali",
      Data: "06/22/2022",
      attachement: "file.pdf",
      startDate: "10/08/2022",
      endDate: "10/09/2022",
      taxable: 50,
      vatCode: 4,
      paymentMethod: "Bonfiico",
      Conto: "Conto1",
      Entrata: 100,
      modality: null,
      noteFrom: "fakeFrom2",
      noteTo: null,
      userID: 0,
      conductors: [],
      owners: {
        Name: "DARIO VERDI",
        Category: "Notary",
        "Type of SUBJET": "Sole Proprietorship",
        PHONE: "018283u9",
      },
      Uscita: "",
      Saldo: 100,
    },
    {
      id: 2,
      cdat: "2022-08-10T07:53:48.315+0000",
      udate: null,
      typology: "Prelievo da conto in cassa",
      movementType: "bills",
      Descrizione: "Prelievo da conto in cassa",
      Data: "05/24/2022",
      attachement: "file.pdf",
      startDate: "10/08/2022",
      endDate: "10/09/2022",
      taxable: 50,
      vatCode: 4,
      paymentMethod: "Bonfiico",
      Conto: "Conto1/Cassa",
      Entrata: "",
      modality: null,
      noteFrom: "fakeFrom2",
      noteTo: null,
      userID: 0,
      conductors: [],
      owners: {
        Name: "DARIO VERDI",
        Category: "Notary",
        "Type of SUBJET": "Sole Proprietorship",
        PHONE: "018283u9",
      },
      Uscita: "",
      Saldo: 120,
    },
    {
      id: 3,
      cdat: "2022-08-10T07:53:48.315+0000",
      udate: null,
      typology: "Acconto dato al locatore",
      movementType: "bail",
      Descrizione: "Acconto ricevuto da locatore",
      Data: "06/30/2022",
      attachement: "file.pdf",
      startDate: "10/08/2022",
      endDate: "10/09/2022",
      taxable: 50,
      vatCode: 4,
      paymentMethod: "Bonfiico",
      Conto: "Conto2",
      Entrata: 20,
      modality: null,
      noteFrom: "fakeFrom2",
      noteTo: null,
      userID: 0,
      conductors: [],
      owners: {
        Name: "DARIO VERDI",
        Category: "Notary",
        "Type of SUBJET": "Sole Proprietorship",
        PHONE: "018283u9",
      },
      Uscita: "",
      Saldo: 120,
    },
    {
      id: 4,
      cdat: "2022-08-10T07:53:48.315+0000",
      udate: null,
      typology: "Acconto ricevuto da locatore",
      movementType: "canon",
      Descrizione: "Interessi",
      Data: "06/27/2022",
      attachement: "file.pdf",
      startDate: "10/08/2022",
      endDate: "10/09/2022",
      taxable: 50,
      vatCode: 4,
      paymentMethod: "Bonfiico",
      Conto: "Conto2",
      Entrata: "",
      modality: null,
      noteFrom: "fakeFrom2",
      noteTo: null,
      userID: 0,
      conductors: [],
      owners: {
        Name: "DARIO VERDI",
        Category: "Notary",
        "Type of SUBJET": "Sole Proprietorship",
        PHONE: "018283u9",
      },
      Uscita: 10,
      Saldo: 105,
    },
  ],
};

function documentsReducer(state = initialState, action) {
  const { type, payload } = action;

  switch (type) {
    case DOCUMENTS:
      return {
        documents: {
          ...payload,
        },
      };
    default:
      return initialState;
  }
}

export default documentsReducer;
