import { USER_TEMPLATE } from "../actions/types";

const initialState = {
  user_template: {
    COMUNICAZIONI: ["Comunicazione della riduzione del canone"],
    NEW1: ["Child1", "Child2"],
    NEW2: ["Child11", "Child22"],
  },
};

function userTemplateReducer(state = initialState, action) {
  const { type, payload } = action;

  switch (type) {
    case USER_TEMPLATE:
      console.log("-------", payload);
      return {
        user_template: {
          ...payload,
        },
      };
    default:
      return initialState;
  }
}

export default userTemplateReducer;
