import { MOVEMENT_TYPE } from "../actions/types";

const initialState = {
  server_movement_type: [
    "bollette",
    "canone",
    "cauzione",
    "competenze di gestione",
    "conguaglio fatturato",
    "consumi",
    "costi fissi per locazione",
    "diritti di segreteria",
    "imposta di registro",
    "imposta di soggiorno",
    "interessi",
    "interessi di mora",
    "marca da bollo",
    "marca da bollo da ordinare",
    "mediazione",
    "pagamento",
    "pagamento assicurazione",
    "pagamento fornitore",
    "piano di rientro",
    "ritenuta",
    "rivalsa cassa previdenziale",
    "sanzioni",
    "sconto canone in scaletta",
    "spese condominiali",
    "spese d’incasso",
    "spese di registrazione",
    "spese di registrazione contratti",
    "trasferimento di denaro",
    "trattenuta sulla cauzione",
  ],
  user_movement_type: ["prova", "new1", "new2"],
};

function movementTypeReducer(state = initialState, action) {
  const { type, payload } = action;

  switch (type) {
    case MOVEMENT_TYPE:
      return {
        ...initialState,
        user_movement_type: payload,
      };
    default:
      return initialState;
  }
}

export default movementTypeReducer;
